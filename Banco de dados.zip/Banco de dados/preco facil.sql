-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25-Jun-2021 às 02:09
-- Versão do servidor: 10.4.18-MariaDB
-- versão do PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `projeto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `acesso`
--

CREATE TABLE `acesso` (
  `id` int(11) NOT NULL,
  `login` varchar(50) DEFAULT NULL,
  `senha` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `acesso`
--

INSERT INTO `acesso` (`id`, `login`, `senha`) VALUES
(1, 'jorge', '3213');

-- --------------------------------------------------------

--
-- Estrutura da tabela `aprovacao`
--

CREATE TABLE `aprovacao` (
  `id_aprovacao` int(11) NOT NULL,
  `nome_aprovacao` varchar(100) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `nome_mercado` varchar(100) NOT NULL,
  `valor` decimal(9,2) DEFAULT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `categoria` int(11) DEFAULT NULL,
  `pais` varchar(100) DEFAULT NULL,
  `estado` varchar(100) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `data_cad` datetime NOT NULL,
  `palavras_chaves` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `aprovacao`
--

INSERT INTO `aprovacao` (`id_aprovacao`, `nome_aprovacao`, `marca`, `nome_mercado`, `valor`, `imagem`, `categoria`, `pais`, `estado`, `cidade`, `bairro`, `descricao`, `data_cad`, `palavras_chaves`) VALUES
(38, 'Feijão', 'Asdasd', 'Asdsadas', '24.52', 'b94fcb3aa6956475757c0eafd1db9bd6.jpg', 1, 'Brasil', 'Asdasd', 'Asdasd', 'Asdasd', 'asdasd', '2021-05-25 17:04:51', 'asdasd asdasd '),
(39, 'MOnitores', 'Asdasd', 'Dasdasd', '4.55', '8dff1cb6c4869e1d59719292b717bb12.jpg', 9, 'Brasil', 'Asdasda', 'Asdasd', 'Asdasdsa', 'asdasd', '2021-05-25 17:44:49', 'asdasd asdasd ');

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

CREATE TABLE `categorias` (
  `id_categorias` int(11) NOT NULL,
  `categoria` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` (`id_categorias`, `categoria`, `img`) VALUES
(1, 'Alimentos e Bebidas', 'chefe-de-cozinha.svg'),
(2, 'Beleza e Cuidado Pessoal', 'sabonete.svg'),
(3, 'Esportes', 'esporte.svg'),
(4, 'Games', 'controle-game.svg'),
(5, 'Informatica', 'computador.svg'),
(6, 'Pets', 'pawprint.svg'),
(7, 'Eletrodomésticos', 'appliances.svg'),
(8, 'Móveis e decoração', 'armchair.svg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mais_acessados`
--

CREATE TABLE `mais_acessados` (
  `id_acessado` int(11) NOT NULL,
  `id_produto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `mais_acessados`
--

INSERT INTO `mais_acessados` (`id_acessado`, `id_produto`) VALUES
(11, 2),
(2, 4),
(9, 7),
(7, 20),
(8, 21),
(6, 24),
(5, 26),
(1, 31),
(3, 36),
(10, 37);

-- --------------------------------------------------------

--
-- Estrutura da tabela `mudancas`
--

CREATE TABLE `mudancas` (
  `id` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `novo_preco` decimal(9,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `mudancas`
--

INSERT INTO `mudancas` (`id`, `id_produto`, `novo_preco`) VALUES
(3, 37, '1.99');

-- --------------------------------------------------------

--
-- Estrutura da tabela `nome_categorias`
--

CREATE TABLE `nome_categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `nome_categoria` varchar(100) DEFAULT NULL,
  `palavras_categoria` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `nome_categorias`
--

INSERT INTO `nome_categorias` (`id`, `nome`, `nome_categoria`, `palavras_categoria`) VALUES
(1, 'Alimentos', 'categoria_de_alimentos', 'Achocolatado,Açúcar,Adoçante,Arroz,Atum,Azeite,Azeitona,Batata palha,Baunilha,Biscoito,Bolacha,Bombom,Café,Caldo,Catchup,Katchup,Mostarda,Cereal,Champignon,Chocolate,Chocolate granulado,Granulado,Coco ralado,Queijo ralado,Creme de leite,Farinha de mandioca,Mandioca,Fairinha de milho,Milho,Farinha de rosca,Farinha de trigo,Feijão,Fermento,Gelatina,Geleia,Leite,Leite condensado,Leite de coco,Lentilha,Macarrâo,Maionese,Molho,Miojo,Mostarda,Molho de Tomate,Tomate,Polpa de tomate,Polvilho,Sagu,Sal,Sal grosso,Salsicha,Sardinha,Sopa,Tempero,Salgadinho,ovo,Batata frita,Pão Pulma,Miojo sabor feijão,Miojo Nissan,'),
(2, 'Bebidas', 'categoria_de_bebidas', 'Agua,Agua de coco,Água tonica,Cerveja,Champanhe,Licor,Refrigerante,Rum,Suco,Vinho,Uísque,Vodca,Nescau,Toddy,Suco de caixinha,'),
(3, 'Frios', 'categoria_de_frios', 'Queijo Prato,Queijo mussarela,Bacon,Presunto,Mortadela defumanda,'),
(4, 'Carne', 'categoria_de_carnes', 'Bovina,Carne,Peixe,Miúdos,Porco,Frango,'),
(5, 'Produtos para Cabelo', 'categoria_de_cabelo', 'Shampoo,Condicionador,'),
(6, 'Maquiagem', 'categoria_de_maquiagem', 'Esponja de Maquiagem,Paleta de sombras,'),
(7, 'Perfumes', 'categoria_de_perfumes', 'Perfume,'),
(8, 'Pele', 'categoria_de_pele', 'Protetor solar,Água termal,Creme hidratante,Sabonete,Sabonete liquido,'),
(9, 'Computadores', 'categoria_de_computadores', 'Computador,Notebook,'),
(10, 'SmartPhone', 'categoria_de_smartphones', NULL),
(11, 'Bicicletas', 'categoria_de_bicicleta', 'Bicicleta Urbana,Bike Trial,'),
(12, 'Equipamentos de esportes', 'categoria_de_equipamentos_para_esportes_bolas', 'Bola de futebol,Bola de basket,'),
(13, 'Playstation', 'categoria_de_playstation', 'God of War,God of war 2,God of war 3,God of war 4,The last of us,The last of us part II,Ghost of Tsushima,Shadow of the Colossus,'),
(14, 'Xbox', 'categoria_de_xbox', ''),
(15, 'Nintendo', 'categoria_de_nintendo', NULL),
(16, 'Jogos de computadores', 'categoria_de_jogos_computador', NULL),
(17, 'Brinquedos para cachorro e gato', 'categoria_de_Brinquedos_para_cachorros_ou_gato', 'Varinha,Osso de brinquedo,'),
(18, 'Bebedouros e Comedouros para Pets', ' categoria_de_bebedouros_e_comedouros', NULL),
(21, 'Acessórios para cachoro ou gato', 'categoria_de_acessorio', 'Coleira,'),
(22, 'Alimentos para gatos e cachorros', 'categoria_de_alimentos_para_gatos_e_cachorros', NULL),
(23, 'Cama e casas', 'categoria_de_Camas_e_casas', NULL),
(24, 'Geladeiras e Freezers', 'categoria_de_geladeiras_e_freezers', 'Geladeira,Freezer,'),
(25, 'Máquinas de lavar', 'categoria_de_maquinas_de_lavar', 'Maquina de lavar roupa,Maquina de lavar louça,'),
(26, 'Fogão e Fornos', 'categoria_de_fogao_e_fornos', 'Fogão,Forno,'),
(27, 'Eletrodomésticos para casa', 'categoria_de_para_casa', 'Ferro de passar,Aspirador de pó,Maquina de costura,Vassoura Elétrica,'),
(28, 'Eletrodomésticos para cozinha', 'categoria_de_para_cozinha', 'Cafeteira,Micro-ondas,Torradeira,Liquitificador,Air Fryer,'),
(29, 'Ar condicionado, Aquecedores e Ventiladores', 'categoria_de_ar', 'Ventilador,Ar condicionado,Aquecedor,'),
(30, 'Móveis de casa', 'categoria_de_moveis_de_casa', 'Sofa,Mesa,Nixo,Cadeira,Guarda Roupas,Painel para TV,'),
(31, 'Utilidades Domésticas', 'categoria_de_utilidades_domesticas', 'Panelas,Tapoers,Talheres,Xícara,Jarro,Prato,Frigideira,Abridor de Garrafa,Abridor de Lata,'),
(32, 'Decoração de casa', 'categoria_de_decoracao_casa', 'Lençois,Almofadas,Puff,Puff báu,Quadros,Espelho,Cortina,Papel de parde,Tapete,'),
(33, 'Cama,Mesa e Banho', 'categoria_de_cama_mesa_banho', 'Travesseiro,Toalhas,Lençol,Pano de prato,');

-- --------------------------------------------------------

--
-- Estrutura da tabela `nome_subcategorias`
--

CREATE TABLE `nome_subcategorias` (
  `id_subcategoras` int(11) NOT NULL,
  `nome_subcategorias` varchar(100) DEFAULT NULL,
  `nome_visual` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `nome_subcategorias`
--

INSERT INTO `nome_subcategorias` (`id_subcategoras`, `nome_subcategorias`, `nome_visual`) VALUES
(1, 'subcategoria_alimentos', 1),
(2, 'subcategorias_beleza', 2),
(3, 'subcategorias_eletrodometicos', 7),
(4, 'subcategorias_esportes', 3),
(5, 'subcategorias_games', 4),
(6, 'subcategorias_informatica', 5),
(7, 'subcategorias_moveis_decoracao', 8),
(8, 'subcategorias_pets', 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id_produtos` int(11) NOT NULL,
  `nome_produtos` varchar(100) NOT NULL,
  `nome_mercado` varchar(100) NOT NULL,
  `valor` decimal(9,2) DEFAULT NULL,
  `Marca` varchar(100) NOT NULL,
  `imagem` varchar(100) DEFAULT NULL,
  `categoria` int(11) DEFAULT NULL,
  `pais` varchar(100) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `data_cad` datetime NOT NULL,
  `palavras_chaves` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id_produtos`, `nome_produtos`, `nome_mercado`, `valor`, `Marca`, `imagem`, `categoria`, `pais`, `estado`, `cidade`, `bairro`, `descricao`, `data_cad`, `palavras_chaves`) VALUES
(1, 'Nescau', 'O escolhido', '15.99', 'Nescau', '80b5f3e2596b91267b02c786ed0a9194.jpg', 2, 'Brasil', 'São Paulo', 'Cruzeiro', 'Aguassia', 'Nao gostei', '2021-04-13 16:03:35', 'marrom nescau '),
(2, 'Batata frita', 'Atacadão', '29.99', 'Mais batata', 'cef0b5db5ddf63747efe515b956424d6.jpg', 1, 'Brasil', 'São Paulo', 'Cruzeiro', 'Jardim', 'boazinha, mais ou menos, não é muito essas coisas', '2021-04-13 16:15:34', 'frita batata '),
(3, 'Carne', 'Dia', '59.99', 'Friboy', '7ce519e635c46acc9a729f63b2f7b650.jpg', 4, 'BR', 'SP', 'Cotia', 'Jardim Japão', 'muito bom a carne, recomendo', '2021-04-13 16:17:18', 'confiavel boi friboi carne '),
(4, 'Miojo', 'Atacadão', '2.99', 'Monica', '29b5a9003cdc582995219c784523195d.jpg', 1, 'Braisil', 'Sao Paulo', 'Cruzeiro', 'Bairro nao informado', 'Muito bom, maravilhoso', '2021-04-13 16:34:08', 'Monica Macarrão Miojo '),
(5, 'Cerveja', 'O escolhido', '5.99', 'Scol', '87cbcd596eef08d8e425fbee954f405b.jpg', 2, 'Brasil', 'SP', 'Cruzeiro', 'JD', 'Comentario teste Comentario teste Comentario teste Comentario teste Comentario teste Comentario teste', '2021-04-13 16:38:36', 'beber gas cerveja scoll '),
(6, 'Chocolate', 'Escolhido', '28.99', 'Lacta', 'de0fde746a3aa6e6276c8bee93e81163.jpg', 1, 'Brasil', 'Estado não informado', 'Cruzeiro', 'Aguassai', 'Comentario teste Comentario teste Comentario teste Comentario teste Comentario teste Comentario teste', '2021-04-13 17:56:53', 'amargo marrom chocolate '),
(7, 'Açúcar', 'O escolhido', '15.99', 'União', '412ad5b8ae2f7561ff8b5879e87266a0.jpg', 1, 'Brasil', 'SP', 'Cidade não informada', 'Aguassai', 'açucar né, teste', '2021-04-13 18:49:31', 'pó doce açucar '),
(9, 'Presunto', 'Atacadão', '25.99', 'Sadia', '036351d66813b4dd0fee55093c5c6d0b.jpg', 3, 'Brasil', 'SP', 'Cidade não informada', 'Aguassai', 'Presunto, teste', '2021-04-13 19:43:37', 'sadia presunto '),
(10, 'shampoo', 'Atacadõa', '30.99', 'Dove', '85fafb85282088f11a37b7c6893b6822.jpg', 5, 'Brasil', 'Sp', 'Cruzeiro', 'Jaridm', 'testes dove', '2021-04-13 20:13:56', 'cabelo shammpo dove '),
(11, 'Perfume', 'Lojas da Dove', '89.99', 'Dove', '2a59788b8716c165f7def8e308c14142.jpg', 7, 'BR', 'SP', 'Cidade não informada', 'Bairro nao informado', 'comentario teste', '2021-04-14 10:07:01', 'cheiroso dove perfume '),
(12, 'Protetor solar', 'Maximum', '79.99', 'Nivea sun', 'b1ba5b1cb1c01b012d2b11c21e26f459.jpg', 8, 'Brasil', 'São Paulo', 'Cruzeiro', 'Jardim Japão', 'COMENTARIO TESTE', '2021-04-14 10:13:34', 'protetor nivea '),
(13, 'Esponja de Maquiagem', 'Atacadão', '59.99', 'Dove', 'f1b962d0e3d2ee9181881e45b64fb804.jpg', 6, 'BR', 'SP', 'CR', 'JD', 'Comentairo testeee', '2021-04-14 10:18:12', 'maquiagem esponja '),
(14, 'God of War', 'Maximum', '199.99', 'PS4', '363b033cd4ddd61c39cffcdc01ab72b3.jpg', 13, 'BR', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'Teste', '2021-04-14 19:12:52', 'plays station4 jogo god of war '),
(16, 'Bola de Basket', 'NBA', '399.99', 'NBA', '4992484162550ecc3efbf18ba1a79eed.jpg', 12, 'Brasil', 'São Paulo', 'Cruzeiro', 'Jardim Japão', 'teste', '2021-04-14 20:47:07', 'basket bola '),
(17, 'Farinha de trigo', 'Atacadão', '12.99', 'Royal', '0c82dfb7d283e39f6c8c4c5ac0888ac7.jpg', 1, 'Braisil', 'Sao paulo', 'Cruzeiro', 'Bairro nao informado', 'Teste', '2021-04-14 20:55:00', 'Farinha  '),
(20, 'basket ball', 'Mercado teste', '99.99', 'NBA', 'c085be48bc11a53003065613612be0f3.jpg', 12, 'Brasil', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'teste', '2021-04-15 18:48:36', 'basket bola '),
(21, 'Bolacha', 'Atacadao', '2.99', 'Trakinas', '0ce003a37f0b2795afba2c7cabbb5633.jpg', 1, 'Pais nao informado', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'teste', '2021-04-15 23:46:39', 'bolacha biscoito '),
(22, 'Bike Trial', 'Loja esportes top', '500.00', 'Biketrials', '30ceddf4d0def6aaed7b35c1a106e846.png', 11, 'Brasil', 'São Paulo', 'São Paulo', 'Bairro jardim', 'comentario teste', '2021-04-16 00:14:03', 'trial bike '),
(23, 'Varinha', 'Mercado', '5.95', 'Varianha para gato', '07001b75677782a1b565e31cb04d9a5f.jpg', 17, 'Brasil', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'testes', '2021-04-16 12:57:39', 'brinquedo par gato gato varinha '),
(24, 'Bola de futebol', 'Loja esportes', '900.99', 'Nike', 'efc33c15e66196d8526351ec7a68f728.jpg', 12, 'Brasil', 'São Paulo', 'Cruzeiro', 'São Paulo', 'testes', '2021-04-16 15:01:29', 'futeball futsal bola '),
(25, 'Ar condicionado', 'AR fresco', '99.99', 'AR bom', 'd2cf50818b7345468f0617ccaa1090e1.jpg', 29, 'Brasil', 'São paulo', 'Cruzeiro', 'Tanjiro kamado', 'testse', '2021-04-16 19:42:51', 'condicionado ar '),
(26, 'Geladeira', 'Mercado tsetes', '1500.09', 'Fronzem', 'ad36f29e5ec08433c45fc64499281b7b.jpg', 24, 'Brasil', 'São paulo', 'Cruzeiro', 'Aguassai', 'testes', '2021-04-16 19:45:29', 'congelar geladeria '),
(27, 'Sofa', 'Sofa airexoress', '48.98', 'marca teste', 'ae46be17cf4c678eabed8269e9465d82.jpg', 30, 'Pais nao informado', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'teste', '2021-04-17 00:56:28', 'marrom sofa '),
(28, 'Air Fryer', 'Mercado tests', '99.99', 'Air power flowee', 'c4bd42a550d3ae0cd9bff6a5c1b7ceb9.jpg', 28, 'Brasil', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'air frayer muito boa', '2021-04-20 21:38:42', 'cozinha fritadeira '),
(29, 'Macarrâo', 'Mercado testes', '59.99', 'Vitarrela', 'aede805c0a25db23531731edd37a464b.jpg', 1, 'Pais nao informado', 'Estado não informado', 'Cruzeiro', 'Bairro nao informado', 'bom o  macarrão', '2021-04-20 21:46:36', 'pasta macarrão '),
(30, 'Mostarda', 'Mercado teste', '158.99', 'Heiz', '78fdd798b25911dd4cbd963f478dcccd.jpg', 1, 'Brasil', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'teste', '2021-04-20 21:48:43', 'mostarda amarelo '),
(31, 'Miojo', 'Mercado teste', '99.99', 'Marca', '2d93c20a64d2ba07af3b31cc05a4eba2.jpg', 4, 'Brasil', 'Estado não informado', 'Cidade não informada', 'Bairro nao informado', 'testes', '2021-04-23 12:33:15', 'palavras '),
(36, 'Sofa', 'Mercado teste', '1500.99', 'Sofa industriassd', '994baacb1b25944ded2f0786d642394d.jpg', 30, 'Brasil', 'São Paulo', 'Aguassai', 'Jardim Primavera', 'sofa muito bom', '2021-04-27 15:42:12', 'marrom sofa '),
(37, 'Miojo', 'Aurora', '9.99', 'Nissan', 'f7968440a8032cf35d1e20a36627db6d.jpg', 1, 'Brasil', 'São Paulo', 'Cruzeiro', 'Aguassai', 'Muito bom esse miojo, mas a monica é melhor', '2021-04-29 16:50:18', 'lamen miojo ');

-- --------------------------------------------------------

--
-- Estrutura da tabela `referencia_nome_tables`
--

CREATE TABLE `referencia_nome_tables` (
  `id_referencia` int(11) NOT NULL,
  `caminho` int(11) DEFAULT NULL,
  `subcategoria` varchar(100) NOT NULL,
  `caminho_subcategorias` varchar(100) NOT NULL,
  `nome_categoria_referencia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `referencia_nome_tables`
--

INSERT INTO `referencia_nome_tables` (`id_referencia`, `caminho`, `subcategoria`, `caminho_subcategorias`, `nome_categoria_referencia`) VALUES
(1, 1, 'Comida', 'subcategoria_alimentos', 1),
(2, 1, 'Bebidas', 'subcategoria_alimentos', 2),
(3, 1, 'Carnes', 'subcategoria_alimentos', 4),
(4, 1, 'Frios', 'subcategoria_alimentos', 3),
(5, 2, 'Perfumes', 'subcategorias_beleza', 7),
(6, 2, 'Cabelo', 'subcategorias_beleza', 5),
(7, 2, 'Pele', 'subcategorias_beleza', 8),
(8, 2, 'Maquiagem', 'subcategorias_beleza', 6),
(9, 4, 'PlayStation', 'subcategorias_games', 13),
(10, 4, 'XBOX', 'subcategorias_games', 14),
(11, 4, 'Nintendo Switch', 'subcategorias_games', 15),
(12, 4, 'Jogos para Computador', 'subcategorias_games', 16),
(13, 5, 'Computadores', 'subcategorias_informatica', 9),
(14, 5, 'SmartPhones', 'subcategorias_informatica', 10),
(15, 3, 'Equipamentos para esportes Bolas,Raquetes e etc', 'subcategorias_esportes', 12),
(16, 3, 'Bicicletas', 'subcategorias_esportes', 11),
(17, 6, 'Brinquedos para cachorro ou gato', 'subcategorias_pets', 17),
(18, 6, 'Bebedouros e Comedouros', 'subcategorias_pets', 18),
(19, 6, 'Acessórios', 'subcategorias_pets', 21),
(20, 6, 'Alimentos para gatos e cachorros', 'subcategorias_pets', 22),
(21, 6, 'Camas e Casas', 'subcategorias_pets', 23),
(22, 7, 'Geladeiras e Freezers', 'subcategorias_eletrodometicos', 24),
(23, 7, 'Máquinas de lavar', 'subcategorias_eletrodometicos', 25),
(24, 7, 'Fogão e Fornos', 'subcategorias_eletrodometicos', 26),
(25, 7, 'Eletrodomésticos para casa', 'subcategorias_eletrodometicos', 27),
(26, 7, 'Eletrodomésticos para cozinha', 'subcategorias_eletrodometicos', 28),
(27, 7, 'Ar condicionado, Aquecedores e Ventiladores', 'subcategorias_eletrodometicos', 29),
(28, 8, 'Móveis', 'subcategorias_moveis_decoracao', 30),
(29, 8, 'Utilidades Domésticas', 'subcategorias_moveis_decoracao', 31),
(30, 8, 'Decoração de casa', 'subcategorias_moveis_decoracao', 32),
(31, 8, 'Cama, Mesa e Banho', 'subcategorias_moveis_decoracao', 33);

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_beleza`
--

CREATE TABLE `subcategorias_beleza` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(200) DEFAULT NULL,
  `img_categoria` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_beleza`
--

INSERT INTO `subcategorias_beleza` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Perfumes', 'perfume.png'),
(2, 'Cabelo', 'cabelo.jpg'),
(3, 'Maquiagem', 'maquiagem.jpg'),
(4, 'Pele', 'pele.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_eletrodometicos`
--

CREATE TABLE `subcategorias_eletrodometicos` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(100) DEFAULT NULL,
  `img_categoria` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_eletrodometicos`
--

INSERT INTO `subcategorias_eletrodometicos` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Geladeiras e Freezers', 'geladeira.jpg'),
(2, 'Máquinas de lavar', 'maquina de lavar.jpg'),
(3, 'Fogão e Fornos', 'fogao.jpg'),
(4, 'Eletrodomésticos para casa', 'eletrodomesticos para casa.jpg'),
(5, 'Eletrodomésticos para cozinha', 'eletrodomesticos de cozinha.jpg'),
(6, 'Ar condicionado, Aquecedores e Ventiladores', 'ar-condicionado.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_esportes`
--

CREATE TABLE `subcategorias_esportes` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(200) DEFAULT NULL,
  `img_categoria` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_esportes`
--

INSERT INTO `subcategorias_esportes` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Bicicletas', 'bicicleta.jpg'),
(2, 'Equipamentos para esportes Bolas,Raquetes e etc', 'bolas_esportes.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_games`
--

CREATE TABLE `subcategorias_games` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(200) DEFAULT NULL,
  `img_categoria` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_games`
--

INSERT INTO `subcategorias_games` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'PlayStation', 'playstation.jpg'),
(2, 'XBOX', 'xbox.jpg'),
(3, 'Nintendo Switch', 'nintendo.png'),
(4, 'Jogos para Computador', 'pcgamer.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_informatica`
--

CREATE TABLE `subcategorias_informatica` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(200) NOT NULL,
  `img_categoria` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_informatica`
--

INSERT INTO `subcategorias_informatica` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Computadores', 'computadores.jpg'),
(2, 'SmartPhones', 'smartphone.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_moveis_decoracao`
--

CREATE TABLE `subcategorias_moveis_decoracao` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(100) DEFAULT NULL,
  `img_categoria` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_moveis_decoracao`
--

INSERT INTO `subcategorias_moveis_decoracao` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Móveis', 'moveis.jpg'),
(2, 'Utilidades Domésticas', 'utilidades.jpg'),
(3, 'Cama, Mesa e Banho', 'toalha.jpg'),
(4, 'Decoração de casa', 'decoracao.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_pets`
--

CREATE TABLE `subcategorias_pets` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(100) NOT NULL,
  `img_categoria` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_pets`
--

INSERT INTO `subcategorias_pets` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Brinquedos para cachorro ou gato', 'brinquedos de caes.jpg'),
(2, 'Bebedouros e Comedouros', 'bebedouros.jpg'),
(3, 'Acessórios', 'acessorio.jpg'),
(4, 'Alimentos para gatos e cachorros', 'alimentos para animais.jpg'),
(5, 'Camas e Casas', 'casas de cachorro.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias_roupas`
--

CREATE TABLE `subcategorias_roupas` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(200) DEFAULT NULL,
  `img_categoria` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategorias_roupas`
--

INSERT INTO `subcategorias_roupas` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Moda Masculina', NULL),
(2, 'Moda Feminina', NULL),
(3, 'Meninas', NULL),
(4, 'Meninnos', NULL),
(5, 'Bebes', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategoria_alimentos`
--

CREATE TABLE `subcategoria_alimentos` (
  `id` int(11) NOT NULL,
  `sub_categoria` varchar(200) DEFAULT NULL,
  `img_categoria` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `subcategoria_alimentos`
--

INSERT INTO `subcategoria_alimentos` (`id`, `sub_categoria`, `img_categoria`) VALUES
(1, 'Comida', 'comida.jpg'),
(2, 'Bebidas', 'bebidas.jpg'),
(3, 'Carnes', 'carnes.jpg'),
(4, 'Frios', 'frios.jpg');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `acesso`
--
ALTER TABLE `acesso`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `aprovacao`
--
ALTER TABLE `aprovacao`
  ADD PRIMARY KEY (`id_aprovacao`),
  ADD KEY `categoria` (`categoria`);

--
-- Índices para tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categorias`);

--
-- Índices para tabela `mais_acessados`
--
ALTER TABLE `mais_acessados`
  ADD PRIMARY KEY (`id_acessado`),
  ADD KEY `id_produto` (`id_produto`);

--
-- Índices para tabela `mudancas`
--
ALTER TABLE `mudancas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `nome_categorias`
--
ALTER TABLE `nome_categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `nome_subcategorias`
--
ALTER TABLE `nome_subcategorias`
  ADD PRIMARY KEY (`id_subcategoras`),
  ADD KEY `nome_visual` (`nome_visual`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id_produtos`),
  ADD KEY `categoria` (`categoria`);

--
-- Índices para tabela `referencia_nome_tables`
--
ALTER TABLE `referencia_nome_tables`
  ADD PRIMARY KEY (`id_referencia`),
  ADD KEY `caminho` (`caminho`),
  ADD KEY `nome_categoria_referencia` (`nome_categoria_referencia`);

--
-- Índices para tabela `subcategorias_beleza`
--
ALTER TABLE `subcategorias_beleza`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategorias_eletrodometicos`
--
ALTER TABLE `subcategorias_eletrodometicos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategorias_esportes`
--
ALTER TABLE `subcategorias_esportes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategorias_games`
--
ALTER TABLE `subcategorias_games`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategorias_informatica`
--
ALTER TABLE `subcategorias_informatica`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategorias_moveis_decoracao`
--
ALTER TABLE `subcategorias_moveis_decoracao`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategorias_pets`
--
ALTER TABLE `subcategorias_pets`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategorias_roupas`
--
ALTER TABLE `subcategorias_roupas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `subcategoria_alimentos`
--
ALTER TABLE `subcategoria_alimentos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `acesso`
--
ALTER TABLE `acesso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `aprovacao`
--
ALTER TABLE `aprovacao`
  MODIFY `id_aprovacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categorias` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `mais_acessados`
--
ALTER TABLE `mais_acessados`
  MODIFY `id_acessado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `mudancas`
--
ALTER TABLE `mudancas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `nome_categorias`
--
ALTER TABLE `nome_categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de tabela `nome_subcategorias`
--
ALTER TABLE `nome_subcategorias`
  MODIFY `id_subcategoras` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id_produtos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de tabela `referencia_nome_tables`
--
ALTER TABLE `referencia_nome_tables`
  MODIFY `id_referencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de tabela `subcategorias_beleza`
--
ALTER TABLE `subcategorias_beleza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `subcategorias_eletrodometicos`
--
ALTER TABLE `subcategorias_eletrodometicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `subcategorias_esportes`
--
ALTER TABLE `subcategorias_esportes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `subcategorias_games`
--
ALTER TABLE `subcategorias_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `subcategorias_informatica`
--
ALTER TABLE `subcategorias_informatica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `subcategorias_moveis_decoracao`
--
ALTER TABLE `subcategorias_moveis_decoracao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `subcategorias_pets`
--
ALTER TABLE `subcategorias_pets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `subcategorias_roupas`
--
ALTER TABLE `subcategorias_roupas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `subcategoria_alimentos`
--
ALTER TABLE `subcategoria_alimentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `aprovacao`
--
ALTER TABLE `aprovacao`
  ADD CONSTRAINT `aprovacao_ibfk_1` FOREIGN KEY (`categoria`) REFERENCES `nome_categorias` (`id`);

--
-- Limitadores para a tabela `mais_acessados`
--
ALTER TABLE `mais_acessados`
  ADD CONSTRAINT `mais_acessados_ibfk_1` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`id_produtos`);

--
-- Limitadores para a tabela `nome_subcategorias`
--
ALTER TABLE `nome_subcategorias`
  ADD CONSTRAINT `nome_subcategorias_ibfk_1` FOREIGN KEY (`nome_visual`) REFERENCES `categorias` (`id_categorias`);

--
-- Limitadores para a tabela `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`categoria`) REFERENCES `nome_categorias` (`id`);

--
-- Limitadores para a tabela `referencia_nome_tables`
--
ALTER TABLE `referencia_nome_tables`
  ADD CONSTRAINT `referencia_nome_tables_ibfk_1` FOREIGN KEY (`caminho`) REFERENCES `categorias` (`id_categorias`),
  ADD CONSTRAINT `referencia_nome_tables_ibfk_2` FOREIGN KEY (`nome_categoria_referencia`) REFERENCES `nome_categorias` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
