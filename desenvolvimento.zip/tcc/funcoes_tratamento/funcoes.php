<?php
  function tratar_data($d){
    $data = substr($d,0,10);
    $data = explode("-",$data);
    $dataAtual = date("d/m/Y");
    $dataAtual = explode("/",$dataAtual);
    $a=0;
    if($dataAtual[0] == $data[2]){
      $aviso="Postado hoje";
      return $aviso;
      }else if($dataAtual[0] > $data[2]){
      for ( $i=$data[2];  $i < $dataAtual[0]; $i++){ 
        $a++;
        if($a==1){
          $aviso = "Postado á ".$a." dia";
        }else if($a>1 && $a<8){
          $aviso = "Postado á ".$a." dias";
        }else if($a>7 && $a<14){
          $aviso = "Postado á uma semana";
        }else if($a> 14 && $a < 21){
          $aviso = "Postado á 2 semanas";
        }else if($a > 21 &&$a < 28){
          $aviso = "Postado á 3 semanas";
        }else if($a > 28 && $a < 31){
          $aviso = "Postado á 4 semanas";
        }else if($a == 31){
          $aviso = "Postado á 1 mes";
        }
      }
      return $aviso;
    }elseif($dataAtual[1]> $data[1]){
      $aviso = "Postado mês passado";
      return $aviso;
    }
  }
  function tratar_preco($a){
    $preco_p_len=  strlen($a);
    if($preco_p_len >=7){
      $a = str_replace('.',',',$a);
      $antes = substr($a,0,1);
      $depois = substr($a,1,7);
      $a = $antes.'.'.$depois;
    }else if($preco_p_len < 7){
      $a = str_replace('.',',',$a);
    }
    return $a;
  }
?>