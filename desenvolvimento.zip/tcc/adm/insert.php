<?php
  include('../conexao/conexao.php');
  $a = isset($_GET['acao'])?$_GET['acao']:'';
  if($a == 'cadastro'){
    $nome = trim(ucfirst(isset($_POST['name_p'])?$_POST['name_p']:''));
    $nome_mercado = trim(ucfirst(isset($_POST['mercado'])?$_POST['mercado']:''));
    $preco = isset($_POST['preco'])?$_POST['preco']:'';
    $pais = trim(ucfirst(isset($_POST['pais'])?$_POST['pais']:''));
    $estado = trim(ucfirst(isset($_POST['estado'])?$_POST['estado']:''));
    $cidade = trim(ucfirst(isset($_POST['cidade'])?$_POST['cidade']:''));
    $bairro = trim(ucfirst(isset($_POST['bairro'])?$_POST['bairro']:''));
    $categoria = isset($_POST['categoria'])?$_POST['categoria']:'';
    $img = $_FILES['img_foto'];
    $comentario = trim(ucfirst(isset($_POST['comentario'])?$_POST['comentario']:''));
    $palavras_chaves = isset($_POST['palavras'])?$_POST['palavras']:'';
    /*Tratamento*/
    $precolen = strlen($preco);
    if($precolen <= 6){
      $preco = str_replace(",",".",$preco);
    }else if($precolen >= 8){
      $preco = str_replace(".","",$preco);
      $preco = str_replace(",",".",$preco);
    }
    $palavras_chaves = str_replace("."," ",$palavras_chaves);
    /*upload img*/
      $largura = "300";
      $altura = "300";
      $config = array();
      $config['tamanho'] =7000000;
      $config['largura'] = 300;
      $config['altura'] = 300;
      $error = array();
    if($img){
      if(!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $img["type"])){
        $aviso= "Arquivo em formato inválido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo";
      }else{
        if($img["size"] > $config["tamanho"]){
          $aviso = "Arquivo em tamanho muito grande!";
        }
        $tamanhos = getimagesize($img["tmp_name"]);
        if($tamanhos[0]>$config['largura']){
          $aviso = "Largura da imagem não deve ultrapassar " . $config["largura"] . " pixels";
        }
        if($tamanhos[1] > $config['altura']){
          $aviso = "Altura da imagem não deve ultrapassar " . $config["altura"] . " pixels";
        }
      }
      if(sizeof($error)){
        foreach($error as $err){
          echo "-".$err."<br>";
        }
      }else{
            if($img['type'] == 'image/jpeg'){
                $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
                $larguta_original = imagesx($imagem_temporaria);
                $altura_original = imagesy($imagem_temporaria);
                $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
                $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
                $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
                imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
                preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
                $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
                $imagem_dir = "img/" . $imagem_nome;
                $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
                  if(imagejpeg($imagem_redimensionada,'../upload/'.$imagem_nome)){
                    $sql = "insert into  aprovacao(nome,nome_mercado,valor,imagem,categoria,pais,estado,cidade,bairro,descricao,data_cad,palavras_chaves)values('$nome','$nome_mercado',$preco,'$imagem_nome','$categoria','$pais','$estado','$cidade','$bairro','$comentario',now(),'$palavras_chaves')";
                    mysqli_query($conexao,$sql);
                    $aviso = "Cadastro feito com sucesso!!";
                  }else{
                    $aviso = "Erro no cadastramento!\\nTente Novamente!";
                  }
              }elseif($img['type'] == 'image/png'){
                  $imagem_temporaria = imagecreatefrompng($_FILES['img_foto']['tmp_name']);
                  $larguta_original = imagesx($imagem_temporaria);
                  $altura_original = imagesy($imagem_temporaria);
                  $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
                  $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
                  $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
                  imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
                  preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
                  $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
                  $imagem_dir = "img/" . $imagem_nome;
                  $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
                if(imagepng($imagem_redimensionada,'../upload/'.$imagem_nome)){
                  $sql = "insert into aprovacao(nome,nome_mercado,valor,imagem,categoria,pais,estado,cidade,bairro,descricao,data_cad,palavras_chaves)values('$nome','$nome_mercado','$preco','$imagem_nome','$categoria','$pais','$estado','$cidade','$bairro','$comentario',now(),'$palavras_chaves')";
                  mysqli_query($conexao,$sql);
                  $aviso = "Cadastro feito com sucesso!!";
                }else{
                  $aviso = "Erro no cadastramento!\\nTente Novamente!"; 
                }
            }
          }
    }
    echo '<script>alert("'.$aviso.'");location.href="../adm/adm.php?a=verProdutos";</script>';
  }
?>