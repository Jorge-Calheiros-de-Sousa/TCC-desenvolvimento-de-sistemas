<?php
  include('../conexao/conexao.php');
  include('acao.php');
  include('../funcoes_tratamento/funcoes.php');
  if($_SESSION['login'] == 0){
    header('Location: ./');
  }
  $pg = isset($_GET['pag'])?$_GET['pag']:1;
  $qunt_pagina=8;
  $inicio = ($qunt_pagina * $pg)-$qunt_pagina;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ADM</title>
  <script src="../js.js"></script>
  <link rel="stylesheet" href="../css/adm.css">
  <link rel="shortcut icon" href="../img/fivicon.png"> 
</head>
<body>
  <div class='bg' id='bg'>
    .
  </div>
  <header>
    (adm)
    <br>  
      <nav>
        <ul>
          <li onclick="location.href='adm.php'">Inicio</li>
          <li  onclick="location.href='?a=verProdutos'">Produtos</li>
          <li  onclick="location.href='?a=Aprovacao'">Aprovação</li>
          <li onclick="location.href='?a=Mudancas'">Sugestões de mudanças de preços</li>
          <li  onclick="location.href='?a=showCategorias'">Categorias</li>
          <li onclick="location.href='?a=words'">Palavras das categorias</li>
          <li onclick="location.href='./logout.php'">Sair</li>
        </ul>
      </nav>
      <br>
  </header>
  <br>
  <div class = "container_mostrar">
    <?php
      if($a=='verProdutos' && $a2==''){
        echo "
        <br>
          <div class='taxonomia'>
            <strong><a href='?a=verProdutos'>Produtos</a></strong>
          <div>
        ";
        if($texto != 'none'){
          $sql = $texto;
        }else{
          $sql = "select id_produtos,data_cad, nome_produtos,categoria,nome FROM produtos 
          INNER JOIN nome_categorias ON produtos.categoria = nome_categorias.id order by data_cad desc limit $inicio,$qunt_pagina";
        }
        $id_categoria=isset($_GET['categoria'])?$_GET['categoria']:'';
        if($id_categoria !=''){
          $sql = "select id_produtos,data_cad, nome_produtos,categoria,nome FROM produtos 
          INNER JOIN nome_categorias ON produtos.categoria = nome_categorias.id where categoria=$id_categoria order by data_cad desc limit $inicio,$qunt_pagina";
        }
        $result = mysqli_query($conexao,$sql);
        $row = mysqli_num_rows($result);
        if($row == 0){
          echo "<strong>Sem produtos cadastrados</strong>";
        }else{
          echo "
          <br>
            <div class='select'>
            <form action='' method='post'>
              <input type='text' name='select' id='select' autocomplete = 'off'>
              <button type='submit'>Ver</button>
            </form>
            </div>
          <br>
          <table>
            <tr>
              <th>id</th>
              <th>Data</th>
              <th>Nome</th>
              <th>Categoria</th>
              <th>Acoes</th>
            </tr>
            ";
          while($row=$result->fetch_array()){
            $id = $row['id_produtos'];
            $data = $row['data_cad'];
            $nome = $row['nome_produtos'];
            $categoria =  $row['nome'];
            $data = tratar_data($data);
            echo "
            <tr>
              <td>$id</td>
              <td>$data</td>
              <td>$nome</td>
              <td>$categoria</td>

             <td>
             <div class='acoes'>
             <button class = 'excluir'onclick=' direcionar(2,$id)'>Excluir</button>
             <button class='editar' onclick='direcionar(3,$id)'>Editar</button>
             <button class='ver' onclick='direcionar(4,$id)'>Ver</button>
            </div>
             </td>
            </tr>
            ";
          }
          echo "</table>";
          if($id_categoria!=''){
            $select="select * from produtos where categoria=$id_categoria";
          }else{
            $select="select * FROM produtos ";
          }
          $consulta=mysqli_query($conexao,$select);
          $linha=mysqli_num_rows($consulta);
          echo"
            <div class='paginacao' id='paginacao'>
              <div class='primeiro' id='primeiro'><img src='../img/simbolo-de-setas-duplas.png' alt=''></div>
              <div class='anterior'id='anterior'><img src='../img/seta-direita.png' alt=''></div>
              <div class='container_number' id='numbers'>
                <div class='numbers_style'>1</div>
              </div>
              <div class='proximo'id='proximo'><img src='../img/seta-direita.png' alt=''></div>
              <div class='ultimo'id='ultimo'><img src='../img/simbolo-de-setas-duplas.png' alt=''></div>
            </div>
            <script>
              paginacao($linha);
            </script>
            <br>
            ";
        }
      }elseif($a=='verProdutos' &&  $a2=='ver'){
        $id =isset($_GET['id'])? $_GET['id']:'';
        $sql = "select * from produtos where id_produtos=$id";
        $result = mysqli_query($conexao,$sql);
        $array = mysqli_fetch_assoc($result);
        $nome = $array['nome_produtos'];
        $marca=$array['Marca'];
        $nome_mercado = $array['nome_mercado'];
        $valor = $array['valor'];
        $img = $array['imagem'];
        $categoria =  $array['categoria'];
        $descricao = $array['descricao'];
        $data = $array['data_cad'];
        $data= tratar_data($data);
        $palavras_chaves =  $array['palavras_chaves'];
        $palavras_chaves=explode(" ",$palavras_chaves);
        $espaco = count($palavras_chaves);
        echo"
        <br>
          <div class='taxonomia'>
            <strong><a href='?a=verProdutos'>Produtos</a> / <a href='?a=verProdutos&a2=ver&id=$id'>ver produto $nome</a></strong>
          <div>
        <br>
        <div class='ver'>
          <div class='bloco'>
            <div class='titulo'>
            id:
            </div>
            <div class='conteudo'>
            $id
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Nome:
            </div>
            <div class='conteudo'>
             $nome
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Marca:
            </div>
            <div class='conteudo'>
             $marca
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Nome do mercado
            </div>
            <div class='conteudo'>
             $nome_mercado
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Valor:
            </div>
            <div class='conteudo'>
             $valor
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Imagem:
            </div>
            <div class='conteudo'>
             $img
            <figure>
              <img src='../upload/$img' alt=''>
            </figure>
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Categoria
            </div>
            <div class='conteudo'>
            $categoria
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
              Pais/Estado/cidade
            </div>
            <div class='conteudo'>
            
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Descrição
            </div>
            <div class='conteudo'>
              $descricao
            </div>
          </div>
          <br>
          <div class='bloco'>
          <div class='titulo'>
              Data
          </div>
            <div class='conteudo'>
              $data
            </div>
          </div>
          <br>
          <div class='bloco'>
            <div class='titulo'>
            Palavras_chaves
            </div>
            <div class='conteudo'>
            ";
              for ($i=0; $i <$espaco; $i++){
                echo" 
              <div class='tags'>";
                echo $palavras_chaves[$i];
                echo "
              </div>";
              }
              echo"
            </div>
          </div>
        </div>
        <br>
        ";
      }elseif($a=='verProdutos' && $a2=='editar'){
        $id =isset($_GET['id'])? $_GET['id']:'';
        $sql = "select * from produtos where id_produtos=$id";
        $result = mysqli_query($conexao,$sql);
        $array = mysqli_fetch_assoc($result);
        $img = $array['imagem'];
        $nome = $array['nome_produtos'];
        $marca=$array['Marca'];
        $nome_mercado = $array['nome_mercado'];
        $categoria=$array['categoria'];
        $coment = $array['descricao'];
        $preco = $array['valor'];
        $pais = ($array['pais']!='')?$array['pais']:'Pais nao informado';
        $estado = ( $array['estado']!='')? $array['estado']:'Estado não informado';
        $cidade = ($array['cidade']!='')?$array['cidade']:'Cidade não informada';
        $bairro = ($array['bairro']!='')?$array['bairro']:'Bairro nao informado';
        $palavras_chaves =  $array['palavras_chaves'];
        $palavras_chaves=explode(" ",$palavras_chaves);
        $espaco = count($palavras_chaves);
        $data= $array['data_cad'];
  
        echo"
        <br>
          <div class='taxonomia'>
            <strong><a href='?a=verProdutos'>Produtos</a> /  <a href='?a=verProdutos&a2=editar&id=$id'>Editar produto $nome </a></strong>
          <div>
        <br>
        <div class='ver'>
          <form action='?a=modificar&id=$id&img=$img' method='post' onsubmit = 'return validar_modificar()'       enctype='multipart/form-data'>
            <div class='bloco'>
              <div class='titulo'>
                id:
              </div>
              <div class='conteudo'>
                $id
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Nome:
              </div>
              <div class='conteudo'>
                $nome
              </div>
              <div class='perdir_para_modificar' onclick='abre_modificar(1)' id='perdir_para_modificar'>
                Deseja modificar o nome?
              </div>
              <div class='modificar_input' id='modificar_nome'>
                <input type='text' name='nome' id='nome_modi' autocomplete='off' class='nome_modi'>
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Marca:
              </div>
              <div class='conteudo'>
                $marca
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Nome do mercado
              </div>
              <div class='conteudo'>
                $nome_mercado
              </div>
              <div class='perdir_para_modificar' onclick='abre_modificar(2)' id='perdir_para_modificar_mercado'>
                Deseja modificar o mercado?
              </div>
              <div class='modificar_input'  id='modificar_mercado'>
                <input type='text' name='mercado' id='mercado' autocomplete='off'  class='nome_modi'>
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Valor:
              </div>
              <div class='conteudo'>
                $preco
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Imagem:
              </div>
              <div id='nome_img'>
                $img
              </div>
              <br>
              <div class='conteudo'>
                <figure id='container_figure'>
                  <img src='../upload/$img' alt=''  id='img_figure' width='300'  height = '300'>
                </figure>
                  <div class='btns_ajustar'>
                    <div class='form_ajuste'>
                      <div class='titulo_ajustar'>
                        Trocar Imagem
                      </div>
                      <input type='file' name='img_foto' id='imagem' onchange='trocarImg()'>
                      <br>
                      <br>
                      <button type='submit' class='salvar_btn' id='salvar_btn'>Salvar</button>
                    </div>
                    <div class='ajuste_rotacao'>
                        <div class='titulo_ajustar'>
                          Rodar
                        </div>
                        ";
                          for ($i=0; $i < 360 ; $i+=90) {
                            echo"
                        <label for='$i deg'>$i</label>
                        <input type='radio' id='$i deg'name='rotacao' onclick='ajustar_img($i)' value='$i'>
                        <br>
                        ";
                        }
                        echo "
                    </div>
                    <br>
                    <button onclick='ajustar_img(2)'>Cortar</button>
                  </div>
                </div>
                <br>
              </div>
              <br>
            <div class='bloco'>
              <div class='titulo'>
                Categoria
              </div>
              <div class='conteudo'>
                $categoria
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Pais/Estado/cidade
              </div>
              <div class='conteudo'>
                $pais / $estado / $cidade / $bairro
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Descrição
              </div>
              <div class='conteudo'>
                  $coment
              </div>
              <div class='perdir_para_modificar' onclick='abre_modificar(3)' id='perdir_para_modificar_texto'>
                Deseja modificar a descrição?
              </div>
              <div class='modificar_input' id='modificar_texto'>
                  <textarea name='texto_corrigido' id='modi_descricao' cols='30' rows='10' maxlength='500'>

                  </textarea>
              </div>
            </div>
            <br>
            <div class='bloco'>
              <div class='titulo'>
                Data
              </div>
              <div class='conteudo'>
                $data
              </div>
            </div>
            <br>
            <div class='bloco'>
                <div class='titulo'>
                  Palavras chaves
                </div>
                <div class='conteudo'>
                  ";
                    for ($i=0; $i <$espaco; $i++){
                      echo"
                    <div class='tags' id='tags'>
                    ";
                      echo $palavras_chaves[$i];
                      echo"
                    </div> ";
                    }
                    echo"
                </div>
                <div class='perdir_para_modificar' onclick='abre_modificar(4)'id='perdir_para_modificar_palavras'>
                  Deseja modificar as palavras chaves?
                </div>
                <div class='modificar_input'  id='modificar_palavras'>
                  <div class = 'container'>
                    <input type='text' name = 'palavras' id = 'palavras' class='input_tags' autocomplete = 'off'><span class = 'add' onclick = 'tecla_chave()'>+</span><span class='reset'onclick = 'reset()'>Reset</span>
                    <div class = 'tag_container' id='tag_container'>
                        
                    </div>
                  </div>
                </div>
            </div>
            <br>
            <br>
            <div class='btn_submit_editar'>
              <input type='submit' value='Modificar'>
            </div>
          </form>
        </div>
        ";
      }elseif($a == 'verProdutos' && $a2 == 'excluir'){
        $id = $_GET['id'];
        echo "
        <div class = 'excluir_certeza'>
          <div class='texto_excluir'>
            deseja excluir mesmo?
          </div>
          <hr>
          <br>
          <div class='btns_excluir'>
            <button class='excluir' onclick = 'direcionar(6,$id)'>Excluir</button>
            <button onclick = ".'location.href="?a=verProdutos"'.">Cancelar</button>
          </div>
        </div>
        ";
      }elseif($a=='Aprovacao' && $a2 == ''){
        echo"
        <br>
        <div class='taxonomia'>
          <strong> <a href='?a=Aprovacao'>Aprovacão</a></strong>
        <div>
        ";
        if($texto != 'none'){
          $sql = $texto;
        }else{
          $sql = "select * from aprovacao INNER JOIN nome_categorias ON aprovacao.categoria = nome_categorias.id order by data_cad asc";
        }
        $result = mysqli_query($conexao,$sql);
        $row = mysqli_num_rows($result);
        if($row == 0){
          echo "<strong>Sem produtos cadastrados</strong>";
        }else{
          echo "
          <br>
          <div class='select'>
          <form action='' method='post'>
            <input type='text' name='select' id='select' autocomplete = 'off'>
            <button type='submit'>Ver</button>
          </form>
          </div>
          <br>
          <table>
            <tr>
              <th>id</th>
              <th>Data</th>
              <th>Nome</th>
              <th>Categoria</th>
              <th>Acoes</th>
            </tr>
            ";
          while($row=$result->fetch_array()){
            $id = $row['id_aprovacao'];
            $data = $row['data_cad'];
            $data = tratar_data($data);
            $nome = $row['nome_aprovacao'];
            $categoria =  $row['nome'];
            $id_categoria=$row['id'];
  
            echo "
            <tr>
              <td>$id</td>
              <td>$data</td>
              <td>$nome</td>
              <td>$categoria</td>
             <td>
             <div class='acoes'>
             <button class='ver' onclick='direcionar(5,$id)'>Ver</button>
             <button onclick = 'direcionar(12,$id)'>Inserir palavra na categoria</button>
            </div>
             </td>
            </tr>
          ";
          }
          echo"
          </table>
          ";
        }
      }elseif($a=='Aprovacao' && $a2=='ver'){
        $id =isset($_GET['id'])? $_GET['id']:'';
        $sql = "select * from aprovacao where id_aprovacao=$id";
        $result = mysqli_query($conexao,$sql);
        $array = mysqli_fetch_assoc($result);
        $img = $array['imagem'];
        $nome = $array['nome_aprovacao'];
        $nome_marca=$array['marca'];
        $nome_mercado = $array['nome_mercado'];
        $categoria=$array['categoria'];
        $coment = $array['descricao'];
        $preco = $array['valor'];
        $pais = ($array['pais']!='')?$array['pais']:'Pais nao informado';
        $estado = ( $array['estado']!='')? $array['estado']:'Estado não informado';
        $cidade = ($array['cidade']!='')?$array['cidade']:'Cidade não informada';
        $bairro = ($array['bairro']!='')?$array['bairro']:'Bairro nao informado';
        $data= $array['data_cad'];
        $palavras_chaves =  $array['palavras_chaves'];
        $palavras_chaves=explode(" ",$palavras_chaves);
        $espaco = count($palavras_chaves);

        echo"
        <br>
          <div class='taxonomia'>
            <strong><a href='?a=Aprovacao'>Aprovacão</a> / <a href=''>ver produto $nome</a></strong>
          <div>
        <br>
        <div class='ver'>
          <form action='?a=modificarAprovacao&id=$id&img=$img' method='post'  onsubmit = 'return validar_modificar()'  enctype='multipart/form-data'>
              <div class='bloco'>
                <div class='titulo'>
                id:
                </div>
                <div class='conteudo'>
                 $id
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                  Nome:
                </div>
                <div class='conteudo'>
                  $nome
                </div>
                <div class='perdir_para_modificar' onclick='abre_modificar(1)' id='perdir_para_modificar'>
                  Deseja modificar o nome?
                </div>
                <div class='modificar_input' id='modificar_nome'>
                  <input type='text' name='nome' id='nome_modi' autocomplete='off' class='nome_modi'>
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                Marca
                </div>
                <div class='conteudo'>
                $nome_marca
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                  Nome do mercado
                </div>
                <div class='conteudo'>
                  $nome_mercado
                </div>
                <div class='perdir_para_modificar' onclick='abre_modificar(2)' id='perdir_para_modificar_mercado'>
                  Deseja modificar o mercado?
                </div>
                <div class='modificar_input'  id='modificar_mercado'>
                  <input type='text' name='mercado' id='mercado' autocomplete='off'  class='nome_modi'>
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                  Valor:
                </div>
                <div class='conteudo'>
                  $preco
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                  Imagem:
                </div>
                <div id='nome_img'>
                $img
                </div>
                <br>
                <div class='conteudo'>
                  <figure id='container_figure'>
                    <img src='../upload/$img' alt=''  id='img_figure' width='300'  height = '300'>
                  </figure>
                    <div class='btns_ajustar'>
                      <div class='form_ajuste'>
                        <div class='titulo_ajustar'>
                          Trocar Imagem
                        </div>
                        <input type='file' name='img_foto' id='imagem' onchange='trocarImg()'>
                        <br>
                        <br>
                        <button type='submit' class='salvar_btn' id='salvar_btn'>Salvar</button>
                      </div>
                      <div class='ajuste_rotacao'>
                          <div class='titulo_ajustar'>
                            Rodar
                          </div>
                          ";
                            for ($i=0; $i < 360 ; $i+=90) {
                              echo"
                          <label for='$i deg'>$i</label>
                          <input type='radio' id='$i deg'name='rotacao' onclick='ajustar_img($i)' value='$i'>
                          <br>
                          ";
                          }
                          echo "
                      </div>
                      <br>
                      <button onclick='ajustar_img(2)'>Cortar</button>
                    </div>
                  </div>
                  <br>
                </div>
                <br>
              <div class='bloco'>
                <div class='titulo'>
                  Categoria
                </div>
                <div class='conteudo'>
                  $categoria
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                  Pais/Estado/cidade
                </div>
                <div class='conteudo'>
                  $pais / $estado / $cidade / $bairro
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                  Descrição
                </div>
                <div class='conteudo'>
                    $coment
                </div>
                <div class='perdir_para_modificar' onclick='abre_modificar(3)' id='perdir_para_modificar_texto'>
                  Deseja modificar a descrição?
                </div>
                <div class='modificar_input' id='modificar_texto'>
                    <textarea name='texto_corrigido' id='modi_descricao' cols='30' rows='10' maxlength='500'>
  
                    </textarea>
                </div>
              </div>
              <br>
              <div class='bloco'>
                <div class='titulo'>
                  Data
                </div>
                <div class='conteudo'>
                  
                </div>
              </div>
              <br>
              <div class='bloco'>
                  <div class='titulo'>
                    Palavras chaves
                  </div>
                  <div class='conteudo'>
                    ";
                      for ($i=0; $i <$espaco; $i++){
                        echo"
                      <div class='tags' id='tags'>
                      ";
                        echo $palavras_chaves[$i];
                        echo"
                      </div> ";
                      }
                      echo"
                  </div>
                  <div class='perdir_para_modificar' onclick='abre_modificar(4)'id='perdir_para_modificar_palavras'>
                    Deseja modificar as palavras chaves?
                  </div>
                  <div class='modificar_input'  id='modificar_palavras'>
                    <div class = 'container'>
                      <input type='text' name = 'palavras' id = 'palavras' class='input_tags' autocomplete = 'off'><span class = 'add' onclick = 'tecla_chave()'>+</span><span class='reset'onclick = 'reset()'>Reset</span>
                      <div class = 'tag_container' id='tag_container'>
                          
                      </div>
                    </div>
                  </div>
              </div>
              <br>
              <br>
              <div class='btn_submit_editar'>
                <input type='submit' value='Modificar'>
              </div>
              <br>
          </form>
          <div class='btns_aprovar'>
          <button class='aprovar' onclick='direcionar(7,$id)'>Aprovar</button>
          <button class='repro'onclick='direcionar(8,$id)'>Reprovado</button>
        </div>
        <br>
        </div>
        ";
      }elseif($a=='Mudancas' && $a2==''){
        echo"
        <br>
        <div class='taxonomia'>
          <strong> <a href='?a=Mudancas'>Mudanças de preços</a></strong>
        <div>
        ";
        $sql="select * from mudancas order by id desc";
        $result = mysqli_query($conexao,$sql);
        $row = mysqli_num_rows($result);
        if($row == 0){
          echo "<strong>Sem produtos cadastrados</strong>";
        }else{
          echo "
          <br>
            <div class='select'>
            <form action='' method='post'>
              <input type='text' name='select' id='select' autocomplete = 'off'>
              <button type='submit'>Ver</button>
            </form>
            </div>
          <br>
          <table>
            <tr>
              <th>id</th>
              <th>id_produto</th>
              <th>Novo preco</th>
            </tr>
            ";
          while($row=$result->fetch_array()){
            $id = $row['id'];
            $id_produto = $row['id_produto'];
            $novo_preco = $row['novo_preco'];
            echo "
            <tr>
              <td>$id</td>
              <td>$id_produto</td>
              <td>$novo_preco</td>

             <td>
             <div class='acoes'>
             <button class = 'excluir'onclick=' direcionar(9,$id_produto)'>ver produto</button>
             <button class='editar' onclick='direcionar(10,$id_produto,$novo_preco,$id)'>trocar</button>
             <button class='ver' onclick='direcionar(11,$id)'>rejeitar</button>
            </div>
             </td>
            </tr>
            ";
          }
          echo "</table>";
        }
      }elseif($a=='showCategorias'){
        $sql="select * from nome_subcategorias join categorias on nome_subcategorias.nome_visual = categorias.id_categorias";
       $resutado = mysqli_query($conexao,$sql);
       $texto="add_categoria";
       echo "
       <br>
        <div class='taxonomia'>
          <strong><a href='?a=showCategorias'>Categorias e subcategorias</a></strong>
        <div>
       <div class='container_categoria'>
         <div class='indicadores'>
          <div class='add_categoria'>
            <div class='table_titulo'>
              Categorias
            </div>
            <div class='add_categoria1' onclick='mostrar_categoria(`$texto`)'>
                Adicionar categoria +
            </div>
          </div>
          <div class='table_values'>
            subcategorias
          </div>
         </div>
         <br>
        ";
        while($row=mysqli_fetch_assoc($resutado)){
          $nome=$row['categoria'];
          $id_categoria_mostrar=$row['id_categorias'];
          $subcategoria=$row['nome_subcategorias'];
          $cod="select * from $subcategoria";
          $consulta=mysqli_query($conexao,$cod);
          echo"
          <div class='container_subcategorias'>
            <div class='table_titulo' onclick='mostrar_categoria($id_categoria_mostrar)'>
                $nome 
            </div>
            ";
            while($array=mysqli_fetch_assoc($consulta)){
              $categorias=$array['sub_categoria'];
              $categorias_nome=str_replace(" ","_",$categorias);
              $id=$array['id'];
              echo"
              <div class='table_values' onclick=abrir_categoria_adm(`$subcategoria`,$id,`$categorias_nome`)>
                $categorias
              </div>
              ";
            }
            echo"
            <div class='add_categoria'>
              <form action='?a=criar_categoria&&subcategoria=$subcategoria' method='post'>
                <input type='text' name='categoria' id='categoria' autocomplete='off' required><br>
                <button>ADD</button>
              </form>
            </div>
          </div>
          ";
        }
        echo"
       </div>
       ";
      }elseif($a=='words'){
        if($a2=='pesquisa'){
          $nome=$_POST['nome'];
          $sql="select * from nome_categorias where nome like '%$nome%'";
        }else{
          $sql="select * from nome_categorias";
        }
        $consulta=mysqli_query($conexao,$sql);
        echo"
        <br>
          <div class='taxonomia'>
            <strong><a href='?a=words'>Palavras das subcategorias</a></strong>
          <div>
        <div class='container_form_palavras'>
          <form action='?a=words&a2=pesquisa' method='post'>
            <input type='text' name='nome' id='nome' autocomplete='off'>
            <button>Pesquisar</button>
          </form>
        </div>
        <div class='indicadores_palavras'>
            Subcategorias
        </div>
        ";
        while($row=mysqli_fetch_assoc($consulta)){
          $titulo=$row['nome'];
          $segundo_titulo=str_replace(' ','_',$titulo);
          $word=$row['palavras_categoria'];
          $id_categoria=$row['id'];
          $word=explode(",",$word);
          echo"
          <div class='container_words'>
            <div class='titulo'>
              $titulo
            </div>
            <button class='btn_mostrar' onclick='direcionar(13,$id_categoria)'>
              Mostrar palavras
            </button>
            ";
            $n=count($word);
            echo"
            </div>
            ";
        }
      }elseif($a=='palavra_categoria'&&$a2==''){
        $id=$_GET['id_categoria'];
        $sql="select * from nome_categorias where id=$id";
        $consulta=mysqli_query($conexao,$sql);
        if($row=mysqli_num_rows($consulta) > 0){
          $array=mysqli_fetch_assoc($consulta);
          $titulo=$array['nome'];
          $word=$array['palavras_categoria'];
          $word=explode(",",$word);
          $num="";
          $n=count($word);
          echo"
          <br>
          <div class='taxonomia'>
            <strong><a href='?a=words'>Palavras das subcategorias</a> / <a href='?a=palavra_categoria&id_categoria=$id'>ver todas</a></strong>
          <div>
          <div class='container_words'>
          <form action='?a=form_inserir_palavra&a2=$id' method='post' onsubmit='return validar_add_palavras()' autocomplete='off'>
            Adicione um nova palava: <input type='text' name='palavra' id='palavra'  maxlength='50'><div class='btn_add'><button>Add</button></div>
          </form>
            <div class='titulo'>
              $titulo
            </div><br>
          ";
          for ($i=0; $i < $n ; $i++) {
            $palavra=$word[$i];
            if($palavra==""){

            }else{
              echo"
              <div class='words'>
                 <div id='divb$i' class='words1'>$palavra</div>
                 <div class='btn_x' id='div$i'>X</div>
              </div>
              ";
              $num++;
            }
          }
        }
        echo "
          <script>
          delete_word($num,$id);
          </script>
        ";
      }elseif($a=='subcategorias_mostrar' && $a2==''){
        $subcategoria=$_GET['subcategoria'];
        $id=$_GET['id'];
        $nome_categoria=$_GET['categoria'];
        $nome_categoria=str_replace("_"," ",$nome_categoria); 
        if(isset($nome_categoria)){
          $select="select * from referencia_nome_tables where subcategoria = '$nome_categoria'";
          if($consulta=mysqli_query($conexao,$select)){
            $array=mysqli_fetch_assoc($consulta);
            $id_referencia=$array['nome_categoria_referencia'];
          }
        }
        $sql="select * from $subcategoria where id=$id";
        $consulta = mysqli_query($conexao,$sql);
        $array=mysqli_fetch_assoc($consulta);
        $nome=$array['sub_categoria'];
        $img=$array['img_categoria'];
        echo "
        <br>
          <div class='taxonomia'>
            <strong><a href='?a=showCategorias'>Categorias e subcategorias</a> / <a href='?a=subcategorias_mostrar&subcategoria=$subcategoria&id=$id&categoria=$nome_categoria'>ver subcategoria $nome</a></strong>
          <div>
        <div class='container_mostrar_categoria'>
          <div class='nome'>
            $nome
          </div>
          <div class='imagem'>
            <figure>
              <img src='../img_categorias/$img' alt=''>
            </figure>
          </div>
          <div class='controles'>
            <div class='container_btn'>
              <button id='mostrar_produtos'>Mostrar produtos dessa categoria</button>
            </div>
            <div class='container_btn'>
              <button id='mostrar_palavras'>Mostrar palavras dessa categoria</button>
            </div>
            <div class='container_btn'>
              <button id='btn_excluir_categoria'>Excluir</button>
            </div>
          </div>
          <div class='confirmar_delete_categoria' id='confirmar_delete_categoria'>
            <h1>Certeza?</h1>
            <br>
            <div class='btn_confirmar'>
              <button id='cancelar'>Cancelar</button>
              <button id='confirmar'>Confirmar</button>
            </div>
          </div>
        </div>
        <script>
          controles($id,`$nome`,`$subcategoria`,$id_referencia);
        </script>
        ";
      }elseif($a=='criar_categoria' && $a2==""){
        $subcategoria=$_GET['subcategoria'];
        $nome=$_POST['categoria'];
        $sql="select * from nome_subcategorias join categorias on nome_subcategorias.nome_visual = categorias.id_categorias  where nome_subcategorias='$subcategoria'";
        $consulta=mysqli_query($conexao,$sql);
        $array=mysqli_fetch_assoc($consulta);
        $array['categoria'];
        $caminho=$array['id_categorias'];
        echo "
        <div class='container_form_add_categoria'>
          <div class='topo'>
            Criar um nova categoira
          </div>
          <br>
          <div class='form_add'>
            <form action='?a=inserir_categoria_database' method='post' onsubmit='return validar_form_categoria()'  enctype='multipart/form-data'>
              <div class='part'>
              <input type='text' name='categoria' id='categoria1' autocomplete='off' value='$nome'>
              <input type='number' name='caminho' id='caminho' autocomplete='off' value='$caminho'>
              <input type='text' name='subcategorias' id='subcategorias' autocomplete='off' value='$subcategoria'>
              $nome
              </div>
              <div class='part container'>
                Insira os nomes de produto em relação a categoria: <input type='text' name = 'palavras' id = 'palavras' class='input_tags' autocomplete = 'off'placeholder='Adicione as palavras chaves para que outras pessoas possam encontrar o produto''><span class = 'add' onclick = 'tecla_chave()'>+</span><span class='reset'onclick = 'reset()'>Reset</span>
                <div class = 'tag_container' id='tag_container'>
          
                </div>
              </div>
              <div class='part'>
              <input type='file' name='img_foto' id='img' onchange = 'preview()' required>
              <div class='preview' id='preview'>
              <img id='img_preview' src='../img/noimage.jpg' alt='' width='200' height='200'>
              </div>
              </div>
              <div class='part'>
                  <input type='submit' value='Criar'>
              </div>
            </form>
          </div>
        </div>
        ";
      }elseif($a=='mostrar_categoria'){
        $id=$_GET['id'];
        if($id !='add_categoria'){
          $sql ="select * from categorias where id_categorias=$id";
          $consulta=mysqli_query($conexao,$sql);
          $array=mysqli_fetch_assoc($consulta);
          echo $img=$array['img'];
          $nome=$array['categoria'];
          echo "
          <br>
            <div class='taxonomia'>
              <strong><a href='?a=showCategorias'>Categorias e subcategorias</a> / <a href='?a=mostrar_categoria&id=$id'>ver categoria $nome</a>
              </strong>
            <div>
          <div class='container_mostrar_categoria'>
            <div class='nome'>
              $nome
            </div>
            <div class='imagem'>
              <figure>
                <img src='../img/$img' alt=''>
              </figure>
            </div>
            <div class='controles'>
            </div>
          <script>
          controles2($id);
          </script>
          ";
        }
      }
    ?>
  </div>
  <br>
</body>
</html>