<?php
  session_start();
  $a = isset($_GET['a'])?$_GET['a']:'';
  $a2 = isset($_GET['a2'])?$_GET['a2']:'';
  $texto = isset($_POST['select'])?$_POST['select']:'none';
  if($a == 'verProdutos' && $a2 == 'true'){
      $id = $_GET['id'];
    if(isset($id)){
      $id;
      $mais_acessados="select * from mais_acessados where id_produto=$id";
      if(mysqli_query($conexao,$mais_acessados)){
        $delete="delete from mais_acessados where id_produto = $id";
        if(mysqli_query($conexao,$delete)){
          $foi_deletado=true;
        }else{
          $foi_deletado=false;
        }
      }else{
        $sql = "select * from produtos where id_produtos = $id";
        if(mysqli_query($conexao,$sql)){
          $resultado = mysqli_query($conexao,$sql);
          $row = mysqli_fetch_assoc($resultado);
          $img = $row['imagem'];
          $foi_deletado=true;
        }
      }
      if($foi_deletado==true){
        $sql = "delete  from  produtos where id_produtos = $id";
        if(mysqli_query($conexao,$sql)){
          unlink("../upload/$img");
          echo '<script>alert("O produto foi deletado");location.href="../adm/adm.php?a=verProdutos";</script>';
        }
      }else{
        $foi_deletado=false;
      }
    }
  }elseif($a=='Aprovacao' && $a2 == 'aprovar'){
    $id = $_GET['id'];
    if(isset($id)){
      $sql = "select * from aprovacao where id_aprovacao = $id";
      $resultado = mysqli_query($conexao,$sql);
      $row = mysqli_fetch_assoc($resultado);
      $nome = $row['nome_aprovacao'];
      $nome_mercado = ($row['nome_mercado']!="")?$row['nome_mercado']:'Mercado nao informado';
      $preco = $row['valor'];
      $marca=$row['marca'];
      $pais = ($row['pais']!='')?$row['pais']:'Pais nao informado';
      $estado = ( $row['estado']!='')? $row['estado']:'Estado não informado';
      $cidade = ($row['cidade']!='')?$row['cidade']:'Cidade não informada';
      $bairro = ($row['bairro']!='')?$row['bairro']:'Bairro nao informado';
      $categoria = $row['categoria'];
      $data = $row['data_cad'];
      $img = $row['imagem'];
      $comentario = $row['descricao'];
      $palavras_chaves = $row['palavras_chaves'];
    }
      $add = "insert into produtos (nome_produtos,nome_mercado,valor,Marca,imagem,categoria,pais,estado,cidade,bairro,descricao,data_cad,palavras_chaves)values('$nome','$nome_mercado',$preco,'$marca','$img','$categoria','$pais','$estado','$cidade','$bairro','$comentario','$data','$palavras_chaves')";
      if(mysqli_query($conexao,$add)){
        $aviso = 'Aprovado';
        /*$email=$_SESSION['email'];
        $assunto = "Aprovado";
        $para = $email;
        $body = "
          O seu comentario sobre o produto foi aprovado e colocado no site
        ";
        $boundary = "XYZ-".date("dmYis")."-ZYX";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: multipart/mixed; ";
        $headers .= "boundary=\"$boundary\"\r\n";
        $headers .= "--$boundary\r\n";

        if(mail($para, $assunto, $body, $headers)){
          $aviso = 'Aprovado';
        }else{
          $aviso = "Não aprovado";
        }
        */
        if($aviso == "Aprovado"){
          $remove = "delete from  aprovacao where id_aprovacao = $id ";
          mysqli_query($conexao,$remove);
          echo '<script>alert("'.$aviso.'");location.href="../adm/adm.php?a=Aprovacao";</script>';
        }
      }
  }elseif($a=='Aprovacao' && $a2 == 'repro'){
      $id = $_GET['id'];
      if(isset($id)){
        $sql = "select * from aprovacao where id_aprovacao = $id";
        $resultado = mysqli_query($conexao,$sql);
        $row = mysqli_fetch_assoc($resultado);
        $img = $row['imagem'];
      }
      $remove = "delete from  aprovacao where id_aprovacao = $id ";
       if(mysqli_query($conexao,$remove)){
       $aviso = "Reprovado";
        unlink("../upload/$img");

        /*$assunto = "Reprovado";
        $para = $email;
        $body = "
          O seu comentario sobre o produto não foi aprovado
        ";
        $boundary = "XYZ-".date("dmYis")."-ZYX";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: multipart/mixed; ";
        $headers .= "boundary=\"$boundary\"\r\n";
        $headers .= "--$boundary\r\n";

        if(mail($para, $assunto, $body, $headers)){
          $aviso = 'Reprovado';
        }else{
          $aviso = "Não aprovado";
        }*/

        echo '<script>alert("'.$aviso.'");location.href="../adm/adm.php?a=Aprovacao";</script>';
      }
  }elseif($a=='upload' && $a2==''){
      $id = isset($_GET['id'])?$_GET['id']:'';
      $img =isset($_FILES['img_foto'])?$_FILES['img_foto']:'';
      $imagem_nome =$_GET['name'];
      $rotacao = isset($_POST['rotacao'])?$_POST['rotacao']:'';
      $largura = "300";
      $altura = "300";
      $config = array();
      $config['tamanho'] =11339870 ;
      $config['largura'] = 300;
      $config['altura'] = 300;
      $error = array();
      if($img && $rotacao == ''){
        unlink("../upload/$imagem_nome");
      if($img['type'] !='image/jpeg' && $img['type'] !='image/png'){
        $error[]= "Arquivo em formato inválido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo";
      }else{
        if($img["size"] > $config["tamanho"]){
          $erro[] = "Arquivo em tamanho muito grande!";
        }
        $tamanhos = getimagesize($img["tmp_name"]);
        if($tamanhos[0]>$config['largura']){
          $erro[] = "Largura da imagem não deve ultrapassar " . $config["largura"] . " pixels";
        }
        if($tamanhos[1] > $config['altura']){
          $erro[] = "Altura da imagem não deve ultrapassar " . $config["altura"] . " pixels";
        }
      }
      if(sizeof($error)){
        foreach($error as $err){
          echo "-".$err."<br>";
        }
      }else{
            if($img['type'] == 'image/jpeg'){
                $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
                $larguta_original = imagesx($imagem_temporaria);
                $altura_original = imagesy($imagem_temporaria);
                $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
                $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
                $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
                imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
                preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
                //$_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, $angulo, 0);
                $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
                  if(imagejpeg($imagem_redimensionada,'../upload/'.$imagem_nome)){
                    $aviso = "A imagem foi trocada com sucesso";
                  }else{
                    $aviso = "Não deu certo, tente denovo";
                  }
                }elseif($img['type'] == 'image/png'){
                  $imagem_temporaria = imagecreatefrompng($_FILES['foto']['tmp_name']);
                  $larguta_original = imagesx($imagem_temporaria);
                  $altura_original = imagesy($imagem_temporaria);
                  $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
                  $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
                  $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
                  imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
                  preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
                  $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
                  if(imagepng($imagem_redimensionada,'../upload/'.$imagem_nome)){
                    $aviso = "A imagem foi trocada com sucesso";
                }
              }
            }
        }elseif($rotacao!=''){
          /*if($img['type'] == 'image/jpeg'){
            $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
            $larguta_original = imagesx($imagem_temporaria);
            $altura_original = imagesy($imagem_temporaria);
            $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
            $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
            $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
            imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
            preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
            $_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, -$rotacao, 0);
            $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
              if(imagejpeg( $_Imagem_Rotacionada,'../upload/'.$imagem_nome)){
                $aviso = "A imagem foi rotacionada com sucesso";
              }else{
                $aviso = "Não deu certo, tente denovo";
              }
            }elseif($img['type'] == 'image/png'){
              $imagem_temporaria = imagecreatefrompng($_FILES['foto']['tmp_name']);
              $larguta_original = imagesx($imagem_temporaria);
              $altura_original = imagesy($imagem_temporaria);
              $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
              $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
              $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
              imagecopyresampled(  $_Imagem_Rotacionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
              preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
              $_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, $rotacao, 0);
              $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
              if(imagepng($_Imagem_Rotacionada,'../upload/'.$imagem_nome)){
                $aviso = "Não deu certo, tente denovo";
            }
          }*/
        }
        echo '<script>alert("'.$aviso.'");location.href="?a=Aprovacao"</script>';
  }elseif($a=='modificar' && $a2==''){
    $id = isset($_GET['id'])?$_GET['id']:'';
    $nome = isset($_POST['nome'])?$_POST['nome']:'';
    $mercado = isset($_POST['mercado'])?$_POST['mercado']:'';
    $descricao = $_POST['texto_corrigido'];
    $palavras_chaves = isset($_POST['palavras'])?$_POST['palavras']:'';
    $palavras_chaves = str_replace('.',' ',$palavras_chaves);
    $rotacao = isset($_POST['rotacao'])?$_POST['rotacao']:'';
    $imagem_nome = $_GET['img'];
    $img = isset($_FILES['img_foto'])? $_FILES['img_foto'] : 'nada';
    $sql='';
    $largura = "300";
    $altura = "300";
    
    if($nome == '' && $mercado == "" && $descricao == '' && $palavras_chaves == ''&& $rotacao == ''){
      $sql="";
      $aviso='O produto nao foi modificado';
    }elseif($nome != '' && $mercado != "" && $descricao != '' && $palavras_chaves != ''){
    $sql = "update aprovacao set nome_produtos='$nome',nome_mercado='$mercado', descricao='$texto', palavras_chaves='$palavras_chaves' where  id_produtos=$id";
    }elseif($nome != ''){
      $sql = "update  produtos set nome_produtos='$nome' where  id_produtos=$id";
    }elseif($nome != '' && $mercado != ""){
        $sql = "update produtos set nome_produtos='$nome',nome_mercado='$mercado' where  id_produtos=$id";
    }elseif($nome != '' && $mercado != "" &&  $descricao != ''){
      $sql = "update  produtos  set nome_produtos='$nome',nome_mercado='$mercado', descricao='$texto' where  id_produtos=$id";
    }elseif( $mercado != ""){
      $sql = "update  produtos  set nome_mercado='$mercado' where  id_produtos=$id";
    }elseif($palavras_chaves != ''){
      $sql = "update produtos  set palavras_chaves='$palavras_chaves' where id_produtos=$id";
    }

    if($rotacao !='' && $img['name']!=''){
      if(isset($imagem_nome)){
        unlink("../upload/$imagem_nome");
        }
      if($img['type']=='image/jpeg'){
        $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
        $larguta_original = imagesx($imagem_temporaria);
        $altura_original = imagesy($imagem_temporaria);
        $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
        $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
        $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
        imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
        $_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, -$rotacao, 0);
        $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
          if(imagejpeg( $_Imagem_Rotacionada,'../upload/'.$imagem_nome)){
            $aviso = "A imagem foi rotacionada com sucesso";
          }else{
            $aviso = "Não deu certo, tente denovo";
          }
      }elseif($img['type'] == 'image/png'){
        $imagem_temporaria = imagecreatefrompng($_FILES['img_foto']['tmp_name']);
        $larguta_original = imagesx($imagem_temporaria);
        $altura_original = imagesy($imagem_temporaria);
        $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
        $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
        $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
        imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
        $_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, -$rotacao, 0);
        $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
        if(imagepng($_Imagem_Rotacionada,'../upload/'.$imagem_nome)){
          $aviso = "A imagem foi rotacionada com sucesso";
        }else{
          $aviso = "Não deu certo, tente denovo";
        }
      }
    }elseif($img['name'] != '' && $rotacao ==''){
      if(isset($imagem_nome)){
        unlink("../upload/$imagem_nome");
      }
      if($img['type'] == 'image/jpeg'){
        $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
        $larguta_original = imagesx($imagem_temporaria);
        $altura_original = imagesy($imagem_temporaria);
        $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
        $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
        $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
        imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
        //$_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, $angulo, 0);
        $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
        if(imagejpeg($imagem_redimensionada,'../upload/'.$imagem_nome)){
          $aviso = "A imagem foi trocada com sucesso";
        }else{
          $aviso = "Não deu certo, tente denovo";
        }
      }elseif($img['type'] == 'image/png'){
        $imagem_temporaria = imagecreatefrompng($_FILES['foto']['tmp_name']);
        $larguta_original = imagesx($imagem_temporaria);
        $altura_original = imagesy($imagem_temporaria);
        $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
        $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
        $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
        imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
        $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
        if(imagepng($imagem_redimensionada,'../upload/'.$imagem_nome)){
          $aviso = "A imagem foi trocada com sucesso";
        }
      }
    }
    if($sql!=''){
      echo $sql;
      mysqli_query($conexao,$sql);
      $aviso = "O produto foi modificado com sucesso";
    }
    echo '<script>alert("'.$aviso.'");location.href="?a=verProdutos"</script>';
  }elseif($a=='modificarAprovacao' && $a2==''){
      $sql='';
      $id = isset($_GET['id'])?$_GET['id']:'';
      $nome = isset($_POST['nome'])?$_POST['nome']:'';
      $mercado = isset($_POST['mercado'])?$_POST['mercado']:'';
      $descricao =isset($_POST['texto_corrigido'])?$_POST['texto_corrigido']:'';
      $palavras_chaves = isset($_POST['palavras'])?$_POST['palavras']:'';
      $palavras_chaves = str_replace('.',' ',$palavras_chaves);
      $rotacao = isset($_POST['rotacao'])?$_POST['rotacao']:'';
      $imagem_nome = $_GET['img'];
      $img =isset($_FILES['img_foto'])?$_FILES['img_foto']:'';
      $largura = "300";
      $altura = "300";
      
      if($nome == '' && $mercado == "" && $descricao == '' && $palavras_chaves == ''&& $rotacao == ''){
        $sql="";
        $aviso='O produto nao foi modificado';
      }elseif($nome != '' && $mercado != "" && $descricao != '' && $palavras_chaves != ''){
      $sql = "update aprovacao set nome_aprovacao='$nome',nome_mercado='$mercado', descricao='$texto', palavras_chaves='$palavras_chaves' where id_aprovacao=$id";
      }elseif($nome != ''){
        $sql = "update  aprovacao  set nome_aprovacao='$nome' where id_aprovacao=$id";
      }elseif($nome != '' && $mercado != ""){
          $sql = "update  aprovacao  set nome_aprovacao='$nome',nome_mercado='$mercado' where id_aprovacao=$id";
      }elseif($nome != '' && $mercado != "" &&  $descricao != ''){
        $sql = "update  aprovacao  set nome_aprovacao='$nome',nome_mercado='$mercado', descricao='$texto' where id_aprovacao=$id";
      }elseif( $mercado != ""){
        $sql = "update  aprovacao  set nome_mercado='$mercado' where id_aprovacao=$id";
      }elseif($palavras_chaves != ''){
        $sql = "update  aprovacao  set palavras_chaves='$palavras_chaves' where id_aprovacao=$id";
      }elseif($rotacao !=''){
        $caminho_para_arquivo="../upload/$imagem_nome";
        if(file_exists($caminho_para_arquivo)){
          unlink("../upload/$imagem_nome");
        }
        if($img['type'] == 'image/jpeg'){
          $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
          $larguta_original = imagesx($imagem_temporaria);
          $altura_original = imagesy($imagem_temporaria);
          $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
          $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
          $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
          imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
          preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
          $_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, -$rotacao, 0);
          $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
            if(imagejpeg( $_Imagem_Rotacionada,'../upload/'.$imagem_nome)){
              $aviso = "A imagem foi rotacionada com sucesso";
            }else{
              $aviso = "Não deu certo, tente denovo";
            }
         }elseif($img['type'] == 'image/png'){
            $imagem_temporaria = imagecreatefrompng($_FILES['img_foto']['tmp_name']);
            $larguta_original = imagesx($imagem_temporaria);
            $altura_original = imagesy($imagem_temporaria);
            $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
            $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
            $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
            imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
            preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
            $_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, -$rotacao, 0);
            $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
            if(imagepng($_Imagem_Rotacionada,'../upload/'.$imagem_nome)){
              $aviso = "A imagem foi rotacionada com sucesso";
            }else{
              $aviso = "Não deu certo, tente denovo";
            } 
          }
        }elseif($img['name'] != '' && $rotacao==''){
          $caminho_para_arquivo="../upload/$imagem_nome";
          if(file_exists($caminho_para_arquivo)){
            unlink("../upload/$imagem_nome");
          }
          if($img['type'] == 'image/jpeg'){
            $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
            $larguta_original = imagesx($imagem_temporaria);
            $altura_original = imagesy($imagem_temporaria);
            $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
            $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
            $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
            imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
            preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
            //$_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, $angulo, 0);
            $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
              if(imagejpeg($imagem_redimensionada,'../upload/'.$imagem_nome)){
                $aviso = "A imagem foi trocada com sucesso";
              }else{
                $aviso = "Não deu certo, tente denovo";
              }
          }elseif($img['type'] == 'image/png'){
            $imagem_temporaria = imagecreatefrompng($_FILES['foto']['tmp_name']);
            $larguta_original = imagesx($imagem_temporaria);
            $altura_original = imagesy($imagem_temporaria);
            $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
            $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
            $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
            imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
            preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
            $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
            if(imagepng($imagem_redimensionada,'../upload/'.$imagem_nome)){
              $aviso = "A imagem foi trocada com sucesso";
            }
        }
      }
     if($sql!=''){
      mysqli_query($conexao,$sql);
      $aviso = "O produto foi modificado com sucesso";
     }else{
       $sql='';
     }
     echo '<script>alert("'.$aviso.'");location.href="?a=verProdutos"</script>';
  }elseif($a=='Mudancas' && $a2=='verproduto'){
    $id=$_GET['id'];
    echo "<script>window.location.href='?a=verProdutos&a2=ver&id=$id'</script>";
  }elseif($a=='Mudancas' && $a2=='trocar'){
     $id=$_GET['id'];
     $id_preco = $_GET['id_preco'];
     $preco=$_GET['preco'];
     $sql= "update produtos set valor=$preco where id_produtos=$id";
     $delete = "delete from mudancas where id= $id_preco";
     if(mysqli_query($conexao,$sql)){
       if(mysqli_query($conexao,$delete)){
        $aviso = "O valor do produto foi atualizado";
       }
     }
     echo '<script>alert("'.$aviso.'");location.href="?a=verProdutos&a2=ver&id='.$id.'"</script>';
  }elseif($a=='Mudancas' && $a2=='excluir'){
    $id=$_GET['id'];
    $delete = "delete from mudancas where id=$id";
    if(mysqli_query($conexao,$delete)){
      $aviso="Foi deletado";
    }
    echo '<script>alert("'.$aviso.'");location.href="?a=Mudancas"</script>';
  }elseif($a=='inserir_palavra' && $a2=="" ){
   $id=$_GET['id'];
   $sql="select * from aprovacao inner join nome_categorias on aprovacao.categoria = nome_categorias.id where id_aprovacao=$id and palavras_categoria like'%%'";
   $consulta=mysqli_query($conexao,$sql);
   if($row=mysqli_num_rows($consulta)!=''){
     $array=mysqli_fetch_assoc($consulta);
     $id_categoria=$array['id'];
      $novo_nome=$array['nome_aprovacao'];
      $palavras=$array['palavras_categoria'];
      $verificar="select * from aprovacao inner join nome_categorias on aprovacao.categoria = nome_categorias.id where id_aprovacao=$id and palavras_categoria like '%$novo_nome%'";
      $consulta1=mysqli_query($conexao,$verificar);
      if($linha=mysqli_num_rows($consulta1)== 0){
        $sql="update nome_categorias set palavras_categoria='".$palavras.$novo_nome.","."' where id=$id_categoria";
        if($insert=mysqli_query($conexao,$sql)){
          $aviso="A palavra foi adicionada";
        }else{
          $aviso="Ocorreu um erro";
        }
      }else{
        $aviso="A palavra já existe";
      }
      echo '<script>alert("'.$aviso.'");location.href="?a=Mudancas"</script>';
   }
  }elseif($a=='form_inserir_palavra' && $a2 !=''){
    $palavra=trim(ucfirst($_POST['palavra']));
   $sql2="select * from nome_categorias where id=$a2 and  palavras_categoria like '%$palavra%'";
   $consulta2=mysqli_query($conexao,$sql2);
   if(mysqli_num_rows($consulta2)==0){
    $sql="select * from nome_categorias where id=$a2";
    $consulta=mysqli_query($conexao,$sql);
    $array=mysqli_fetch_assoc($consulta);
    $txt=$array['palavras_categoria'];
    $palavra=$palavra.",";
    $frase=$txt.$palavra;
    $update="update nome_categorias set palavras_categoria = '$frase' where id=$a2";
    if(mysqli_query($conexao,$update)){
      $aviso="A palavra foi adicionada";
    }else{
      $aviso="A palavra não foi adicionada";
    }
   }else{
     $aviso="Essa palavra já existe";
   }
    echo '<script>alert("'.$aviso.'");location.href="?a=palavra_categoria&id_categoria='.$a2.'"</script>';
  }elseif($a=='delete_word' && $a2!=''){
    $id_categoria=$_GET['id_categoria'];
    $sql="select * from nome_categorias where id=$id_categoria";
    $consulta=mysqli_query($conexao,$sql);
   if($array=mysqli_fetch_assoc($consulta)){
    $txt=$array['palavras_categoria'];
    $palavra=$a2.",";
    $frase=str_replace($palavra,"",$txt);
    $cod="update nome_categorias set palavras_categoria='$frase' where id=$id_categoria";
      if(mysqli_query($conexao,$cod)){
        $aviso="A palavra foi deletada";
      }else{
        $aviso="A palavra não foi deletada";
      }
    }
    echo '<script>alert("'.$aviso.'");location.href="?a=palavra_categoria&id_categoria='.$id_categoria.'"</script>';
  }elseif($a=='inserir_categoria_database' && $a2==''){
    $subcategoria=$_POST['subcategorias'];
    $caminho=$_POST['caminho'];
    $nome_categoria=$_POST['categoria'];
    $palavras=$_POST['palavras'];
    $palavras=str_replace(".",",",$palavras);
    $palavras;
    $categoria_de="categoria_de_".strtolower(str_replace(" ","_",$nome_categoria));
    $img=$_FILES['img_foto'];
    $largura = "300";
    $altura = "300";
    $config = array();
    $config['tamanho'] =11339870 ;
    $config['largura'] = 300;
    $config['altura'] = 300;
    $angulo = -90.0;
    $error = array();
    if($img !=''){
      if($img['type'] !='image/jpeg' && $img['type'] !='image/png'){
        $error[]= "Arquivo em formato inválido! A imagem deve ser jpg, jpeg, ou png. Envie outro arquivo";
      }else{
        if($img["size"] > $config["tamanho"]){
          $erro[] = "Arquivo em tamanho muito grande!";
        }
        $tamanhos = getimagesize($img["tmp_name"]);
        if($tamanhos[0]>$config['largura']){
          $erro[] = "Largura da imagem não deve ultrapassar " . $config["largura"] . " pixels";
        }
        if($tamanhos[1] > $config['altura']){
          $erro[] = "Altura da imagem não deve ultrapassar " . $config["altura"] . " pixels";
        }
      }
      if(sizeof($error) > 0){
        foreach($error as $err){
          $aviso = $aviso."#".$err."\\n";
        }
      }else{
        if($img['type'] == 'image/jpeg'){
          $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
          $larguta_original = imagesx($imagem_temporaria);
          $altura_original = imagesy($imagem_temporaria);
          $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
          $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
          $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
          imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
          preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
          //$_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, $angulo, 0);
          $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
          $imagem_nome;
          if(imagejpeg($imagem_redimensionada,'../img_categorias/'.$imagem_nome)){
           $select_subcategoria=true;
          }
        }elseif($img['type'] == 'image/png'){
          $imagem_temporaria = imagecreatefrompng($_FILES['img_foto']['tmp_name']);
          $larguta_original = imagesx($imagem_temporaria);
          $altura_original = imagesy($imagem_temporaria);
          $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
          $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
          $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
          imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
          preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
          $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
          $imagem_dir = "img/" . $imagem_nome;
          $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
          if(imagepng($imagem_redimensionada,'../img_categorias/'.$imagem_nome)){
             $select_subcategoria=true;
          }
        }
      }
    }
    if($select_subcategoria==true){
      $insert="insert into $subcategoria(sub_categoria,img_categoria) values('$nome_categoria','$imagem_nome')";
      if($consulta=mysqli_query($conexao,$insert)){
        $insert="insert into nome_categorias(nome,nome_categoria,palavras_categoria)values('$nome_categoria','$categoria_de','$palavras')";
        if(mysqli_query($conexao,$insert)){
          $select="select * from  nome_categorias where nome_categoria='$categoria_de'";
          $consulta=mysqli_query($conexao,$select);
          if($row=mysqli_num_rows($consulta)>0){
            $array=mysqli_fetch_assoc($consulta);
            $id_nome_categorias=$array['id'];
            $insert="insert into referencia_nome_tables (caminho,subcategoria,caminho_subcategorias,nome_categoria_referencia)values($caminho,'$nome_categoria','$subcategoria',$id_nome_categorias)";
            if(mysqli_query($conexao,$insert)){
              $aviso="A categoria foi adicionada";
            }else{
              $aviso="teve alguma erro";
            }
          }
        }
      }
    }
    echo '<script>alert("'.$aviso.'");location.href="?a=showCategorias"</script>';
  }elseif($a=='delete_categoria' && $a2==''){
    $subcategoria=$_GET['subcategoria'];
    $id_categoria=$_GET['id_categoria'];
    $sql="select * from $subcategoria where id=$id_categoria";
    if($consulta=mysqli_query($conexao,$sql)){
      $array=mysqli_fetch_assoc($consulta);
      $img=$array['img_categoria'];
      $nome_categoria=$array['sub_categoria'];
      $categoria_de="categoria_de_".strtolower(str_replace(" ","_",$nome_categoria));
     $sql="select * from nome_categorias where nome_categoria ='$categoria_de'";
      if($consulta=mysqli_query($conexao,$sql)){
        $array=mysqli_fetch_assoc($consulta);
        $id=$array['id'];
        $delete="delete from referencia_nome_tables where nome_categoria_referencia=$id";
        if(mysqli_query($conexao,$delete)){
          $delete="delete from nome_categorias where id=$id";
          if(mysqli_query($conexao,$delete)){
            $delete="delete from $subcategoria where id=$id_categoria";
            unlink("../img_categorias/$img");
            if(mysqli_query($conexao,$delete)){
              $aviso="A categoria foi deletada";
            }else{
              $aviso="Ocorreu um erro";
            }
          }
        }
      }
    }
    echo '<script>alert("'.$aviso.'");location.href="?a=showCategorias"</script>';
  }
?>