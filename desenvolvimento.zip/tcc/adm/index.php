<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="../css/css.css">
</head>
<body>
<div class = "conteiner_login" id = "login">
      <div class="head">
        <strong>Login(Acesso restrito)</strong>
      </div>
      <br>
      <div class = "cad_produtos">
          <form action="../verificacao/veri_login.php" method="post">
            <div class = "grupo_input_cad">
              <label for="nome">Login:</label><br>
              <input type="text" name = "nome" id = "nome" autocomplete = "off">
            </div>
            <div class="grupo_input_cad">
              <label for="senha">Senha:</label><br>
              <input type="password" name = "senha" id = "senha" autocomplete = "off" maxlength = "5">
            </div>
            <br>
            <div class="footer">
              <br>
              <div class = "btns_cad">
                <br>
                <button type = "submit">Entrar</button>
              </div> 
              <br>
            </div>
          </form>
      </div>
  </div>
</body>
</html>