<?php
  include('conexao/conexao.php');
  include('funcoes_tratamento/funcoes.php');
  $a=isset($_GET['a'])?$_GET['a']:'';
  if($a=='cadastro_produto'){
    $aviso="";
    $nome=trim(ucfirst(isset($_POST['nome'])?$_POST['nome']:'none'));
    $categoria=$_POST['categoria'];
    $nome_mercado=trim(ucfirst(isset($_POST['mercado'])?$_POST['mercado']:''));
    $preco=isset($_POST['preco'])?$_POST['preco']:'';
    $marca=trim(ucfirst(isset($_POST['marca'])?$_POST['marca']:''));
    $pais=trim(ucfirst(isset($_POST['pais'])?$_POST['pais']:''));
    $estado=trim(ucfirst(isset($_POST['estado'])?$_POST['estado']:''));
    $cidade=trim(ucfirst(isset($_POST['cidade'])?$_POST['cidade']:''));
    $bairro=trim(ucfirst(isset($_POST['bairro'])?$_POST['bairro']:''));
    $img=isset($_FILES['img_foto'])?$_FILES['img_foto']:'none';
    $comentario=trim(isset($_POST['comentario'])?$_POST['comentario']:'');
    $palavras_chaves=isset($_POST['palavras'])?$_POST['palavras']:'';

    /*tratamento*/
    $precolen = strlen($preco);
    if($precolen <= 6){
      $preco = str_replace(",",".",$preco);
    }else if($precolen >= 8){
      $preco = str_replace(".","",$preco);
      $preco = str_replace(",",".",$preco);
    }
    $palavras_chaves = str_replace("."," ",$palavras_chaves);
    if($categoria !=''){
      $largura = "300";
      $altura = "300";
      $config = array();
      $config['tamanho'] =11339870 ;
      $config['largura'] = 300;
      $config['altura'] = 300;
      $angulo = -90.0;
      $error = array();
      if($img !='none'){
        if($img['type'] !='image/jpeg' && $img['type'] !='image/png'){
          $error[]= "Arquivo em formato inválido! A imagem deve ser jpg, jpeg, ou png. Envie outro arquivo";
        }else{
          if($img["size"] > $config["tamanho"]){
            $erro[] = "Arquivo em tamanho muito grande!";
          }
          $tamanhos = getimagesize($img["tmp_name"]);
          if($tamanhos[0]>$config['largura']){
            $erro[] = "Largura da imagem não deve ultrapassar " . $config["largura"] . " pixels";
          }
          if($tamanhos[1] > $config['altura']){
            $erro[] = "Altura da imagem não deve ultrapassar " . $config["altura"] . " pixels";
          }
        }
        if(sizeof($error) > 0){
          foreach($error as $err){
            $aviso = $aviso."#".$err."\\n";
          }
        }else{
          if($img['type'] == 'image/jpeg'){
            $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
            $larguta_original = imagesx($imagem_temporaria);
            $altura_original = imagesy($imagem_temporaria);
            $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
            $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
            $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
            imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
            preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
            //$_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, $angulo, 0);
            $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
            if(imagejpeg($imagem_redimensionada,'upload/'.$imagem_nome)){
             $sql="insert into aprovacao(nome_aprovacao,marca,nome_mercado,valor,imagem,categoria,pais,estado,cidade,bairro,descricao,data_cad,palavras_chaves)values('$nome','$marca','$nome_mercado',$preco,'$imagem_nome',$categoria,'$pais','$estado','$cidade','$bairro','$comentario',now(),'$palavras_chaves')";
              if(mysqli_query($conexao,$sql)){
                $aviso = 'Sua postagem foi encaminhada para a aprovação';
              }else{
                $aviso = "Sua postagem não foi enviada, tente denovo";
              }
            }
          }elseif($img['type'] == 'image/png'){
            $imagem_temporaria = imagecreatefrompng($_FILES['img_foto']['tmp_name']);
            $larguta_original = imagesx($imagem_temporaria);
            $altura_original = imagesy($imagem_temporaria);
            $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
            $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
            $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
            imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
            preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
            $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
            $imagem_dir = "img/" . $imagem_nome;
            $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
            if(imagepng($imagem_redimensionada,'upload/'.$imagem_nome)){
              $sql = "insert into $BD.aprovacao (nome_aprovacao,marca,nome_mercado,valor,imagem,categoria,pais,estado,cidade,bairro,descricao,data_cad,palavras_chaves)values('$nome','$marca','$nome_mercado',$preco,'$imagem_nome',$categoria,'$pais','$estado','$cidade','$bairro','$comentario',now(),'$palavras_chaves')";
              if(mysqli_query($conexao,$sql)){
                $aviso = 'Sua postagem foi encaminhada para a aprovação';
              }else{
                $aviso = "Sua postagem não foi enviada, tente denovo";
              }
            }
          }
        }
      }
      if($aviso !=''){
        echo '<script>alert("'.$aviso.'");location.href="?a=cadastro_ok&a2='.$categoria.'";</script>';
      }
    }
  }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro</title>
  <link rel="stylesheet" href="css/cadastro.css?v=7">
  <link rel="shortcut icon" href="img/fivicon.png"> 
  <script src="js.js?v=4"></script>
</head>
<body id='body'>
  <header>
      <figure class='logo'>
      <a href="./"><img src="img/Logo6.png" alt="" id='img_logotipo'></a>
      </figure>
      <div class='dado_produto'>
        Dados do produto
      </div>
      <div class='voltar'>
        <u onclick="voltar()">Voltar</u>
      </div>
  </header>
  <div class='barra'>
    <div class='total'>
      <div class='preenchimento' id='barra_preechimento'>
        .
      </div>
    </div>
  </div>
  <?php
    if($a=='step-one'){
      $sql="select * from categorias";
      $consulta=mysqli_query($conexao,$sql);
     echo'
      <div class="informacao">
        <div class="texto">
          <h1>Olá, antes de tudo o que você vai cadastrar ?</h1>
        </div>
      </div>
      <section>
      ';
      while($array=mysqli_fetch_assoc($consulta)){
        $nome=$array['categoria'];
        $img=$array['img'];
        $nome_url=str_replace(" ","_",$nome);
        echo"
        <div class='categorias' onclick=location.href=`?a=step-two&name=$nome_url`>
          <figure>
            <img src='img/$img' alt=''>
          </figure>
          $nome
        </div>
        ";
      }
        echo'
      </section>
     ';
    }elseif($a=='step-two'){
      $name=$_GET['name'];
      $name=str_replace("_"," ",$name);
      $select_categorias="select * from categorias where categoria='$name'";
      $consulta=mysqli_query($conexao,$select_categorias);
      $array=mysqli_fetch_assoc($consulta);
      $img=$array['img'];
      $legenda=$array['categoria'];
      $sql_produtos="select * from referencia_nome_tables 
      INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id  where (categoria like '%$name%') and palavras_categoria <> ''";
      $resutado=mysqli_query($conexao,$sql_produtos);
      echo"
      <div class='informacao'>
        <div class='texto'>
          <h1>$legenda</h1>
        </div>
        <div class='legenda_figure'>
        
        <br>
          <figure>
            <img src='img/$img' alt=''>
          </figure>
        </div>
      </div>
      <div class='form'>
        <div class='info'>
          <h1>Primeiro, escreva o nome do produto</h1>
          <p>Indique o produto, escreva apenas o nome para nós identifica-los mais rápidamente</p>
        </div>
        <div class='flex'>
        <form action='?a=step-tree' method='post' onsubmit='return validar_nome_cadastro()'>
          <div class='input'>
            <input type='text' name='categoria' id='categoria' value='$name' class='sumir'>
            <div class='relative'>
              <div class='absolute'>
                <input type='text' name='nome' id='nome' maxlength='50' autocomplete='off'>
                  <div class='history' id='historico'>
                        
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class='submit'>
            <button>Confirmar</button>
          </div>
        </form>
          
        </div>
      </div>
      ";
    }elseif($a=='step-tree'){
      $categoria=$_POST['categoria'];
      $nome=$_POST['nome'];
      $subcategoria_select=isset($_POST['subcategoria'])?$_POST['subcategoria']:'';
      if($subcategoria_select !=''){
        $sql="select * from referencia_nome_tables INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where (subcategoria like '%$subcategoria_select%')";
      }else{
        $sql="select * from referencia_nome_tables INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where (categoria like '%$categoria%') and palavras_categoria like '%$nome%'";
      }
      $resutado=mysqli_query($conexao,$sql);
      if(mysqli_num_rows($resutado)<1){
        $sql_select="select * from referencia_nome_tables INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where (categoria like '%$categoria%')";
        $texto="subcategoria";
        echo"
        <div class='informacao'>
          <div class='texto'>
            <h1>Não foi identificado o produto</h1>
          </div>
        </div>
        <div class='form'>
          <div class='info'>
            <h1>Não achamos nenhuma lugar em $categoria que corresponde com <U>$nome</u></h1>
            <p></p>
          </div>
          <div class='texto_mostrar_categoria'>
            <form action='?a=step-four' method='post'>
              <input type='text' name='nome' id='' value='$nome' class='sumir'>
              <div class='nome_produto'>
                Informe uma subcategoria clicando em Selecionar outra subcategoria
              </div>
            </form>
          </div>
          <div class='categoria_nova'>
            <div class='nova_categoria'>
              <u id='click'>Selecionar outra subcategoria</u>
            </div>
          </div>
        </div>
        ";
      }else{
        $array=mysqli_fetch_assoc($resutado);
        $nome_subcategoria=$array['subcategoria'];
        $subcategoria=$array['caminho_subcategorias'];
        $id_categoria=$array['id'];
        if($subcategoria_select != ''){
          $nome_subcategoria=$subcategoria_select;
        }
        $select="select * from $subcategoria where sub_categoria like '%$nome_subcategoria%'";
        $consulta=mysqli_query($conexao,$select);
        $row=mysqli_fetch_assoc($consulta);
        $img=$row['img_categoria'];
        $sql_select="select * from $subcategoria";
        $texto="sub_categoria";
        echo"
        <div class='informacao'>
          <div class='texto'>
            <h1>Achamos uma subcategoria</h1>
          </div>
        </div>
        <div class='form'>
          <div class='info'>
            <h1>Colocamos o produto nessa subcategoria, selecione-a se estiver correta</h1>
            <p>Caso esteja incorreta, clique em selecionar outra subcategoria</p>
          </div>
          <div class='texto_mostrar_categoria'>
            <form action='?a=step-four' method='post'>
              <input type='text' name='nome' id='' value='$nome' class='sumir'>
              <input type='number' name='id_categoria' id='' value='$id_categoria' class='sumir'>
              <figure>
                <img src='img_categorias/$img' alt=''>
              </figure>
              <div class='nome_produto'>
                <strong>$categoria > $nome_subcategoria</strong>
              </div>
              <div class='proximo'>
                <button>
                  <img src='img/right-arrow.svg' alt=''>
                </button>
              </div>
            </form>
          </div>
          <div class='categoria_nova'>
            <div class='nova_categoria'>
              <u id='click'>Selecionar outra subcategoria</u>
            </div>
          </div>
        </div>
        ";
      }
      $consulta=mysqli_query($conexao,$sql_select);
      echo"
      <div class='form form_select' id='form_select'>
        Escolha a subcategoria:
        <form action='?a=step-tree' method='post'>
        <input type='text' name='categoria' id='categoria' value='$categoria' class='sumir'>
        <input type='text' name='nome' id='categoria1' value='$nome' class='sumir'>
          <select name='subcategoria' id=''>
          ";
          while($array=mysqli_fetch_assoc($consulta)){
            $categorias=$array["$texto"];
            echo"<option value='$categorias'>$categorias</option>";
          }
            echo"
          </select>
          <div class='submit_two'>
            <button>
              Confirmar
            </button>
          </div>
        </form>
      </div>
      ";
    }elseif($a=='step-four'){
      $nome=$_POST['nome'];
      $id_categoria=$_POST['id_categoria'];
      echo"
      <div class='informacao'>
        <div class='texto'>
          <h1>Agora informe o resto das informações</h1>
        </div>
      </div>
      <form action='?a=cadastro_produto' method='post' onsubmit='return validar_cad()' enctype='multipart/form-data'>
        <div class='form' formulario' id='form1'>
          <div class='info'>
            <strong>Nome do mercado:</strong>
          </div>
          <div class='input'>
          <input type='text' name='categoria' id='categoria' value=' $id_categoria' class='sumir'>
          <input type='text' name='nome' id='nome' value='$nome' class='sumir'>
            <input type='text' name='mercado' id='mercado' autocomplete='off'  maxlength='50'>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='proximo'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form2'>
          <div class='info'>
           <strong>  Marca: </strong>
          </div>
          <div class='input'>
            <input type='text' name='marca' id='marca' autocomplete='off'  maxlength='50'>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior2'>Anterior</div>
              <div id='proximo2'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form3'>
          <div class='info'>
           <strong> Preço</strong>
          </div>
          <div class='input'>
            <input type='text'  name='preco' id='preco' placeholder='00,00' autocomplete='off'  onkeyup = 'formatarMoeda()' maxlength='9'>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior3'>Anterior</div>
              <div id='proximo3'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form4'>
          <div class='info'>
            <p>Informe a localidade do produto</p>
            <br>
            <strong>Pais:</strong>
          </div>
          <div class='input'>
            <input type='text' name='pais' id='pais' autocomplete='off'  value='Brasil'>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior4'>Anterior</div>
              <div id='proximo4'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form5'>
          <div class='info'>
            <strong>Estado:</strong>
          </div>
          <div class='input'>
            <input type='text' name='estado' id='estado' autocomplete='off'>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior5'>Anterior</div>
              <div id='proximo5'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form6'>
          <div class='info'>
            <strong>Cidade:</strong>
          </div>
          <div class='input'>
            <input type='text' name='cidade' id='cidade' autocomplete='off'>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior6'>Anterior</div>
              <div id='proximo6'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form7'>
          <div class='info'>
            <strong> Bairro:</strong>
          </div>
          <div class='input'>
            <input type='text' name='bairro' id='bairro' autocomplete='off' >
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior7'>Anterior</div>
              <div id='proximo7'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form8'>
          <div class='info'>
           <strong> Adicione uma imagem do produto:</strong>
          </div>
          <div class='input'>
            <input type='file' name='img_foto' id='img' onchange = 'preview()'>
            <div class='preview' id='preview'>
              <img id='img_preview' src='img/noimage.jpg' alt='' width='200' height='200'>
            </div>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior8'>Anterior</div>
              <div id='proximo8'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form9'>
          <div class='info'>
            <strong>Quer colocar seu comentario ?</strong>
          </div>
          <div class='input'>
          <textarea name='comentario' id='comentario'  rows='10' maxlength = '500' placeholder='Digite a sua opnial sobre o produto aqui' autocomplete='off'>
          
          </textarea>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior9'>Anterior</div>
              <div id='proximo9'>Proximo</div>
            </div>
          </div>
        </div>
        <div class='form'  formulario' id='form10'>
          <div class='info'>
         <strong> Adicione as palavras chaves:</strong>
          </div>
          <div class='input'>
          <div class = 'container'>
          <div class='container_flex'>
          <input type='text' name = 'palavras' id = 'palavras' class='input_tags' autocomplete = 'off' placeholder='Adicione as palavras chaves para que outras pessoas possam encontrar o produto'><span class = 'add' onclick = 'tecla_chave()'>+</span><span class='reset'onclick = 'reset()'>Reset</span>
          </div>
            <div class = 'tag_container' id='tag_container'>
      
            </div>
          </div>
          </div>
          <div class='submit'>
            <div class='btns'>
              <div id='anterior10'>Anterior</div>
              <button id='proximo10'>Enviar</button>
            </div>
          </div>
        </div>
      </form>
      ";
    }elseif($a=='cadastro_ok'){
      $a2=$_GET['a2'];
      $sql="select * from referencia_nome_tables 
      INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias where id='$a2';";
      $resultado=mysqli_query($conexao,$sql);
      $row=mysqli_fetch_assoc($resultado);
      $caminho=$row['categoria'];
      $categoria=$row['subcategoria'];
      echo "
      <div class='container_thak_for_help'>
        <div class='cotainer_figure_obg'>
          <figure>
            <img src='img/check.png' alt='' width='200' height='200'>
          </figure>
          <div class='obrigado'>
            <h1>Seu cadastro foi efetuado com sucesso</h1>
            <p>Obrigado por contribuir com o nosso site<p>
            <p>O produto vai estar em breve na área <strong>$caminho / $categoria</strong></p>
            <br>
            <a href='index.php'>Voltar para a pagina inicial</a>
          </div>
        </div>
     </div>
      ";
    }
  ?>
  <script>
    <?php
      if($a=='step-two'){
        $palavra_categoria="";
        while($row=$resutado->fetch_array()){
          $palavra_categoria.= trim($row['palavras_categoria']);
        };
        echo 'historico("'.$palavra_categoria.'");';
      }
      ?>
    mostrar_select_categoria('click','form_select');
    almentar_barra();
    mudar();
    script_tirar_espacos('comentario');
  </script>
  <?php
  include('rodape.php');
  ?>
</body>
</html>