<?php
  include('conexao/conexao.php');
  include('funcoes_tratamento/funcoes.php');
  $a = isset($_GET['a'])?$_GET['a']:'';
  $a2 = isset($_GET['a2'])?$_GET['a2']:'';
  $p = isset($_GET['p'])?$_GET['p']:'';
  $categoria = isset($_GET['nome_categoria'])?$_GET['nome_categoria']:'none';
  $pg = isset($_GET['pag'])?$_GET['pag']:1;
  $qunt_pagina=9;
  $inicio = ($qunt_pagina * $pg)-$qunt_pagina;
  if($p!=''){
    $a='null';
  }elseif($categoria !='none'){
    $a='Pesquisa avancada';
  }elseif($a2=='mudar_preco'){
    $preco = $_POST['preco_novo'];
    $id = $_GET['id'];
    $precolen = strlen($preco);
    if($precolen <= 6){
      $preco = str_replace(",",".",$preco);
    }else if($precolen >= 8){
      $preco = str_replace(".","",$preco);
      $preco = str_replace(",",".",$preco);
    }
    if($preco != ''){
      $insert="insert into mudancas(id_produto,novo_preco) values($id,$preco)";
      if(mysqli_query($conexao,$insert)){
        $aviso="A sua sujestão de mudança esta sendo encaminhada para a aprovação";
      }else{
        $aviso='Não foi possivel enviar a sujestão de mudança';
      }
      echo '<script>alert("'.$aviso.'");location.href="index.php?a=produtos";</script>';
    }
  }elseif($a=='cadastro_categoria_nome'){
    $nome=$_POST['nome'];
    $sql="select * from referencia_nome_tables";
    $resutado=mysqli_query($conexao,$sql);
    while($row=$resutado->fetch_array()){
      $name_table=$row['nome'];
      $sql="select * from $name_table where nome like '%$nome%'";
      $result = mysqli_query($conexao,$sql);
      $row=mysqli_num_rows($result);
    }
  }elseif($a=='enviar_email'){
    $para="jorgecalheiros.s@gmail.com";
    $nome_usuario=$_POST['nome_usu'];
    $email_usuario=$_POST['email_usu'];
    $texto=$_POST['mensagem'];
    $assunto=$_POST['assunto'];
    if(mail($para,$assunto,$texto)){
      $aviso="Seu email foi enviado";
    }else{
      $aviso="Não foi enviado, verifique se o email é autenticado";
    }
   echo '<script>alert("'.$aviso.'");location.href="index.php";</script>';
  }
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preço fácil</title>
    <link rel="shortcut icon" href="img/fivicon.png"> 
    <link rel="stylesheet" href="css/css.css?v=22">
    <script src="js.js?v=12"></script>
  </head>
  <body id= "body">
  <div class = "bg" id = 'bg' onclick="fechar_busca()">.</div>
  <div class = "bg" id = 'bg2'>.</div>
  <header id='header'>
    <br>
    <figure class='logo' id='logo_img'>
      <a href="./"><img src="img/Logo6.png" alt="" id='img_logotipo'></a>
    </figure>
  <!--<div class='nome_site'>
        <u><a href="./" id='preco_facil'>Preço fácil</a></u>
    </div>-->
    <div class="content_pesquisa" id='content_pesquisa'> 
      <div class="container_pesquisa" id='container_pesquisa'>
          <form action="" method="get" onsubmit = "return validar_pesquisa()">
            <input type="text" placeholder="Procure um produto" name = "p" id= "nome" autocomplete="off">
            <button type="submit" id='submit_pesquisa'><img src="img/lupa.svg" alt=""></button>
          </form>
          <div class='history' id='historico'>
                  
          </div>
      </div>
    </div>
    <div class="container_pesquisa_abas" >
      <nav class="container_abas" id='container_abas'>
        <ul>
          <li class="aba" onclick="location.href='./'">
            <strong>Home</strong>
          </li>
          <li class="aba" onclick="location.href='?a=empresa'">
            <strong>Sobre nós</strong>
          </li>
          <li class="aba" onclick="location.href='cadastro1.php?a=step-one'">
            <strong >Cadastro de produtos</strong>
          </li>
          <li class="aba" id='fale_conosco' onclick="location.href='?a=faleConosco'">
            <strong>Fale conosco</strong>
          </li>
        </ul>
        <div class='btn_fechar_menu' id='btn_fechar_menu'>
          <div onclick="fechar_btn_menu()"><img src="img/seta-direita.png" alt=""></div>
        </div>
      </nav>
    </div>
    <div class='btn_menu_container' id='btn_menu_container'>
      <button onclick="abrir_menu()" id='abrir_menu'><img src="img/menu (2).svg" alt="" width='40'><span>Menu</span></button>
    </div>
    <br>
  </header>
  <figure class='imagem_grande' id='imagem_grande'>
    <img src="img/decisoes-de-compras.jpg" alt="" id='img_principal'>
      <div class='titulo'>
          Preço Fácil
      </div>
  </figure>
  <div class='menu' id='menu'>
    <nav>
      <ul>
      <li class="aba" onclick="location.href='./'">
        <strong>Home</strong>
      </li>
      <li class="aba" onclick="location.href='?a=empresa'">
        <strong>Sobre nós</strong>
      </li>
      <li class="aba" onclick="location.href='cadastro1.php?a=step-one'">
        <strong >Cadastro de produtos</strong>
      </li>
      <li class="aba" id='fale_conosco'onclick="location.href='?a=faleConosco'">
        <strong>Fale conosco</strong>
      </li>
      <div class='btn_fechar_menu'>
        <button onclick='fechar_btn_menu()'><img src="img/menu (3).svg" alt=""></button>
      </div>
      </ul>
    </nav>
  </div>
  <div class="container_mostrar_produtos" id='container_mostrar_produtos'>
    <br>
    <div class='acoes'>
      <?php
        if($p !=''){
          $sql = "select * from $BD.produtos where nome_produtos like '%$p%' or palavras_chaves like '%$p%' order by data_cad desc limit $inicio,$qunt_pagina";
          $sql2="select * from $BD.produtos where nome_produtos like '%$p%' or palavras_chaves like '%$p%'";
          $result2= mysqli_query($conexao,$sql2);
          $total02= mysqli_num_rows($result2);
          $result = mysqli_query($conexao,$sql);
          $total = mysqli_num_rows($result);
      

          if($total == 0){
            echo "
            <div class='alert'>
              Não há produtos compativeis com a sua pesquisa de $p
              <br>
            </div>
            <div class='img'>
              <img src='img/not-found.svg' alt=''>
            </div>
            <div class='alert'>
            <br>
              Porfavor adicione um produto para nos ajudar.
            </div>
            ";
          }else{
            echo "
            </br>
            <div class='taxonomia'>
            <strong><a href='./'>Home</a> / <a href='?p=$p'>Pesquisa</a> </strong>
            </div>
            <br>
              <div class='quantidade'>
              Achamos $total02 resultados
              </div>
              <br>
              ";
              echo"
              <div class='container_filtro_mostrar_produtos'> 
                <div class='btn_mostrar_filtro'>
                  <button id='btn_filtro'>
                  <img src='img/filter.svg' alt=''>
                  </button>
                </div>
                <div class='filtro_produtos_outro' id='container_filtro'>
                    <div class='head_filtro'>
                      Filtro
                      <div class='btn_fechar_filtro'>
                        <button id='btn_fechar_filtro'><img src='img/close.svg' alt=''></button>
                      </div>
                    </div>
                  <form action='' method='get'>
                    <div class='container_inputs'>
                      <h1>Informações sobre o produto</h1>
                      <div class='nome_produto'>
                        <div class='label'>
                          Nome do produto:
                        </div>
                        <input type='text' name='nome_categoria' id='categoria_filtro' autocomplete='off' value=''>
                        <input type='text' name='nome' id='nome_filtro' autocomplete='off' value='$p'>
                      </div>
                      <div class='marca'>
                        <div class='label'>
                          Nome da marca:
                        </div>
                        <input type='text' name='marca' id='marca_filtro' autocomplete='off'>
                      </div>
                      <div class='mercado'>
                        <div class='label'>
                          Digite o mercado
                        </div>
                        <input type='text' name='mercado' id='mercado_filtro' autocomplete='off'>
                      </div>
                    </div>
                    <div class='container_inputs'>
                      <h1>Localização:</h1>
                      <div class='pais'>
                      <div class='label'>
                        Pais
                      </div>
                        <input type='text' name='pais' id='pais_filtro' autocomplete='off'>
                      </div>
                      <div class='estado'>
                      <div class='label'>
                        Estado
                      </div>
                        <input type='text' name='estado' id='estado_filtro' autocomplete='off'>
                      </div>
                      <div class='cidade'>
                      <div class='label'>
                        Cidade
                      </div>
                        <input type='text' name='cidade' id='cidade_filtro' autocomplete='off'>
                      </div>
                      <div class='bairro'>
                      <div class='label'>
                        Bairro
                      </div>
                        <input type='text' name='bairro' id='bairro_filtro' autocomplete='off'>
                      </div>
                    </div>
                    <div class='container_inputs'>
                      <h1>Ordenar por</h1>
                      <label for='radio_asc'>Menor preço</label><input type='radio' name='radio' id='radio_asc' value='asc' class='radio' checked>
                      <label for='radio_desc'>Maior preço</label><input type='radio' name='radio' id='radio_desc' value='desc' class='radio'>
                    </div>
                    <div  class='container_inputs'>
                      <div class='btn_filtrar'>
                        <button>Filtrar</button>
                      </div>
                    </div>
                  </form>
                </div>
                <div class='filtro_produtos'>
                  <form action='' method='get'>
                    <div class='container_inputs'>
                      <h1>Informações sobre o produto</h1>
                      <div class='nome_produto'>
                        <div class='label'>
                          Nome do produto:
                        </div>
                        <input type='text' name='nome_categoria' id='categoria_filtro' autocomplete='off' value=''>
                        <input type='text' name='nome' id='nome_filtro' autocomplete='off' value='$p'>
                      </div>
                      <div class='marca'>
                        <div class='label'>
                          Nome da marca:
                        </div>
                        <input type='text' name='marca' id='marca_filtro' autocomplete='off'>
                      </div>
                      <div class='mercado'>
                        <div class='label'>
                          Digite o mercado
                        </div>
                        <input type='text' name='mercado' id='mercado_filtro' autocomplete='off'>
                      </div>
                    </div>
                    <div class='container_inputs'>
                      <h1>Localização:</h1>
                      <div class='pais'>
                      <div class='label'>
                        Pais
                      </div>
                        <input type='text' name='pais' id='pais_filtro' autocomplete='off'>
                      </div>
                      <div class='estado'>
                      <div class='label'>
                        Estado
                      </div>
                        <input type='text' name='estado' id='estado_filtro' autocomplete='off'>
                      </div>
                      <div class='cidade'>
                      <div class='label'>
                        Cidade
                      </div>
                        <input type='text' name='cidade' id='cidade_filtro' autocomplete='off'>
                      </div>
                      <div class='bairro'>
                      <div class='label'>
                        Bairro
                      </div>
                        <input type='text' name='bairro' id='bairro_filtro' autocomplete='off'>
                      </div>
                    </div>
                    <div class='container_inputs'>
                      <h1>Ordenar por</h1>
                      <br>
                      <label for='radio_asc'>Menor preço</label><input type='radio' name='radio' id='radio_asc' value='asc' class='radio' checked>
                      <label for='radio_desc'>Maior preço</label><input type='radio' name='radio' id='radio_desc' value='desc' class='radio'>
                    </div>
                    <div class='btn_filtrar'>
                      <button>Filtrar</button>
                    </div>
                  </form>
                </div>
                <div class='caixa_mostrar_produtos'>
                ";
                while($row=$result->fetch_array()){
                  $id = $row['id_produtos'];
                  $data = $row['data_cad'];
                  $nome = $row['nome_produtos'];
                  $categoria =  $row['categoria'];
                  $preco = $row['valor'];
                  $imagem = $row['imagem'];
                  $data = tratar_data($data);
                  $preco=tratar_preco($preco);
                  echo"
                    <div class='novo_container_produto'>
                      <figure>
                      <img src='upload/$imagem' alt=''>
                      </figure>
                      <div class='info'>
                        <div class='titulo'>
                          $nome
                        </div>
                        <div class='week'>
                          $data
                        </div>
                        <div class='preco'>
                          R$ $preco
                        </div>
                        <div class='btn' onclick='direcionar(15,$id,`$p`)'>
                          Clique para mais informações
                        </div>
                      </div>
                    </div>
                  ";
                }
                echo"
                </div>
              </div>
            ";
            $result_pg="select * from $BD.produtos where nome_produtos like '%$p%' or palavras_chaves like '%$p%'";
            $resultado_pg=mysqli_query($conexao,$result_pg);
            $row_pg=mysqli_num_rows($resultado_pg);
            
            echo"
            <div class='paginacao' id='paginacao'>
              <div class='primeiro' id='primeiro'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
              <div class='anterior'id='anterior'><img src='img/seta-direita.png' alt=''></div>
              <div class='container_number' id='numbers'>
                <div class='numbers_style'>1</div>
              </div>
              <div class='proximo'id='proximo'><img src='img/seta-direita.png' alt=''></div>
              <div class='ultimo'id='ultimo'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
            </div>
            <script>
              paginacao($row_pg);
              abrir_filtro();
            </script>
            <br>
            ";
          }
        }elseif($a == ''){
          /*
          echo"
          <div class='content_carrosel_max' id='content_carrosel'>
            <div class='btn_carrosel' id='btn_anterior'>
              <img src='img/right-arrow.svg' alt=''>
            </div>
            <div class='container_max_carrosel' id='container_carrosel'>
                <div class='box'>
                <figure>
                <img src='img/mae.png' alt=''>
                </figure>
                </div>
                <div class='box'>
                  Feliz dias das mâes
                </div>
                <div class='box'>
                  principalmente para minha mãe incrivel
                </div>
                <div class='box'>
                <figure>
                <img src='img/coracao.jpg' alt=''>
                </figure>
                </div>
            </div>
            <div class='btn_carrosel' id='btn_proximo'>
            <figure>
            <img src='img/right-arrow.svg' alt=''>
            </figure>
             
            </div>
          </div>
          ";
          */
          $mais_pesquisados="select * from mais_acessados join produtos on mais_acessados.id_produto=produtos.id_produtos order by valor desc limit 8";
          $consulta=mysqli_query($conexao,$mais_pesquisados);
          if(mysqli_num_rows($consulta) > 7){
            echo"
            <section>
              <div class='titulo'><h1>Produtos mais pesquisados</h1></div>
              <div class='container_mini_carrosel'>
                <div class='btn' id='btn_prev3'>
                  <img src='img/right-arrow.svg' alt=''>
                </div>
                <div class='mini_carrosel' id='mini_carrosel3'>
                ";
                  while($array=mysqli_fetch_assoc($consulta)){
                    $nome=$array['nome_produtos'];
                    $data=$array['data_cad'];
                    $preco=$array['valor'];
                    $id=$array['id_produtos'];
                    $imagem=$array['imagem'];
                    $data=tratar_data($data);
                    $preco=tratar_preco($preco);
                    echo"
                    <div class='novo_container_produto' id='novo_container_produto3'>
                      <figure>
                      <img src='upload/$imagem' alt=''>
                      </figure>
                      <div class='info'>
                        <div class='titulo'>
                          $nome
                        </div>
                        <div class='week'>
                          $data
                        </div>
                        <div class='preco'>
                          R$ $preco
                        </div>
                        <div class='btn' onclick='direcionar(14,$id)'>
                        Ver preços
                        </div>
                      </div>
                    </div>
                    ";
                  }
                  echo"
                </div>
                <div class='btn'  id='btn_next3'>
                  <img src='img/right-arrow.svg' alt=''>
                </div>
              </div>
            </section>
            <script>
            scroll_section3();
            </script>
            ";
          }
          $mais_baratos="select * from produtos order by valor asc limit 8";
          $consulta=mysqli_query($conexao,$mais_baratos);
          if(mysqli_num_rows($consulta)>7){
            echo"
            <section>
              <div class='titulo'><h1>Produtos mais baratos</h1></div>
              <div class='container_mini_carrosel'>
                <div class='btn' id='btn_prev'>
                  <img src='img/right-arrow.svg' alt=''>
                </div>
                <div class='mini_carrosel' id='mini_carrosel'>
                ";
                  while($array=mysqli_fetch_assoc($consulta)){
                    $nome=$array['nome_produtos'];
                    $data=$array['data_cad'];
                    $preco=$array['valor'];
                    $id=$array['id_produtos'];
                    $imagem=$array['imagem'];
                    $data=tratar_data($data);
                    $preco=tratar_preco($preco);
                    echo"
                    <div class='novo_container_produto' id='novo_container_produto'>
                      <figure>
                      <img src='upload/$imagem' alt=''>
                      </figure>
                      <div class='info'>
                        <div class='titulo'>
                          $nome
                        </div>
                        <div class='week'>
                          $data
                        </div>
                        <div class='preco'>
                          R$ $preco
                        </div>
                        <div class='btn' onclick='direcionar(14,$id)'>
                        Ver preços
                        </div>
                      </div>
                    </div>
                    ";
                  }
                  echo"
                </div>
                <div class='btn' id='btn_next'>
                  <img src='img/right-arrow.svg' alt=''>
                </div>
              </div>
            </section>
            <script>
              scroll_section();
            </script>
            ";
          }
          $mais_caros="select * from produtos order by valor desc limit 8";
          $consulta=mysqli_query($conexao,$mais_caros);
          if(mysqli_num_rows($consulta)>7){
            echo"
            <section>
              <div class='titulo'><h1>Produtos mais caros</h1></div>
              <div class='container_mini_carrosel'>
                <div class='btn' id='btn_prev2'>
                  <img src='img/right-arrow.svg' alt=''>
                </div>
                <div class='mini_carrosel' id='mini_carrosel2'>
                ";
                  while($array=mysqli_fetch_assoc($consulta)){
                    $nome=$array['nome_produtos'];
                    $data=$array['data_cad'];
                    $preco=$array['valor'];
                    $id=$array['id_produtos'];
                    $imagem=$array['imagem'];
                    $data=tratar_data($data);
                    $preco=tratar_preco($preco);
                    echo"
                    <div class='novo_container_produto' id='novo_container_produto2'>
                      <figure>
                      <img src='upload/$imagem' alt=''>
                      </figure>
                      <div class='info'>
                        <div class='titulo'>
                          $nome
                        </div>
                        <div class='week'>
                          $data
                        </div>
                        <div class='preco'>
                          R$ $preco
                        </div>
                        <div class='btn' onclick='direcionar(14,$id)'>
                          Ver preços
                        </div>
                      </div>
                    </div>
                    ";
                  }
                  echo"
                </div>
                <div class='btn' id='btn_next2'>
                  <img src='img/right-arrow.svg' alt=''>
                </div>
              </div>
            </section>
            <script>
            scroll_section2();
            </script>
            ";
          }
          $sql = "select * from categorias";
          $resutado = mysqli_query($conexao,$sql);
          echo"
          <section>
          <div class='titulo'><h1>Produtos por categoria</h1></div>
            <div class='container_categorias_produtos'>
              <div class='container_categorias_populares'>
              ";
              while($row=$resutado->fetch_array()){
                $nome_categoria = $row['categoria'];
                $img=$row['img'];
                $id_categoria = $row['id_categorias'];
                echo "
                <div class='container_categoria' id='container_categoria_$id_categoria'>
                  <figure>
                    <img src='img/$img' alt='' width width='100' height='100'>
                  </figure>
                  <p>$nome_categoria</p>
                </div>
                <script>
                  redirecioar_categorias($id_categoria);
                </script>
                ";
              }
              echo"
              </div>
            </div>
          </section>
          ";
          echo"
          <script>
           
          </script>
          ";
        }elseif($a == 'produtos' && $a2 == ''){
          $sql = "select * from $BD.produtos order by data_cad DESC limit $inicio,$qunt_pagina";
          $result = mysqli_query($conexao,$sql);
          $total = mysqli_num_rows($result);
          if($total == 0){
            echo "
            <div class='recente'>
              Não há produtos cadastrados
            </div>
            ";
          }else{
            echo "
            <br>
            ";

            while($row=$result->fetch_array()){
              $id = $row['id_produtos'];
              $data = $row['data_cad'];
              $nome = $row['nome_produtos'];
              $categoria =  $row['categoria'];
              $preco = $row['valor'];
              $imagem = $row['imagem'];
              $data = tratar_data($data);
              $preco=tratar_preco($preco);
              
              echo "
              <div class = 'container_produto_forma' onclick='direcionar(14,$id)'>
                <figure>
                  <img src='upload/$imagem' alt=''>
                </figure>
                <div class='assunto'>
                  <div class='week'>
                    $data
                  </div>
                  <br>
                  <div class = 'nome_produto'>
                    $nome
                  </div>
                  <br>
                  <div class ='info'>
                    clique para mais informações
                  </div>
                  <br>
                  <div class ='preco_produto'>
                    preço: <br> $preco R$
                  </div>
                  <br>
                </div>
              </div>
              ";
            }
            $result_pg="select * from $BD.produtos";
            $resultado_pg=mysqli_query($conexao,$result_pg);
            $row_pg=mysqli_num_rows($resultado_pg);
            
            echo "
            <div class='paginacao' id='paginacao'>
              <div class='primeiro' id='primeiro'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
              <div class='anterior'id='anterior'><img src='img/seta-direita.png' alt=''></div>
              <div class='container_number' id='numbers'>
                <div class='numbers_style'>1</div>
              </div>
              <div class='proximo'id='proximo'><img src='img/seta-direita.png' alt=''></div>
              <div class='ultimo'id='ultimo'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
            </div>
            <script>
              paginacao($row_pg);
            </script>
            ";
          }
        }elseif($a=='empresa'){
          echo
          "
          <div class='texto_sobrenos_titulo'>
            <h1>Sobre nós</h1>
          </div>
          <div class='container_texto_sobrenos'>
            <div class='texto_sobrenos'>
            Somos uma organização que tem o foco no mercado digital, trabalhamos com site e plataformas que tragam facilidade de uso e integridade, nosso principal objetivo e melhorar o mercado regional com uma proposta diferente e inovadora, que visa facilitar e melhorar a busca por produtos baratos e de qualidade, dando visibilidade e oportunidade para criar uma nova tendência de catálogo digital regional.
            <br>
            <br>
            <ul>
              <li>Melhorar o mercado regional</li>
              <li>Melhor facilidade de busca e acesso</li>
              <li>Economia de gastos em compras</li>
              <li>Dar visibilidades a produtos não tão conhecidos</li>
              <li>Criar uma nova tendência de catálogo digital regional</li>
            </ul>
            <br>
            Desenvolvemos este site com a finalidade de criar um ambiente fácil e intuitivo, onde todos possam encontrar e cadastrar produtos com o melhor preço do mercado, sendo assim criando uma oportunidade tanto para novos mercados como para usuários que buscam ter melhor economia sobre os produtos que pretendem investir.
            </div>
         
          </div>
          <br>
          ";
        }elseif($categoria !='none'){
          $nome=ucfirst(isset($_GET['nome'])?$_GET['nome']:'');
          $pais = ucfirst(isset($_GET['pais'])?$_GET['pais']:'');
          $estado = ucfirst(isset($_GET['estado'])?$_GET['estado']:'');
          $cidade = ucfirst(isset($_GET['cidade'])?$_GET['cidade']:'');
          $bairro = ucfirst(isset($_GET['bairro'])?$_GET['bairro']:'');
          $mercado = ucfirst(isset( $_GET['mercado'])? $_GET['mercado']:'');
          $nome_marca=ucfirst(isset($_GET['marca'])?$_GET['marca']:'');
          $order = isset($_GET['radio'])?$_GET['radio']:'asc';
          $sql="select * from referencia_nome_tables 
          INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where referencia_nome_tables.subcategoria like '%$categoria%' limit 1";
          $re2=mysqli_query($conexao,$sql);
          $row=mysqli_num_rows($re2);
          if($row>0 && $row<2){
            $array=mysqli_fetch_assoc($re2);
            if($categoria==''){
              $t="";
              $frase=" like '%$t%'";
            }else{
              $t=$array['nome_categoria'];
              $frase="= '$t'";
            }
          }
          $sql="select * from produtos
          INNER JOIN nome_categorias ON produtos.categoria = nome_categorias.id where nome_categorias.nome_categoria $frase and nome_produtos like '%$nome%' and nome_mercado like '%$mercado%' and pais like '%$pais%' and estado like '%$estado%' and cidade like '%$cidade%' and bairro like '%$bairro%' and Marca like'%$nome_marca%' order by valor $order limit $inicio,$qunt_pagina";
          $result = mysqli_query($conexao,$sql);
          $total = mysqli_num_rows($result);
          if($total == 0){
            echo "
            <div class='recente'>
              Não há produtos compativeis com a sua pesquisa.
            </div>
            ";
          }else{
            echo "
            <div class='quantidade'>
              Há $total produto
            </div>
            <br>
            ";
            echo"
            <div class='container_filtro_mostrar_produtos'> 
              <div class='btn_mostrar_filtro'>
                <button id='btn_filtro'>
                <img src='img/filter.svg' alt=''>
                </button>
              </div>
              <div class='filtro_produtos_outro' id='container_filtro'>
                  <div class='head_filtro'>
                    Filtro
                    <div class='btn_fechar_filtro'>
                      <button id='btn_fechar_filtro'><img src='img/close.svg' alt=''></button>
                    </div>
                  </div>
                <form action='' method='get'>
                  <div class='container_inputs'>
                    <h1>Informações sobre o produto</h1>
                    <div class='nome_produto'>
                      <div class='label'>
                        Nome do produto:
                      </div>
                      <input type='text' name='nome_categoria' id='categoria_filtro' autocomplete='off' value='$categoria'>
                      <input type='text' name='nome' id='nome_filtro' autocomplete='off'>
                    </div>
                    <div class='marca'>
                      <div class='label'>
                        Nome da marca:
                      </div>
                      <input type='text' name='marca' id='marca_filtro' autocomplete='off'>
                    </div>
                    <div class='mercado'>
                      <div class='label'>
                        Digite o mercado
                      </div>
                      <input type='text' name='mercado' id='mercado_filtro' autocomplete='off'>
                    </div>
                  </div>
                  <div class='container_inputs'>
                    <h1>Localização:</h1>
                    <div class='pais'>
                    <div class='label'>
                      Pais
                    </div>
                      <input type='text' name='pais' id='pais_filtro' autocomplete='off'>
                    </div>
                    <div class='estado'>
                    <div class='label'>
                      Estado
                    </div>
                      <input type='text' name='estado' id='estado_filtro' autocomplete='off'>
                    </div>
                    <div class='cidade'>
                    <div class='label'>
                      Cidade
                    </div>
                      <input type='text' name='cidade' id='cidade_filtro' autocomplete='off'>
                    </div>
                    <div class='bairro'>
                    <div class='label'>
                      Bairro
                    </div>
                      <input type='text' name='bairro' id='bairro_filtro' autocomplete='off'>
                    </div>
                  </div>
                  <div class='container_inputs'>
                    <h1>Ordenar por</h1>
                    <label for='radio_asc'>Menor preço</label><input type='radio' name='radio' id='radio_asc' value='asc' class='radio' checked>
                    <label for='radio_desc'>Maior preço</label><input type='radio' name='radio' id='radio_desc' value='desc' class='radio'>
                  </div>
                  <div  class='container_inputs'>
                    <div class='btn_filtrar'>
                      <button>Filtrar</button>
                    </div>
                  </div>
                </form>
              </div>
              <div class='filtro_produtos'>
                <form action='' method='get'>
                  <div class='container_inputs'>
                    <h1>Informações sobre o produto</h1>
                    <div class='nome_produto'>
                      <div class='label'>
                        Nome do produto:
                      </div>
                      <input type='text' name='nome_categoria' id='categoria_filtro' autocomplete='off' value='$categoria'>
                      <input type='text' name='nome' id='nome_filtro' autocomplete='off'>
                    </div>
                    <div class='marca'>
                      <div class='label'>
                        Nome da marca:
                      </div>
                      <input type='text' name='marca' id='marca_filtro' autocomplete='off'>
                    </div>
                    <div class='mercado'>
                      <div class='label'>
                        Digite o mercado
                      </div>
                      <input type='text' name='mercado' id='mercado_filtro' autocomplete='off'>
                    </div>
                  </div>
                  <div class='container_inputs'>
                    <h1>Localização:</h1>
                    <div class='pais'>
                    <div class='label'>
                      Pais
                    </div>
                      <input type='text' name='pais' id='pais_filtro' autocomplete='off'>
                    </div>
                    <div class='estado'>
                    <div class='label'>
                      Estado
                    </div>
                      <input type='text' name='estado' id='estado_filtro' autocomplete='off'>
                    </div>
                    <div class='cidade'>
                    <div class='label'>
                      Cidade
                    </div>
                      <input type='text' name='cidade' id='cidade_filtro' autocomplete='off'>
                    </div>
                    <div class='bairro'>
                    <div class='label'>
                      Bairro
                    </div>
                      <input type='text' name='bairro' id='bairro_filtro' autocomplete='off'>
                    </div>
                  </div>
                  <div class='container_inputs'>
                    <h1>Ordenar por</h1>
                    <br>
                    <label for='radio_asc'>Menor preço</label><input type='radio' name='radio' id='radio_asc' value='asc' class='radio' checked>
                    <label for='radio_desc'>Maior preço</label><input type='radio' name='radio' id='radio_desc' value='desc' class='radio'>
                  </div>
                  <div class='btn_filtrar'>
                    <button>Filtrar</button>
                  </div>
                </form>
              </div>
              <div class='caixa_mostrar_produtos'>
              ";
              while($row=$result->fetch_array()){
                $id = $row['id_produtos'];
                $data = $row['data_cad'];
                $nome = $row['nome_produtos'];
                $categoria =  $row['categoria'];
                $preco = $row['valor'];
                $imagem = $row['imagem'];
                $data = tratar_data($data);
                $preco=tratar_preco($preco);
                echo"
                  <div class='novo_container_produto'>
                    <figure>
                    <img src='upload/$imagem' alt=''>
                    </figure>
                    <div class='info'>
                      <div class='titulo'>
                        $nome
                      </div>
                      <div class='week'>
                        $data
                      </div>
                      <div class='preco'>
                        R$ $preco
                      </div>
                      <div class='btn' onclick='direcionar(15,$id)'>
                        Clique para mais informações
                      </div>
                    </div>
                  </div>
                ";
              }
              echo"
              </div>
            </div>
          ";
            echo"
            <div class='paginacao' id='paginacao'>
              <div class='primeiro' id='primeiro'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
              <div class='anterior'id='anterior'><img src='img/seta-direita.png' alt=''></div>
              <div class='container_number' id='numbers'>
                <div class='numbers_style'>1</div>
              </div>
              <div class='proximo'id='proximo'><img src='img/seta-direita.png' alt=''></div>
              <div class='ultimo'id='ultimo'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
            </div>
            <script>
              paginacao($total);
              abrir_filtro();
            </script>
            ";
          }
        }elseif($a =='mostrar_produtos'){
          $busca=isset($_GET['busca'])?$_GET['busca']:'';
          $pesquisa=isset($_GET['serach'])?$_GET['serach']:'';
          $id = $_GET['id'];
          $sql = "select * from $BD.produtos where id_produtos = $id";
          $result = mysqli_query($conexao,$sql);
          $array = mysqli_fetch_assoc($result);
          $imagem=$array['imagem'];
          $id = $array['id_produtos'];
          $nome=$array['nome_produtos'];
          $nome_mercado=$array['nome_mercado'];
          $marca=$array['Marca'];
          $preco = $array['valor'];
          $categoria=$array['categoria'];
          $preco=tratar_preco($preco);
          $pais = $array['pais'];
          $estado=$array['estado'];
          $cidade=$array['cidade'];
          $bairro=$array['bairro'];
          $texto = $array['descricao'];
          $palavras = $array['palavras_chaves'];
          $palavras=explode(' ',$palavras);
          $sql_ralacionados="select * from  $BD.produtos where id_produtos <> $id and categoria=$categoria and nome_produtos like '%$nome%' or categoria=$categoria and  palavras_chaves like '%".$palavras[0]."%' and id_produtos <> $id";
          $sql_cidades="select * from produtos where categoria=$categoria and nome_produtos = '$nome' and cidade <> 'Cidade não informada' and id_produtos <> $id";
          $resultado = mysqli_query($conexao,$sql_ralacionados);
          $categoria=isset($_GET['categoria'])?$_GET['categoria']:'';
          $sub_categoria=isset($_GET['subcategoria'])?$_GET['subcategoria']:'';
          $sub_categoria=str_replace("_"," ",$sub_categoria);
          if($categoria != ''){
            echo"
            <div class='taxonomia'>
            <strong><a href='./'>Home</a> / <a href='?a=categorias&a2=$categoria'>$categoria</a> / <a href='?a=sub_categoria&a2=$sub_categoria&categoria=$categoria'>$sub_categoria</a> / <a href='?a=mostrar_produtos&id=$id&categoria=$categoria&subcategoria=$sub_categoria'>$nome</a></strong>
            </div>
            ";
          }else if($pesquisa !=''){
            echo"
            <div class='taxonomia'>
            <strong><a href='./'>Home</a> / <a href='?p=$pesquisa'>Pesquisa</a> / <a href='?a=mostrar_produtos&id=$id&busca=true&serach=$pesquisa'>$nome</a></strong>
            </div>
            ";
          }
          echo "
          <br>
          <div class='container_mostrar_produtos_descricao'>
            <div class='info_produtos'>
              <div class='nome'>
                $nome
              </div>
              <div class='preco'>
                R$ $preco
              </div>
              <div class='localidade'>
                <h1>Localidade</h1>
                <table>
                 <tr>
                    <th>
                      Pais:
                    </th>
                    <td>
                      <p>$pais</p>
                    </td>
                 </tr>
                 <tr>
                  <th>
                    Estado:
                  </th>
                  <td>
                    <p>$estado</p>
                  </td>
                 </tr>
                 <tr>
                  <th>
                    Cidade:
                  </th>
                  <td>
                    <p>$cidade</p>
                  </td>
                </tr>
                <tr>
                  <th>
                    Bairro:
                  </th>
                  <td>
                    <p>$bairro</p>
                  </td>
                </tr>
                </table>
              </div>
            </div>
            <div class='container_figure_desc'>
              <figure>
                <img src='upload/$imagem' alt=''>
              </figure>
              <div class='caracteristicas_principais'>
              <table>
               <tr>
                  <th>
                    Marca
                  </th>
                  <td>
                    <p>$marca</p>
                  </td>
               </tr>
               <tr>
                  <th>
                    Mercado
                  </th>
                  <td>
                    <p>$nome_mercado</p>
                  </td>
               </tr>
              </table>
              </div>
              <div class='descricao'>
                <div class='titulo'>
                  <h1>Descrição</h1>
                </div>
                <div class='texto'>
                 $texto
                </div>
              </div>
              ";
              $consulta=mysqli_query($conexao,$sql_cidades);
              if(mysqli_num_rows($consulta) > 0){
                echo"
                <div class='container_ver_produto_outros_paises'>
                <h1>Esse produto em outras cidades</h1>
                  <table>
                  ";
                  $consulta=mysqli_query($conexao,$sql_cidades);
                  while($array=mysqli_fetch_assoc($consulta)){
                    $city=$array['cidade'];
                    $valor=$array['valor'];
                    $name=$array['nome_produtos'];
                    $id=$array['id_produtos'];
                    $mercado=$array['nome_mercado'];
                    if($city=="Cidade não informada"){
                      
                    }else{
                      echo"
                        <tr>
                          <th>
                            $city
                          </th>
                          <td>
                            $nome
                          </td>
                          <td>
                            R$$valor
                          </td>
                          <td>
                            <button onclick='direcionar(14,$id)'>
                              Ver produto
                            </button>
                          </td>
                        </tr>
                      ";
                    }
                  }
                  echo"
                  </table>
                </div>
                ";
              }
              echo"
            </div>
            <div class='container_mudar_preco'>
              <button onclick='sugerir_mudanca()'>Deseja sugerir uma mudança de preço ?</button>
              <div class='container_form' id='container_form'>
                <form action='?a2=mudar_preco&id=$id' method='post' onsubmit='return validar_mudanca_preco()'>
                  Digite o novo preço: <br><input type='text' class='input' name='preco_novo' id='preco' autocomplete = 'off' onkeyup = "."formatarMoeda()"." maxlength='9'  placeholder='Informe o preço aqui'>
                  <input type='submit' value='Enviar'>
                </form>
              </div>
              <br>
            </div>
          </div> 
            <br>
            <div class='segunda_parte'>
              <h1>Produtos Relacionados</h1>
              <div class='container_box'>
              ";
              while($row=$resultado->fetch_array()){
                $id_relacional=$row['id_produtos'];
                $imagem=$row['imagem'];
                $nome=$row['nome_produtos'];
                $data=$row['data_cad'];
                $data=tratar_data($data);
                $preco=$row['valor'];
                $preco = tratar_preco($preco);
                if($categoria !=''){
                  $direcionar="direcionar(1,$id_relacional,`$categoria`,`$sub_categoria`)";
                }else{
                  $direcionar="direcionar(14,$id_relacional)";
                }
                echo "
                  <div class='box'   onclick='$direcionar'>
                    <img src='upload/$imagem' alt=''>
                    <div class='data'>
                      $data
                    </div>
                    <div class='nome'>
                      <p>$nome</p>
                    </div>
                    <div class='preco'>
                      $preco R$
                    </div>
                    <div class='info'>
                      clique para mais informações
                    </div>
                  </div class='box'>
                ";
              }
              echo "
              </div>
            </div>
            <br>
          ";
          if($busca=='true'){
            $add="insert into mais_acessados(id_produto)values($id)";
            $verificar="select * from mais_acessados where id_produto=$id";
            $consulta=mysqli_query($conexao,$verificar);
            if(mysqli_num_rows($consulta)>0){
            }else{
              $consulta2=mysqli_query($conexao,$add);
            }
          }
        }elseif($a=='categorias'){
          echo"
          <div class='head_categoria'>
          </br>
          </br>
            $a2
          </div>
          ";
          $t="";
          $sql="select * from referencia_nome_tables 
          INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias where categorias.categoria like '%$a2%' limit 1";
          $resutado = mysqli_query($conexao,$sql);
          $row=mysqli_num_rows($resutado);
          $nao_tem_produto=false;
          if($row>0){
            $array=mysqli_fetch_assoc($resutado);
            $sub_categoria_caminho=$array['caminho_subcategorias'];
            $t="select * from $sub_categoria_caminho";
          }else{
            
          }
          if($t!=''){
            $resutado = mysqli_query($conexao,$t);
            echo "
            <div class='taxonomia'>
              <strong><a href='./'>Home</a> / <a href='?a=categorias&a2=$a2'>$a2</a></strong>
            </div>
            <div class='container_subcategorias'>
              <div class='subcategorias'>
              ";
              while($row=$resutado->fetch_array()){
                $sub_categoria=$row['sub_categoria'];
                $select="select * from referencia_nome_tables INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias 
                inner join nome_categorias on referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where subcategoria='$sub_categoria'";
                $consulta=mysqli_query($conexao,$select);
                $array=mysqli_fetch_assoc($consulta);
                $nome_visual=$array['nome'];
                $img_sub_categoria=$row['img_categoria'];
                $sub_categoria_url=str_replace(" ","_",$sub_categoria);
                if($nome_visual != ''){
                  $select="select * from produtos join nome_categorias on produtos.categoria= nome_categorias.id where nome='$nome_visual'";
                  $consulta=mysqli_query($conexao,$select);
                }
                if($row=mysqli_num_rows($consulta)>0){
                  echo "
                  <div onclick='direcionar_subcategorias(`$sub_categoria_url`,`$a2`)' class='content'>
                    <figure>
                      <img src='img_categorias/$img_sub_categoria' alt=''>
                    </figure>
                    <footer>
                      $sub_categoria
                    </footer>
                  </div>
                ";
                }else{
                  
                }
              }
              echo "
              </div>
            </div>
            ";
          }
        }elseif($a=='Cadastrar_produto'){
          echo"
          <div class='container_categoria_cadastro'>
            <div class='head'>
              <p>Antes de tudo, que produto você vai cadastrar ?</p>
            </div>
            <div class='contaier_max'>
              <div class='container_balls'>
                <div id='Produto'>
                  <figure>
                    <img src='img_categorias/sacolas-de-compras.svg' alt='' width='100' height='100'>
                  </figure>
                </div>
                <p>Produtos e Elétrodomesticos</p>
              </div>
              <div class='container_balls'>
                <div id='moveis'>
                  <figure>
                    <img src='img_categorias/trabalho-a-partir-de-casa.svg' alt='' width='100' height='100'>
                  </figure>
                </div>
                <p>Moveis e Decorações</p>
              </div>
            </div>
          </div>
          <script>
            cadasto_produtos();
          </script>
          ";
        }elseif($a=='sub_categoria'){
          $sql="select * from referencia_nome_tables 
          INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where referencia_nome_tables.subcategoria like '%$a2%';";
          $re2=mysqli_query($conexao,$sql);
          $row=mysqli_num_rows($re2);
          $categoria1=$_GET['categoria'];
          if($row>0 && $row<2){
            $array=mysqli_fetch_assoc($re2);
            $t=$array['nome_categoria'];
          }
          if($t!=''){
            $sql="select * from produtos
            INNER JOIN nome_categorias ON produtos.categoria = nome_categorias.id where nome_categorias.nome_categoria ='$t' order by data_cad DESC limit $inicio,$qunt_pagina";
            $resutado=mysqli_query($conexao,$sql);
            $frase=str_replace("_"," ",$a2);

            echo"
            </br>
            <div class='taxonomia'>
            <strong><a href='./'>Home</a> / <a href='?a=categorias&a2=$categoria1'>$categoria1</a> / <a href='?a=sub_categoria&a2=$a2&categoria=$categoria1'>$frase</a></strong>
            </div>
            <br>
              ";
              echo"
                <div class='container_filtro_mostrar_produtos'> 
                  <div class='btn_mostrar_filtro'>
                    <button id='btn_filtro'>
                    <img src='img/filter.svg' alt=''>
                    </button>
                  </div>
                  <div class='filtro_produtos_outro' id='container_filtro'>
                      <div class='head_filtro'>
                        Filtro
                        <div class='btn_fechar_filtro'>
                          <button id='btn_fechar_filtro'><img src='img/close.svg' alt=''></button>
                        </div>
                      </div>
                    <form action='' method='get'>
                      <div class='container_inputs'>
                        <h1>Informações sobre o produto</h1>
                        <div class='nome_produto'>
                          <div class='label'>
                            Nome do produto:
                          </div>
                          <input type='text' name='nome_categoria' id='categoria_filtro' autocomplete='off' value='$a2'>
                          <input type='text' name='nome' id='nome_filtro' autocomplete='off'>
                        </div>
                        <div class='marca'>
                          <div class='label'>
                            Nome da marca:
                          </div>
                          <input type='text' name='marca' id='marca_filtro' autocomplete='off'>
                        </div>
                        <div class='mercado'>
                          <div class='label'>
                            Digite o mercado
                          </div>
                          <input type='text' name='mercado' id='mercado_filtro' autocomplete='off'>
                        </div>
                      </div>
                      <div class='container_inputs'>
                        <h1>Localização:</h1>
                        <div class='pais'>
                        <div class='label'>
                          Pais
                        </div>
                          <input type='text' name='pais' id='pais_filtro' autocomplete='off'>
                        </div>
                        <div class='estado'>
                        <div class='label'>
                          Estado
                        </div>
                          <input type='text' name='estado' id='estado_filtro' autocomplete='off'>
                        </div>
                        <div class='cidade'>
                        <div class='label'>
                          Cidade
                        </div>
                          <input type='text' name='cidade' id='cidade_filtro' autocomplete='off'>
                        </div>
                        <div class='bairro'>
                        <div class='label'>
                          Bairro
                        </div>
                          <input type='text' name='bairro' id='bairro_filtro' autocomplete='off'>
                        </div>
                      </div>
                      <div class='container_inputs'>
                        <h1>Ordenar por</h1>
                        <label for='radio_asc'>Menor preço</label><input type='radio' name='radio' id='radio_asc' value='asc' class='radio' checked>
                        <label for='radio_desc'>Menor preço</label><input type='radio' name='radio' id='radio_desc' value='desc' class='radio'>
                      </div>
                      <div  class='container_inputs'>
                        <div class='btn_filtrar'>
                          <button>Filtrar</button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class='filtro_produtos'>
                    <form action='' method='get'>
                      <div class='container_inputs'>
                        <h1>Informações sobre o produto</h1>
                        <div class='nome_produto'>
                          <div class='label'>
                            Nome do produto:
                          </div>
                          <input type='text' name='nome_categoria' id='categoria_filtro' autocomplete='off' value='$a2'>
                          <input type='text' name='nome' id='nome_filtro' autocomplete='off'>
                        </div>
                        <div class='marca'>
                          <div class='label'>
                            Nome da marca:
                          </div>
                          <input type='text' name='marca' id='marca_filtro' autocomplete='off'>
                        </div>
                        <div class='mercado'>
                          <div class='label'>
                            Digite o mercado
                          </div>
                          <input type='text' name='mercado' id='mercado_filtro' autocomplete='off'>
                        </div>
                      </div>
                      <div class='container_inputs'>
                        <h1>Localização:</h1>
                        <div class='pais'>
                        <div class='label'>
                          Pais
                        </div>
                          <input type='text' name='pais' id='pais_filtro' autocomplete='off'>
                        </div>
                        <div class='estado'>
                        <div class='label'>
                          Estado
                        </div>
                          <input type='text' name='estado' id='estado_filtro' autocomplete='off'>
                        </div>
                        <div class='cidade'>
                        <div class='label'>
                          Cidade
                        </div>
                          <input type='text' name='cidade' id='cidade_filtro' autocomplete='off'>
                        </div>
                        <div class='bairro'>
                        <div class='label'>
                          Bairro
                        </div>
                          <input type='text' name='bairro' id='bairro_filtro' autocomplete='off'>
                        </div>
                      </div>
                      <div class='container_inputs'>
                        <h1>Ordenar por</h1>
                        <br>
                        <label for='radio_asc'>Menor preço</label><input type='radio' name='radio' id='radio_asc' value='asc' class='radio' checked>
                        <label for='radio_desc'>Menor preço</label><input type='radio' name='radio' id='radio_desc' value='desc' class='radio'>
                      </div>
                      <div class='btn_filtrar'>
                        <button>Filtrar</button>
                      </div>
                    </form>
                  </div>
                  <div class='caixa_mostrar_produtos'>
                  ";
                  while($row=$resutado->fetch_array()){
                    $id = $row['id_produtos'];
                    $data = $row['data_cad'];
                    $nome = $row['nome_produtos'];
                    $categoria =  $row['categoria'];
                    $preco = $row['valor'];
                    $imagem = $row['imagem'];
                    $data = tratar_data($data);
                    $preco=tratar_preco($preco);
                    echo"
                      <div class='novo_container_produto'>
                        <figure>
                        <img src='upload/$imagem' alt=''>
                        </figure>
                        <div class='info'>
                          <div class='titulo'>
                            $nome
                          </div>
                          <div class='week'>
                            $data
                          </div>
                          <div class='preco'>
                            R$ $preco
                          </div>
                          <div class='btn' onclick='direcionar(1,$id,`$categoria1`,`$a2`)'>
                            Clique para mais informações
                          </div>
                        </div>
                      </div>
                    ";
                  }
                  echo"
                  </div>
                </div>
              ";
            $result_pg="select * from produtos
            INNER JOIN nome_categorias ON produtos.categoria = nome_categorias.id where nome_categorias.nome_categoria ='$t'";
            $resultado_pg=mysqli_query($conexao,$result_pg);
            $row_pg=mysqli_num_rows($resultado_pg);
            if($row_pg>0){
              echo "
              <div class='paginacao' id='paginacao'>
                <div class='primeiro' id='primeiro'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
                <div class='anterior'id='anterior'><img src='img/seta-direita.png' alt=''></div>
                <div class='container_number' id='numbers'>
                  <div class='numbers_style'>1</div>
                </div>
                <div class='proximo'id='proximo'><img src='img/seta-direita.png' alt=''></div>
                <div class='ultimo'id='ultimo'><img src='img/simbolo-de-setas-duplas.png' alt=''></div>
              </div>
              <script>
                paginacao($row_pg);
                 abrir_filtro();
              </script>
              ";
            }
          }
        }elseif($a=='faleConosco'){
          echo"
          <div class='formulario_faleConosco'>
            <div class='head'>
              Fale Conosco
            </div>
            <form action='?a=enviar_email' method='post' onsubmit = 'return validar_fale()'>
              <div class='campo'>
                <img src='img/usu.svg' alt=''>
                <input type='text' name='nome_usu' id='nome_usu' placeholder='Digite seu nome aqui' autocomplete='off'>
              </div>
              <div class='campo'>
                <img src='img/arroba.svg' alt=''>
                <input type='email' name='email_usu' id='email_usu' placeholder='Digite seu nome email aqui' autocomplete='off'>
              </div>
              <div class='campo'>
                <img src='img/caneta.svg' alt=''>
                <input type='text' name='assunto' id='assunto' placeholder='Assunto' autocomplete='off'>
              </div>
              <div class='campo'>
                <img src='img/email.svg' alt=''><label for='mensagem'>Mensagem</label>
                <textarea name='mensagem' id='mensagem' cols='30' rows='10' maxlength='500' placeholder=''>
      
                </textarea>
              </div>
              <div class='campo sumir'>
                <button>Enviar</button>
              </div>
            </form>
          </div>
          <script>
            script_tirar_espacos(`mensagem`)
          </script>
          ";
        }
      ?>
    </div>
  </div>
  <script>
    <?php
        $palavra_categoria="";
        $sql_produtos="select * from referencia_nome_tables 
          INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id  where (categoria like '%Alimentos e Bebidas%' or categoria like '%Beleza e Cuidado Pessoal%' or categoria like '%Games%'  or categoria like'%Informatica%' or categoria like'%Esportes%' or categoria like'%Pets%' or categoria like '%Eletrodomésticos%'  or categoria like'%Móveis e decoração%' or categoria like'%Produtos de limpeza%') and palavras_categoria <> ''";
          $resutado=mysqli_query($conexao,$sql_produtos);
        while($row=$resutado->fetch_array()){
          $palavra_categoria.= trim($row['palavras_categoria']);
        };
        echo 'historico("'.$palavra_categoria.'");';
      ?>
      caixa_de_pesquisa();  
      trocar_imagens();
      header_fixed();
      imagem_grande();
  </script>
  <?php
  include('rodape.php');
  ?>
</body>
</html>