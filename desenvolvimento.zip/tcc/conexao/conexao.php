<?php
if($_SERVER['SERVER_NAME']=='precofacil.eteccruzeiro.dev.br'){
  $host = 'localhost';
  $usuario = 'eteccr31_21_1_ex';
  $senha = '123456';
  $BD = 'eteccr31_21_1_elementox';
}else{
  $host = 'localhost';
  $usuario = 'root';
  $senha = '';
  $BD = 'projeto';
}
$conexao = mysqli_connect($host,$usuario,$senha,$BD);
?>