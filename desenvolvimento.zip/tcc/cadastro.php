<?php
  include('conexao/conexao.php');
  include('funcoes_tratamento/funcoes.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro</title>
  <link rel="stylesheet" href="css/css.css">
  <script src="js.js"></script>
  <style>
    body{
      background-color: #F5F4F6;
    }
  </style>
  <?php
    $a=$_GET['a'];
    $a2=isset($_GET['a2'])?$_GET['a2']:'';
    if($a=='cadastro_produto'){
      $aviso="";
      $nome=trim(ucfirst(isset($_POST['nome'])?$_POST['nome']:'none'));
      $categoria=$_POST['categoria'];
      $nome_mercado=trim(ucfirst(isset($_POST['mercado'])?$_POST['mercado']:''));
      $preco=isset($_POST['preco'])?$_POST['preco']:'';
      $marca=trim(ucfirst(isset($_POST['marca'])?$_POST['marca']:''));
      $pais=trim(ucfirst(isset($_POST['pais'])?$_POST['pais']:''));
      $estado=trim(ucfirst(isset($_POST['estado'])?$_POST['estado']:''));
      $cidade=trim(ucfirst(isset($_POST['cidade'])?$_POST['cidade']:''));
      $bairro=trim(ucfirst(isset($_POST['bairro'])?$_POST['bairro']:''));
      $img=isset($_FILES['img_foto'])?$_FILES['img_foto']:'none';
      $comentario=trim(isset($_POST['comentario'])?$_POST['comentario']:'');
      $palavras_chaves=isset($_POST['palavras'])?$_POST['palavras']:'';

      /*tratamento*/
      $precolen = strlen($preco);
      if($precolen <= 6){
        $preco = str_replace(",",".",$preco);
      }else if($precolen >= 8){
        $preco = str_replace(".","",$preco);
        $preco = str_replace(",",".",$preco);
      }
      $palavras_chaves = str_replace("."," ",$palavras_chaves);
      if($categoria !=''){
        $largura = "300";
        $altura = "300";
        $config = array();
        $config['tamanho'] =11339870 ;
        $config['largura'] = 300;
        $config['altura'] = 300;
        $angulo = -90.0;
        $error = array();
        if($img !='none'){
          if($img['type'] !='image/jpeg' && $img['type'] !='image/png'){
            $error[]= "Arquivo em formato inválido! A imagem deve ser jpg, jpeg, ou png. Envie outro arquivo";
          }else{
            if($img["size"] > $config["tamanho"]){
              $erro[] = "Arquivo em tamanho muito grande!";
            }
            $tamanhos = getimagesize($img["tmp_name"]);
            if($tamanhos[0]>$config['largura']){
              $erro[] = "Largura da imagem não deve ultrapassar " . $config["largura"] . " pixels";
            }
            if($tamanhos[1] > $config['altura']){
              $erro[] = "Altura da imagem não deve ultrapassar " . $config["altura"] . " pixels";
            }
          }
          if(sizeof($error) > 0){
            foreach($error as $err){
              $aviso = $aviso."#".$err."\\n";
            }
          }else{
            if($img['type'] == 'image/jpeg'){
              $imagem_temporaria = imagecreatefromjpeg($_FILES['img_foto']['tmp_name']);
              $larguta_original = imagesx($imagem_temporaria);
              $altura_original = imagesy($imagem_temporaria);
              $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
              $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
              $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
              imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
              preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
              //$_Imagem_Rotacionada =  imagerotate($imagem_redimensionada, $angulo, 0);
              $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
              if(imagejpeg($imagem_redimensionada,'upload/'.$imagem_nome)){
               $sql="insert into aprovacao(nome_aprovacao,marca,nome_mercado,valor,imagem,categoria,pais,estado,cidade,bairro,descricao,data_cad,palavras_chaves)values('$nome','$marca','$nome_mercado',$preco,'$imagem_nome',$categoria,'$pais','$estado','$cidade','$bairro','$comentario',now(),'$palavras_chaves')";
                if(mysqli_query($conexao,$sql)){
                  $aviso = 'Sua postagem foi encaminhada para a aprovação';
                }else{
                  $aviso = "Sua postagem não foi enviada, tente denovo";
                }
              }
            }elseif($img['type'] == 'image/png'){
              $imagem_temporaria = imagecreatefrompng($_FILES['img_foto']['tmp_name']);
              $larguta_original = imagesx($imagem_temporaria);
              $altura_original = imagesy($imagem_temporaria);
              $nova_largura = $largura?$largura:floor(($larguta_original/$altura_original)*$altura);
              $nova_altura = $altura?$altura:floor(($altura_original/$larguta_original)*$largura);
              $imagem_redimensionada = imagecreatetruecolor($nova_largura,$nova_altura);
              imagecopyresampled($imagem_redimensionada, $imagem_temporaria, 0,0,0,0, $nova_largura,$nova_altura,$larguta_original,$altura_original);
              preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $img["name"], $ext);
              $imagem_nome = md5(uniqid(time())) . "." . $ext[1];
              $imagem_dir = "img/" . $imagem_nome;
              $aviso = "Cadastramento incorreto, verifique se a imagem é muito grande";
              if(imagepng($imagem_redimensionada,'upload/'.$imagem_nome)){
                $sql = "insert into $BD.aprovacao (nome_aprovacao,marca,nome_mercado,valor,imagem,categoria,pais,estado,cidade,bairro,descricao,data_cad,palavras_chaves)values('$nome','$marca','$nome_mercado',$preco,'$imagem_nome',$categoria,'$pais','$estado','$cidade','$bairro','$comentario',now(),'$palavras_chaves')";
                if(mysqli_query($conexao,$sql)){
                  $aviso = 'Sua postagem foi encaminhada para a aprovação';
                }else{
                  $aviso = "Sua postagem não foi enviada, tente denovo";
                }
              }
            }
          }
        }
        if($aviso !=''){
          echo '<script>alert("'.$aviso.'");location.href="?a=cadastro_ok&a2='.$categoria.'";</script>';
        }
      }
    }elseif($a=='escolher_categorias'){
      $nome_p=$_POST['nomep'];
      if($nome_p != ''){
        $sql="select * from referencia_nome_tables 
        Inner join nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id
        inner join categorias ON referencia_nome_tables.caminho = categorias.id_categorias  where palavras_categoria like '%$nome_p%';";
        $consulta=mysqli_query($conexao,$sql);
        /*
        while($row=$resutado->fetch_array()){
          $linha=mysqli_num_rows($resutado);
          if($linha>0){
            $categoria=$row['nome_categoria'];
            $categoria_id=$row['id'];
          }
        }
        */
      }
    }
  ?>
</head>
<body>
  <header class='header_cadastro'>
    <h1>Cadastrar produto</h1>
    <br>
    <br>
    <a href="index.php">Voltar para página principal</a>
  </header>
  <div class="container_scroll_form" id='container_scroll_form'>
    <?php
      if($a=='produtos'){
        if($a2=='confirm'){
          $nome_produto=$_POST['nome_produto'];
          $nome_categoria=$_POST['categoria'];
         $sql="select id,nome_categoria from referencia_nome_tables 
          INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where nome='$nome_categoria'";
          $consulta=mysqli_query($conexao,$sql);
          $row=mysqli_fetch_assoc($consulta);
          $id_categoria=$row['id'];
        }elseif($a2=='trocar'){
          $nome_categoria=$_POST['categoria_nova'];
          $sql="select id,nome_categoria from referencia_nome_tables 
          INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where subcategoria='$nome_categoria'";
          $consulta=mysqli_query($conexao,$sql);
          $row=mysqli_fetch_assoc($consulta);
          $nome_produto=$_POST['nome_produto'];
          $id_categoria=$row['id'];
        }
        echo'
        <div class="info_pagina">
        <br>
        <h6>Etapa 2/2</h6>
        <br>
          <p>Agora informe os resto das informações do produto</p>
        </div>
        <form action="?a=cadastro_produto" method="post" onsubmit="return validar_cad()" enctype="multipart/form-data">
          <div class="part_form" id="form1">
            <div class="info">
             Informe a marca, o nome mercado que o produto esta e o valor
            </div>
            <div class="inputs">
              <input type="text" name="nome" id="nome" placeholder="" autocomplete="off" value="'.$nome_produto.'">
              <input type="text" name="categoria" id="categoria" placeholder="" autocomplete="off" value="'.$id_categoria.'">
              <br>
              <input type="text" name="mercado" id="mercado" placeholder="Digite o nome do mercado" autocomplete="off">
              <br>
              <input type="text" name="marca" id="marca" placeholder="Digite o nome da marca do produto" autocomplete="off">
              <br>
              <input type="text" name="preco" id="preco" placeholder="00,00" autocomplete="off"  onkeyup = "formatarMoeda()" maxlength="9">
            </div>
            <hr>
            <div class="btn_proximo1" id="next">
              Proximo
            </div>
          </div>
          <div class="part_form" id="form2">
            <div class="info">
              Informe a localização para outras pessoas acharem o produto
            </div>
            <div class="inputs">
              <input type="text" name="pais" id="pais" placeholder="Pais:" autocomplete="off" value="Brasil">
              <br>
              <input type="text" name="estado" id="estado" placeholder="Estado:" autocomplete="off">
              <br>
              <input type="text" name="cidade" id="cidade" placeholder="Cidade:" autocomplete="off">
              <br>
              <input type="text" name="bairro" id="bairro" placeholder="Bairro:" autocomplete="off">
            </div>
            <hr>
            <div class="container_btn">
              <div class="btn_anterior" id="anterior">
                Anterior
              </div>
              <div class="btn_proximo" id="pular">
                Proximo
              </div>
            </div>
          </div>
          <div class="part_form" class="part_file" id="form3">
            <div class="info">
              Mande um foto do produto que você quer mostrar
            </div>
            <div class="inputs">
              <input type="file" name="img_foto" id="img" onchange = "preview()">
            </div>
            <div class="preview" id="preview">
              <img id="img_preview" src="img/noimage.jpg" alt="" width="200" height="200">
            </div>
            <hr>
            <div class="container_btn">
              <div class="btn_anterior" id="anterior_img">
                Anterior
              </div>
              <div class="btn_proximo" id="next_desc">
                Proximo
              </div>
            </div>
          </div>
          <div class="part_form" id="form4">
            <div class="info">
              Você quer adicionar uma descrição ?(opcional)
            </div>
            <div class="inputs">
              <textarea name="comentario" id="comentario"  rows="10" maxlength = "500" placeholder="Digite a sua opnial sobre o produto aqui" autocomplete="off">
          
              </textarea>
            </div>
            <hr>
            <div class="container_btn">
              <div class="btn_anterior" id="anterior_words">
                Anterior
              </div>
              <div class="btn_proximo" id="next_words">
                Proximo
              </div>
            </div>
          </div>
          <div class="part_form" id="form5">
            <div class="info">
              Adicione as palavras chaves para que outras pessoas possam encontrar o produto
            </div>
            <div class="inputs">
              <div class = "container">
                <input type="text" name = "palavras" id = "palavras" class="input_tags" autocomplete = "off" placeholder="Adicione as palavras chaves para que outras pessoas possam encontrar o produto"><span class = "add" onclick = "tecla_chave()">+</span><span class="reset"onclick = "reset()">Reset</span>
                  <div class = "tag_container" id="tag_container">
            
                  </div>
                </div>
              </div>
            <hr>
            <div class="container_btn">
              <div class="btn_anterior" id="anterior_palavras_chaves">
                Anterior
              </div>
              <div class="input_cadastro">
                <input type="submit">
              </div>
            </div>
          </div>
        </form>
        <script>
          script_tirar_espacos(`comentario`);
        </script>
        ';
      }elseif($a=='escolher_categorias'){
        $select = mysqli_num_rows($consulta);
        if($select < 1){
          if($a2=='produto'){
            $sql_cod="select * from referencia_nome_tables 
            INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where caminho_subcategorias = 'subcategoria_alimentos' or caminho_subcategorias='subcategorias_beleza'
            or caminho_subcategorias='subcategorias_games' or caminho_subcategorias='subcategorias_informatica' or caminho_subcategorias='subcategorias_esportes' or caminho_subcategorias='subcategorias_pets'
            or caminho_subcategorias='subcategorias_beleza' or caminho_subcategorias='subcategorias_eletrodometicos' or caminho_subcategorias='subcategorias_produtos_limpeza';";
          }elseif($a2=='movel'){
            $sql_cod="select * from referencia_nome_tables 
            INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where caminho_subcategorias = 'subcategorias_moveis_decoracao';";
          }
          $resultado=mysqli_query($conexao,$sql_cod);
          echo "
          <div class='container_categoira_confirmar'>
            <div class='info'>
              Ops!, não foi achado nenhuma categoria de compativel com <br>o produto, porfavor insira um categoria ao produto<br>clicando em mudar a categoria
            </div>
              <div class='categoria_ver'>
                <input type='text' name='nome_produto' id='nome_produto' autocomplete='off' class='input_nome' value='$nome_p'>
                <h1>$nome_p</h1></br>
                <div class='mostrar_categoria'>
                  <p><strong>Categoria: </strong>Sem categoria</p>
                </div>
              </div>
              <form action='?a=produtos&a2=trocar' method='post' onsubmit=' return validar_escolher_categorias()'>
                <div class='mudar_categoria'>
                  <input type='text' name='nome_produto' id='nome_categoria' autocomplete='off' class='input_nome' value='$nome_p'>
                  <span id='nova_categoria'>Deseja mudar a categoria?</span><br><br>
                  <select name='categoria_nova' id='categoria_nova'>
                  <option value='nenhum' selected >Nenhum</option>
                  ";
                    while($linha=$resultado->fetch_array()){
                      $cad=$linha['subcategoria'];
                      echo "
                      <option value='$cad'>$cad</option>
                      ";
                    }
                    echo"
                  </select>
                  <input type='submit' value='Confirmar' id='trocar_categoria' class='submit'>
                </div>
              </form>
            </div>
          <script>
            sugerir_nova_categoria();
          </script>
          ";
        }else{
          $array=mysqli_fetch_assoc($consulta);
          $caminho=$array['categoria'];
          $subcategoria=$array['subcategoria'];
          $categoria=$array['nome'];
          $caminho_subcatgorias=$array['caminho_subcategorias'];
          if($a2=='produto'){
           $sql_cod="select * from referencia_nome_tables 
            INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where caminho_subcategorias = 'subcategoria_alimentos' or caminho_subcategorias='subcategorias_beleza'
            or caminho_subcategorias='subcategorias_games' or caminho_subcategorias='subcategorias_informatica' or caminho_subcategorias='subcategorias_esportes' or caminho_subcategorias='subcategorias_pets'
            or caminho_subcategorias='subcategorias_beleza' or caminho_subcategorias='subcategorias_eletrodometicos';";
          }elseif($a2=='movel'){
            $sql_cod="select * from referencia_nome_tables 
            INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id where caminho_subcategorias = 'subcategorias_moveis_decoracao';";
          }
          $resultado=mysqli_query($conexao,$sql_cod);
          $sql_img="select img_categoria from $caminho_subcatgorias where sub_categoria='$subcategoria'";
          $resutado_img=mysqli_query($conexao,$sql_img);
          $array2=mysqli_fetch_assoc($resutado_img);
          $img_subcategoria=$array2['img_categoria'];
          echo "
          <form action='?a=produtos&a2=confirm' method='post'>
            <div class='container_categoira_confirmar'>
              <div class='info'>
              Colocamos o produto nessa categoria  <br> selecione se estiver correto.
              </div>
              <br>
              <div class='categoria_ver'>
              <input type='text' name='nome_produto' id='nome_produto' autocomplete='off' class='input_nome' value='$nome_p'>
              <input type='text' name='categoria' id='nome_cate' autocomplete='off' class='input_nome' value='$categoria'>
                <h1>$categoria</h1></br>
                <div class='mostrar_categoria'>
                  <p><strong><img src='img_categorias/$img_subcategoria' alt=''></strong></p><input type='submit' value='Confirmar categoria' class='submit'>
                </div>
              </div>
          </form>
          <form action='?a=produtos&a2=trocar' method='post'>
              <div class='mudar_categoria'>
              <input type='text' name='nome_produto' id='nome_produto' autocomplete='off' class='input_nome' value='$nome_p'>
                <span id='nova_categoria'>Deseja mudar a categoria?</span><br><br>
                <select name='categoria_nova' id='categoria_nova'>
                <option value='nenhum' selected >Nenhum</option>
                ";
                  while($linha=$resultado->fetch_array()){
                    $cad=$linha['subcategoria'];
                    echo "
                    <option value='$cad'>$cad</option>
                    ";
                  }
                  echo"
                </select>
                <input type='submit' value='Trocar' id='trocar_categoria' class='submit'>
              </div>
            </div>
          </form>
          <script>
            sugerir_nova_categoria();
          </script>
          ";
        }
      }elseif($a=='cadastrar_produto_ou_movel'){
        if($a2=='produto'){
            $sql_produtos="select * from referencia_nome_tables 
          INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id  where (categoria like '%Alimentos e Bebidas%' or categoria like '%Beleza e Cuidado Pessoal%' or categoria like '%Games%'  or categoria like'%Informatica%' or categoria like'%Esportes%' or categoria like'%Pets%' or categoria like '%Produtos de Limpeza%' or categoria like '%Eletrodomésticos%') and palavras_categoria <> ''";
          $txt="produto";
        }elseif($a2='movel'){
          $sql_produtos="select * from referencia_nome_tables 
          INNER JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id  where categoria like'%Móveis e decoração%'  and palavras_categoria <> ''";
          $txt="movel";
        }
        $resutado=mysqli_query($conexao,$sql_produtos);
        echo "
        <div class='info_pagina'>
        <br>
        <h6>Etapa 1/2</h6>
        <br>
          <p>Para começar basta digitar o nome do produto</p>
        </div> 
        <form action='?a=escolher_categorias&a2=$txt' method='post' onsubmit='return validar_nome_cadastro()' >
          <div class='perguntar_nome'>
            <div class='info'>
              Indique o apenas o nome do produto para podermos indentificalos mais rapidamente
            </div>
            <div class='input'>
             <div class='campo_input'>
              <div class='position'>
                <input type='text' name='nomep' id='nome' placeholder='Digite o nome aqui ' maxlength='30' autocomplete='off'>
                <div class='history' id='historico'>
                  
                </div>
              </div>
             </div>
              </br>
              <input type='submit' value='Confirmar' class='submit' id='btn_submit'>
            </div>
          </div>
        </form>
        ";
      }
    ?>
  </div>
  <?php
    if($a=='cadastro_ok'){
      $sql="select * from referencia_nome_tables 
      INNER JOIN nome_categorias ON referencia_nome_tables.nome_categoria_referencia = nome_categorias.id JOIN categorias ON referencia_nome_tables.caminho = categorias.id_categorias where id='$a2';";
      $resultado=mysqli_query($conexao,$sql);
      $row=mysqli_fetch_assoc($resultado);
      $caminho=$row['categoria'];
      $categoria=$row['subcategoria'];
      echo "
      <div class='container_thak_for_help'>
        <div class='cotainer_figure_obg'>
          <figure>
            <img src='img/check.png' alt='' width='200' height='200'>
          </figure>
          <div class='obrigado'>
            <h1>Seu cadastro foi efetuado com sucesso</h1>
            <p>Obrigado por contribuir com o nosso site<p>
            <p>O produto vai estar em breve na área <strong>$caminho / $categoria</strong></p>
            <br>
            <a href='index.php'>Voltar para a pagina inicial</a>
          </div>
        </div>
     </div>
      ";
    }
  ?>
  <?php if($a=='produtos'){?>
    <script>
      mudar();   
    </script>
  <?php }?>
  <script>
    <?php
      if($a=='cadastrar_produto_ou_movel'){
        $palavra_categoria="";
        while($row=$resutado->fetch_array()){
          $palavra_categoria.= trim($row['palavras_categoria']);
        };
        echo 'historico("'.$palavra_categoria.'");';
      }
      ?>  
  </script>
   <footer>
   <div class='legenda'>
      Preço Fácil 2021
    </div>
     <div class='contato'>
      <div>
          Email: EmaildaEmpresa.l@gmail.com
        </div>
        <br>
        <div >
          Telefone: 4002-8922
        </div>
     </div>
  </footer>
</body>
</html>