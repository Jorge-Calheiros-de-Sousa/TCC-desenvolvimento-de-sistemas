<?php
  session_start();
  include('../conexao/conexao.php');
  $login = $_POST['nome'];
  $senha = $_POST['senha'];
  $sql_code = "select * from acesso where login = '$login' and senha = '$senha'";
  $result = mysqli_query($conexao,$sql_code);
  $row = mysqli_num_rows($result);
  if($row == 1){
    $_SESSION['login'] = true;
    header('Location: ../adm/adm.php');
  }elseif($row == 0){
    $_SESSION['login'] = false;
    header('Location: ../adm/');
  }
?>