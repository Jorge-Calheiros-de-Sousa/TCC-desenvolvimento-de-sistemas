<footer>
    <div class='legenda'>
     Preço Fácil 2021
    </div>
    <hr>
     <div class='contato'>
      <div>
          
        </div>
        <br>
        <div >
          
        </div>
     </div>
     <div class='icons_redes'>
        <div>
          <img src="img/facebook.svg" alt="">
        </div>
        <div>
          <img src="img/instagram.svg" alt="">
        </div>
        <div>
          <img src="img/twitter.svg" alt="">
        </div>
     </div>
  </footer>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-CPYN6Q1MXT"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-CPYN6Q1MXT');
</script>