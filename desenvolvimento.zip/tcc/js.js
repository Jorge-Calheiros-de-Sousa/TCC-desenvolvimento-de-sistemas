var url = location.href;
function checkDevice() { 
	if( navigator.userAgent.match(/Android/i)
	|| navigator.userAgent.match(/webOS/i)
	|| navigator.userAgent.match(/iPhone/i)
	|| navigator.userAgent.match(/iPad/i)
	|| navigator.userAgent.match(/iPod/i)
	|| navigator.userAgent.match(/BlackBerry/i)
	|| navigator.userAgent.match(/Windows Phone/i)
	){
		 return true; // está utilizando celular
	 }
	else {
		 return false; // não é celular
	 }
 }
function fechar_busca(){
  var bg = document.getElementById('bg');
	var body = document.getElementById('body');
	if(bg.style.display == 'block'){
		var menu = document.getElementById('menu');
		menu.classList.remove('class_abrir_menu');
		bg.style.display = 'none';
		body.style.overflow='auto';
	}
}
function formatarMoeda() {
	var valor = document.getElementById('preco');
	var preco = valor.value;
	preco = preco + '';
	preco = parseInt(preco.replace(/[\D]+/g,''));
	preco = preco + '';
	preco = preco.replace(/([0-9]{2})$/g, ",$1");
	if(preco.length > 6 ){
		preco = preco.replace(/([0-9]{3}),([0-9]{2})/g, ".$1,$2");
	}
	valor.value = preco;
	if(preco == 'NaN'){
		valor.value = '';
	}
}
/*Tags*/
var tag = "";
function createTag(label) {
	var spantag  = document.createElement('span');
	spantag.setAttribute('class','tag');
	spantag.innerHTML = label;
	var spanDelete =  document.createElement('span');
	spanDelete.setAttribute('class','close');
	spantag.appendChild(spanDelete);
	spanDelete.addEventListener('click',function(){
		delet(spantag);
	})
	return spantag;
}
function reset(){
	var tag = document.getElementById('tag_container');
	tag.innerHTML = '';
}
function delet(sonTag) {
	sonTag.parentElement.removeChild(sonTag);
}
function addTag(tag){
	var input = createTag(tag)
	tag_container.prepend(input);
}
function tecla_chave(){
	var input = document.querySelector('.container input');
	var tag_container = document.getElementById('tag_container');
	if(input.value == "" || input.value == " "){
		alert('Preencha o campo de palavras chaves corretamente');
	}else{
		tag = input.value;
		tag = tag+".";
		addTag(tag);
	}
	input.value = "";
}
/*Validacoes*/
function validar_cad(){
	var nome = document.getElementById('nome').value;
	var nome_mercado = document.getElementById('mercado').value;
	var marca=document.getElementById('marca').value;
	var preco = document.getElementById('preco').value;
	var pais=document.getElementById('pais').value;
	var estado=document.getElementById('estado').value;
	var cidade=document.getElementById('cidade').value;
	var bairro=document.getElementById('bairro').value;
	var foto = document.getElementById('img').value;
	var input = document.getElementById('palavras');
	var palavras_chaves = document.getElementById('tag_container').innerText;
	if(nome == '' || preco == '' || nome_mercado == ''||marca==''){
		alert('Há campos vazios');
		return false;
	}else if(pais==""||estado==""|| cidade==""||bairro==""){
		alert('Os campos de localidade são obrigatórios');
		return false;	
	}else if(foto == '' || foto=='noimage.jpg'){
		alert('A foto é obrigatória');
		return false;	
	}else if(palavras_chaves ==''){
		alert('O campo de palavras chaves é obrigatório');
		return false;
	}else if(palavras_chaves != ''){
		input.value = palavras_chaves;
	}
}
function validar_nome_cadastro(){
	var nome=document.getElementById('nome').value;
	if(nome=='' || nome.length < 3){
		return false;
	}
}
function validar_pesquisa(){
	var input = document.getElementById('nome').value;
	if(input == ''){
		alert('O campo de pesquisa esta vazio');
		return false;
	}else if(input == ' '){
		alert('O campo de pesquisa esta vazio');
		return false;
	}
}
function validar_cadastro(){
	var email = document.getElementById('email').value;
	var mercado = document.getElementById('name_m').value;
	var nome = document.getElementById('name_p').value;
	var preco = document.getElementById('preco').value;
	var categoria = document.getElementById('categoria_cad').value;
	var foto = document.getElementById('img').value;
	var input = document.getElementById('palavras');
	var palavras_chaves = document.getElementById('tag_container').innerText;
	if(email == ''){
		alert('O campo email esta vazio');
		return false;
	}else if(nome == ''){
		alert('O campo nome esta vazio');
		return false;
	}else if(mercado==''){
		alert('O campo mercado esta vazio');
		return false;
	}else if(preco == ''){
		alert('O campo de preço esta vazio');
		return false;
	}else if(categoria == 'nenhum'){
		alert('O campo de categoria é obrigatório');
		return false;
	}else if(foto == ''){
		alert('A foto é obrigatória');
		return false;	
	}else if(palavras_chaves ==''){
		alert('O campo de palavras chaves é obrigatório');
		return false;
	}else if(palavras_chaves != ''){
		input.value = palavras_chaves;
	}
}
function validar_fale(){
	var nome = document.getElementById('nome_usu').value;
	var email= document.getElementById('email_usu').value;
	var assunto=document.getElementById('assunto').value;
	var texto = document.getElementById('mensagem').value;
	if(nome==""){
		alert('O campo nome esta vazio');
		return false;
	}else if(email==''){
		alert('O campo email esta vazio');
		return false;
	}else if(assunto==''){
		alert('O campo assunto esta vazio');
		return false;
	}else if(texto==''){
		alert('O campo	texto esta vazio');
		return false;
	}
}
function validar_modificar(){
	var input = document.getElementById('palavras');
	var img = document.getElementById('imagem').value;
	var nome = document.getElementById('nome_modi').value;
	var mercado = document.getElementById('mercado').value;
	var texto = document.getElementById('modi_descricao').value.trim();
	var palavras_chaves = document.getElementById('tag_container').innerText.trim();
	console.log(texto);
	if(nome=="" && mercado=="" && texto=="" && palavras_chaves=='' && img==""){
		alert("Os campos estão vazios");
		return false;
	}else if(palavras_chaves!=''){
		input.value=palavras_chaves;
	}
}
/*acao*/
function acao_ver_produtos(a){
	if(a == 0){
		location.href = '?a=verProdutos&a2=excluir';
	}else if(a==1){
		location.href = '?a=verProdutos&a2=editar';
	}else if(a==2){
		location.href = '?a=verProdutos&a2=ver';
	}
}
/*Preview*/
function preview(){
	var url=location.href;
	if(url.indexOf('adm.php') != -1){
		$img_false='../img/noimage.jpg';
	}else{
		$img_false='img/noimage.jpg';
	}
	var input_img = document.querySelector('input[name=img_foto]').files[0];
	var caixa = document.getElementById('preview');
	var cadastro = document.getElementById('container_cad_produtos');
	var endereco = new FileReader();
	endereco.onloadend=function(){
		document.getElementById('img_preview').setAttribute('src', endereco.result);
	}
	if(input_img){
		caixa.style.display = 'block';
		endereco.readAsDataURL(input_img);
	}else{
		
		document.getElementById('img_preview').setAttribute('src',$img_false);
	}
}
/*Ajustar*/
function ajustar_img(a){
	var nome_img=document.getElementById('nome_img').innerHTML;
	var container = document.getElementById("container_figure");
	if(a!=0){
		
	}
	if(a==0){
		container.style.transform = "rotate(0deg)";
	}else if(a==90){
		container.style.transform = "rotate(90deg)";
	}else if(a==180){
		container.style.transform = "rotate(180deg)";
	}else if(270){
		container.style.transform = "rotate(270deg)";
	}else if(360){
		container.style.transform = "rotate(360deg)";
	}
}
function trocarImg(){
	var nome_img=document.getElementById('nome_img').innerHTML;
	var img = document.getElementById('img_figure');
	var input_img = document.querySelector('input[name=img_foto]').files[0];
	var endereco = new FileReader();
	endereco.onloadend=function(){
		document.getElementById('img_figure').setAttribute('src', endereco.result);
		aparecer_btn(true);
	}
	if(input_img){
		endereco.readAsDataURL(input_img);
	}else{
		document.getElementById('img_preview').setAttribute('src','');
	}
}
function aparecer_btn(a){
	if(a==true){
		var btn = document.getElementById('salvar_btn');
		btn.style.display='block';
	}
}
function abre_modificar(num){
	var modificar = document.getElementById('modificar_nome');
	var modi_mercado = document.getElementById('modificar_mercado');
	var modi_texto = document.getElementById('modificar_texto');
	var modi_palavras = document.getElementById('modificar_palavras');
	var btn = document.getElementById('perdir_para_modificar');
	var btn2 = document.getElementById('perdir_para_modificar_mercado');
	var btn3 = document.getElementById('perdir_para_modificar_texto');
	var btn4 = document.getElementById('perdir_para_modificar_palavras')
	console.log(num);
	if(num == 1){
		if(modificar.style.display =='none' || modificar.style.display==''){
			modificar.style.display='block';
			btn.innerText='Fechar';
		}else{
			modificar.style.display='none';
			btn.innerText='Deseja modificar o nome?';
		}
	}else if(num == 2){
		if(modi_mercado.style.display == 'none'  || modi_mercado.style.display==''){
			modi_mercado.style.display='block';
			btn2.innerText='Fechar';
		}else{
			modi_mercado.style.display='none';
			btn2.innerText='Deseja modificar o mercado?';
		}
	}else if(num == 3){
		if(modi_texto.style.display == 'none'  || modi_texto.style.display==''){
			modi_texto.style.display = 'block';
			btn3.innerText='Fechar';
		}else{
			modi_texto.style.display = 'none';
			btn3.innerText='Deseja modificar a descrição?';
		}
	}else if(num == 4){
		if(modi_palavras.style.display == 'none'  || modi_palavras.style.display==''){
			modi_palavras.style.display = 'block';
			btn4.innerText='Fechar';
		}else{
			modi_palavras.style.display = 'none';
			btn4.innerText='Deseja modificar as palavras chaves?';
		}
	}
}
/*abrir menu mobile*/
function abrir_menu(){
	var menu = document.getElementById('menu');
	var body = document.getElementById('body');
	var bg = document.getElementById('bg');
	bg.style.display='block';
	menu.classList.add('class_abrir_menu');
	body.style.overflow = 'hidden';
}
function fechar_btn_menu(){
	var bg = document.getElementById('bg');
	var body = document.getElementById('body');
	var menu = document.getElementById('menu');
	menu.classList.remove('class_abrir_menu');
	bg.style.display='none';
	body.style.overflow = 'auto';
}
/*Paginação*/
function capturarParamentros(){
	var url=window.location.href;
	var res = url.split('?');
	if (res[1] === undefined) {
		
	}	
	if(res[1]!== undefined){
		var parametros = res[1].split('&');
		var qtdParametrosParaLer = 10;
		var parametroEncontrado = new Array(); 
		var valorParametro = new Array();

		for (var cont = 0; cont<=qtdParametrosParaLer; cont++){
			if (parametros[cont] !== undefined) 
			{
				captura = parametros[cont].split('=');				
				parametroEncontrado[cont] = captura[0];
				valorParametro[cont] = captura[1];
			}
		}
	}
	return{parametroEncontrado,valorParametro};
}
function paginacao(n){
	const numero=Array.from({length:n}).map((_,i)=>"<div class='container_produto'>Item"+(i+1)+"</div>");
	const { parametroEncontrado, valorParametro }=capturarParamentros();
	porPage=9;

	var url = location.href,
	separado=url.split("?");
	if(url.indexOf('?nome_categoria') != -1){
		var categoriaok=true;
	}else if(url.indexOf('a=sub_categoria') != -1){
		var produtook=true;
	}else if(url.indexOf('?p=') != -1){
		var pesquisaok=true;
	}else if(url.indexOf('verProdutos&categoria') != -1){
		var verProdutoCategoria=true;
	}else if(url.indexOf('verProdutos') != -1){
		var verProdutos=true;
	}else if(url.indexOf(separado[0]) != -1){
		var inicialok=true;
	}
	if(inicialok==true){
			if(parametroEncontrado===undefined && valorParametro === undefined){
				page=1;
			}else if(parametroEncontrado[0]=='pag' && valorParametro[0]!==undefined){
				page=valorParametro[0];
			}
	}else if(pesquisaok == true){
		if(parametroEncontrado[0] =='p' && valorParametro[1] === undefined){
			page=1;
		}else if(parametroEncontrado[0] =='p' && valorParametro[1] != undefined){
			page=valorParametro[1];
		}
	}else if(produtook == true){
		if(valorParametro[0] =='sub_categoria' && valorParametro[3]===undefined){
			page=1;
		}else if(valorParametro[0]=='sub_categoria' && parametroEncontrado[3]=='pag'){
			page=valorParametro[3];
		}
	}else if(categoriaok==true){
		if(parametroEncontrado[0]=='nome_categoria' && parametroEncontrado[9]===undefined){
			page=1;
		}else if(parametroEncontrado[0]=='nome_categoria' && valorParametro[9]!==undefined){
			page=valorParametro[9];
		}
	}else if(verProdutos==true){
		if(valorParametro[0]=='verProdutos' && valorParametro[1]===undefined){
			page=1;
		}else{
			page=valorParametro[1];
		}
	}else if(verProdutoCategoria==true){
		if(parametroEncontrado[1] && valorParametro[2]===undefined){
			page=1;
		}else{
			page=valorParametro[2];
		}
	}	
	var html={
		get(element){
			return document.getElementById(element);
		}
	}
	var estado={
		page,
		porPage,
		totalPage: Math.ceil(n/porPage),
		maxVisivelbotao:5,
	};
	var controles={
		next(){
			var menos=estado.page;
			estado.page++;
			var ultimaPage=estado.page > estado.totalPage;
			if(ultimaPage){
				estado.page--;
			}
			if(inicialok==true){
				if(separado[1]===undefined){
					location.href=url+"?pag="+estado.page;
				}else if(separado[1]!= undefined){
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(produtook == true){
				var url=location.href;
				var separado=url.split("?");
				if(url.indexOf('pag') == -1){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(pesquisaok==true){
				var url=location.href;
				var separado=url.split("?");
				if(parametroEncontrado[1]===undefined && valorParametro[1]==undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(categoriaok==true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[9]===undefined && valorParametro[9]===undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[9]
					console.log(menos);
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(verProdutos==true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[0]=='a' && parametroEncontrado[1]===undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[1];
					var numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(verProdutoCategoria==true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[0]=='a' && parametroEncontrado[2]===undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[2];
					var numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}
		},
		anterior(){
			var menos=estado.page;
			estado.page--;
			if(estado.page<1){
				estado.page++;
			}
			if(inicialok==true){
				if(separado[1]===undefined){
					location.href=url+"?pag="+estado.page;
				}else if(separado[1]!= undefined){
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(produtook == true){
				var url=location.href;
				var separado=url.split("?");
				if(url.indexOf('pag') == -1){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(pesquisaok == true){
				var url=location.href;
				var separado=url.split("?");
				if(parametroEncontrado[1]===undefined && valorParametro[1]==undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(categoriaok == true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[9]===undefined && valorParametro[9]==undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[9]
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(verProdutos==true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[0]=='a' && parametroEncontrado[1]===undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[1];
					var numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(verProdutoCategoria==true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[0]=='a' && parametroEncontrado[2]===undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[2];
					var numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}
		},
		irpara(page){
			var menos=estado.page;
			estado.page = page;
			if(page>estado.totalPage){
				estado.page = estado.totalPage;
			}
			if(inicialok==true){
				if(separado[1]===undefined){
					location.href=url+"?pag="+estado.page;
				}else if(separado[1]!= undefined){
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(produtook == true){
				var url=location.href;
				var separado=url.split("?");
				if(url.indexOf('pag') == -1){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(pesquisaok == true){
				var url=location.href;
				var separado=url.split("?");
				if(parametroEncontrado[1]===undefined && valorParametro[1]==undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(categoriaok == true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[9]===undefined && valorParametro[9]==undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[9]
					numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(verProdutos==true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[0]=='a' && parametroEncontrado[1]===undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[1];
					var numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}else if(verProdutoCategoria==true){
				var url = location.href,
				separado=url.split("?");
				if(parametroEncontrado[0]=='a' && parametroEncontrado[2]===undefined){
					location.href=url+"&pag="+estado.page;
				}else{
					var numero_mudar=separado[1];
					var menos = valorParametro[2];
					var numero_mudar=numero_mudar.replace('pag='+menos,'pag='+estado.page);
					location.href=separado[0]+"?"+numero_mudar;
				}
			}
		},
		createListeners(){
			html.get('primeiro').addEventListener("click",function(){
				controles.irpara(1);
				update();
			});
			html.get('anterior').addEventListener('click',function(){
				controles.anterior();
				update();
			});
			html.get('proximo').addEventListener('click',function(){
				controles.next();
				update();
			})
			html.get('ultimo').addEventListener('click',function(){
				controles.irpara(estado.totalPage);
				update();
			})
		}
	};
	const buttons={
		create(number){
			var button =document.createElement('div');
			button.innerHTML=number;
			button.classList.add('numbers_style');
			button.addEventListener('click', function(event){
				const page= event.target.innerText;
				controles.irpara(page);
				update();
			})
			html.get('numbers').appendChild(button);
			if(button.innerText==estado.page){
				button.style.backgroundColor='cornflowerblue';
				button.style.color='white';
				button.style.boxShadow="2px 2px 5px grey";
			}
		},
		update(){
			html.get('numbers').innerHTML="";
			const { maxLeft, maxRight }=buttons.botaoVisivel();
			for(let page=maxLeft;page<=maxRight;page++){
				buttons.create(page);
			}
		},
		botaoVisivel(){
			const{maxVisivelbotao}=estado;
			let maxLeft=(estado.page - Math.floor(maxVisivelbotao/2));
			let maxRight =(estado.page + Math.floor(maxVisivelbotao/2));

			if(maxLeft<1){
				maxLeft=1;
				maxRight=maxVisivelbotao;
			}

			if(maxRight>estado.totalPage){
				maxLeft=estado.totalPage-(maxVisivelbotao-1);
				maxRight=estado.totalPage;

				if(maxLeft<1)maxLeft=1;
			}
			return{maxRight,maxLeft};
		}
	}
	function update(){
		buttons.update();
	}
	function inicar(){
		controles.createListeners();
		update();
	}
	inicar();
}
/*Direcionar*/
function direcionar(n,id,novo_preco,id_preco){
	var url = location.href;
	url = url.split("?");
	if(n==1){
		location.href=url[0]+"?a=mostrar_produtos&id="+id+"&categoria="+novo_preco+"&subcategoria="+id_preco;
	}else if(n==2){
		location.href=url[0]+"?a=verProdutos&a2=excluir&id="+id;
	}else if(n==3){
		location.href=url[0]+"?a=verProdutos&a2=editar&id="+id;
	}else if(n==4){
		location.href=url[0]+"?a=verProdutos&a2=ver&id="+id;
	}else if(n==5){
		location.href=url[0]+"?a=Aprovacao&a2=ver&id="+id;
	}else if(n==6){
		location.href='?a=verProdutos&a2=true&id='+id;
	}else if(n==7){
		location.href='?a=Aprovacao&a2=aprovar&id='+id;
	}else if(n==8){
		location.href='?a=Aprovacao&a2=repro&id='+id;
	}else if(n==9){
		location.href='?a=Mudancas&a2=verproduto&id='+id;
	}else if(n==10){
		location.href='?a=Mudancas&a2=trocar&preco='+novo_preco+'&id='+id+'&id_preco='+id_preco;
	}else if(n==11){
		location.href='?a=Mudancas&a2=excluir&id='+id;
	}else if(n==12){
		location.href='?a=inserir_palavra&id='+id;
	}else if(n==13){
		location.href='?a=palavra_categoria&id_categoria='+id;
	}else if(n==14){
		location.href=url[0]+"?a=mostrar_produtos&id="+id;
	}else if(n==15){
		location.href=url[0]+"?a=mostrar_produtos&id="+id+"&busca=true&serach="+novo_preco;
	}
}
function direcionar_subcategorias(texto,texto2){
	location.href="?a=sub_categoria&a2="+texto+"&categoria="+texto2;
}
/*Mostrar form de mudança de preço*/
function sugerir_mudanca(){
	var container=document.getElementById('container_form');
	if(container.style.pointerEvents=='none' || container.style.pointerEvents==''){
		container.style.maxHeight='200px';
		container.style.pointerEvents='all';
	}else if(container.style.pointerEvents=='all' || container.style.pointerEvents==''){
		container.style.maxHeight='0';
		container.style.pointerEvents='none';
	}
}
function validar_mudanca_preco(){
	var preco = document.getElementById('preco').value;
	if(preco==''){
		return false;
	}
}
function teste(){
	alert('oi');
}
function redirecioar_categorias(id){
	var container_categorias = document.getElementById('container_categorias_populares');
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
	const funcoes={
		header(texto){
			location.href="?a=categorias&a2="+texto;
		}
	}
	function createListeners(){
		html.get('container_categoria_'+id).addEventListener('click',function(){
			let container = html.get('container_categoria_'+id),
			texto=container.innerText;
			funcoes.header(texto);
		})
	}
	function iniciar(){
		createListeners();
	}
	iniciar();
}
function cadasto_produtos(){
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
	const funcoes={
		createListeners(){
			html.get('Produto').addEventListener('click',function(){
				location.href="cadastro.php?a=cadastrar_produto_ou_movel&a2=produto";
			})
			html.get('moveis').addEventListener('click',function(){
				location.href="cadastro.php?a=cadastrar_produto_ou_movel&a2=movel";
			})
		}
	}
	function iniciar(){
		funcoes.createListeners();
	}
	iniciar();
}
function  historico(n){
	const { parametroEncontrado, valorParametro }=capturarParamentros();
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
		let sugestaoBox=html.get('historico');
		sugestaoBox.style.display=='none';
		let array=n.split(",");
		html.get('nome').addEventListener('keyup',function(){
			let input=html.get('nome');
			let emptyArray=[];
			if(input.value.length>1){
				emptyArray=array.filter((data)=>{
					return data.toLocaleLowerCase().startsWith(input.value.toLocaleLowerCase());
				})
				emptyArray=emptyArray.map((data)=>{
					return data="<li id='li'>"+data+"</li>";
				})
				sugestaoBox.style.display='block';
				mostrarSuges(emptyArray);
				let todaLista=sugestaoBox.getElementsByTagName("li");
				for (let i = 0; i < todaLista.length; i++) {
					todaLista[i].addEventListener('click',function(){
						var select=todaLista[i].innerText;
						input.value=select;
						sugestaoBox.style.display='none';
					})	
				}
			}else{
				sugestaoBox.style.display='none'
			}
		})
		function mostrarSuges(l){
			let list;
			let input=html.get('nome');
			if(!l.length){
				userValue=input.value;
				list="<li id='li'>"+userValue+"</li>";
			}else{
				list=l.join('');
			}
			sugestaoBox.innerHTML=list;
		}
}
/*sugestão de nova categoria*/
function sugerir_nova_categoria(){
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
	html.get('nova_categoria').addEventListener('click',function(){
		var select = html.get('categoria_nova');
		var button=html.get('trocar_categoria');
		if(select.style.opacity==0 || select.style.opacity==''){
			select.style.opacity=1;
			select.style.pointerEvents='all';
			button.style.opacity=1;
			button.style.pointerEvents='all';
		}else{
			select.style.opacity=0;
			select.style.pointerEvents='none';
			button.style.opacity=0;
			button.style.pointerEvents='none';
		}
	})
}
/*Passagem de formulario*/
function mudar(){
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
	const controle={
		irpara(diva,divb){
			var d1=document.getElementById(diva),
			d2=document.getElementById(divb);
			if(d1.style.opacity == "" || d1.style.opacity == "1"){
				d1.style.opacity="0.9";
				controle.irpara(diva,divb);
			}else if(parseFloat(d1.style.opacity) > 0){
				d1.style.opacity = parseFloat(d1.style.opacity)-0.2;
				setTimeout(function(){
					controle.irpara(diva,divb);
				},50);
			}else if(parseFloat(d1.style.opacity) <= 0){
				d1.style.display='none';
				d1.style.opacity='0';
				d2.style.display='block';
				d2.style.opacity='1';
			}
		},
	}
	const funcoes={
    next(){
      var d1=div.id;
      div.id=div.id+1;
      var d2=div.id;
      if(d2>10){
        div.id=div.id-1;
      }
      controle.irpara("form"+d1,"form"+d2);
    },
    prev(){
      var d1=div.id;
      div.id=div.id-1;
      var d2=div.id;
      if(div.id<1){
        div.id=1;
      }
      controle.irpara("form"+d1,"form"+d2);
    }
  }
	const div={
    id:1
  }
	function createListeners(){
		html.get('proximo').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo2').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo3').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo4').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo5').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo6').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo7').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo8').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('proximo9').addEventListener('click',function(){
			funcoes.next();
		})
		html.get('anterior2').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior3').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior4').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior5').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior6').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior7').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior8').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior9').addEventListener('click',function(){
			funcoes.prev();
		})
		html.get('anterior10').addEventListener('click',function(){
			funcoes.prev();
		})
	}
	var parametro=capturarParamentros();
	var stap=parametro.valorParametro;
	if(stap=='step-four'){
		createListeners();
	}
}
/*excluir palavras adm*/
function delete_word(n,id){
	const html={
		get(elemet){
			return document.getElementById(elemet);
		}
	}
	n=n-1;
	const controles={
		createListeners(){
			for (let index = 0; index <= n; index++) {
				html.get('div'+index).addEventListener('click',function(){
					var div=html.get('divb'+index);
					var txt=div.innerText;
					location.href="?a=delete_word&id_categoria="+id+"&a2="+txt;
				})
			}
		}
	}
	function iniciar(){
		controles.createListeners();
	}
	iniciar();
}
/*Validar_add_palavras_adm*/
function validar_add_palavras(){
	var nome=document.getElementById('palavra');
	if(nome.value.length<2 || nome.value==""){
		alert('Digite corretamente');
		return false;
	}
}
/*Abrir categoria adm*/
function abrir_categoria_adm(nome,id,nome_categoria,id_referencia){
	location.href="?a=subcategorias_mostrar&subcategoria="+nome+"&id="+id+"&categoria="+nome_categoria;
}
function mostrar_categoria(id){
	location.href='?a=mostrar_categoria&id='+id;
}
function validar_form_categoria(){
	var palavras=document.getElementById('palavras');
	var img=document.getElementById('img');
	var container=document.getElementById('tag_container').innerText;
	palavras.value=container;
	console.log(palavras.value);
 if(img.value=="" || img.value=='noimage.jpg'){
		alert('A foto é obrigatória');
		return false;
	}
}
function validar_escolher_categorias(){
	var select=document.getElementById('categoria_nova');
	if(select.value=="nenhum"){
		alert('Escolha uma categoria');
		return false;
	}
}
function controles(id,nome,subcategoria,id_referencia){
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
	const controles={
		deletar(div,bg){
			if(div.style.display=='none' || div.style.display==''){
				div.style.display='block';
				bg.style.display='block';
			}else{
				div.style.display='none';
				bg.style.display='none';
			}
		},
		redirecionar(){
			location.href="?a=delete_categoria&id_categoria="+id+"&subcategoria="+subcategoria;
		},
		mostrar_produto(){
			location.href="?a=verProdutos&categoria="+id_referencia;
		},
		mostrar_palavra(){
			location.href="?a=palavra_categoria&id_categoria="+id_referencia;
		},
	}
	function iniciar(){
		html.get('btn_excluir_categoria').addEventListener('click',function(){
			var div=html.get('confirmar_delete_categoria');
			var bg=html.get('bg');
			controles.deletar(div,bg);
		})
		html.get('cancelar').addEventListener('click',function(){
			var div=html.get('confirmar_delete_categoria');
			var bg=html.get('bg');
			controles.deletar(div,bg);
		})
		html.get('confirmar').addEventListener('click',function(){
			controles.redirecionar();
		})
		html.get('mostrar_produtos').addEventListener('click',function(){
			controles.mostrar_produto();
		})
		html.get('mostrar_palavras').addEventListener('click',function(){
			controles.mostrar_palavra();
		})
	}
	iniciar();
}
function abrir_filtro(){
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
	function createListeners(){
		html.get('btn_filtro').addEventListener('click',function(){
			var container_filtro=html.get('container_filtro');
			var container_mostrar_produtos=html.get('container_mostrar_produtos');
			container_mostrar_produtos.style.height="100px"
			container_filtro.style.display='block';
		})
		html.get('btn_fechar_filtro').addEventListener('click',function(){
			var container_filtro=html.get('container_filtro');
			var body=html.get('body');
			var container_mostrar_produtos=html.get('container_mostrar_produtos');
			container_mostrar_produtos.style.height="fit-content";
			container_filtro.style.display='none';
		})
	}
	createListeners();
}
function  scroll_section(){
	var mobile=checkDevice();
	tamanho=window.innerWidth;
	var carrosel=document.getElementById('mini_carrosel');
	var div=document.getElementById('novo_container_produto');
	if(mobile==true){
		if(tamanho == 320 || tamanho>320 && tamanho<360 ){
			var por=200;
		}else if(tamanho == 360 || tamanho>360 && tamanho<411 ){
			var por=220;
		}else if(tamanho==411 || tamanho>411){
			var por=250;
		}
		num=div.offsetWidth*9;
	}else{
		var por=carrosel.offsetWidth;
		num=carrosel.offsetWidth;
	}
	const scroll={
		num,
		porScroll:por,
		scroll:0,
	};
	const controles={
		chege(l){
			scroll.scroll=scroll.scroll+l;
			if(scroll.scroll>scroll.num ){
				scroll.scroll=0;
			}
			carrosel.scrollTo(scroll.scroll,0);
		},
		prev(l){
			scroll.scroll=scroll.scroll-l;
			if(scroll.scroll < 0){
				scroll.scroll=0;
			}
			carrosel.scrollTo(scroll.scroll,0);
		},
		ouvintes(){
			document.getElementById('btn_next').addEventListener('click',function(){
				controles.chege(scroll.porScroll);
			});
			document.getElementById('btn_prev').addEventListener('click',function(){
				controles.prev(scroll.porScroll);
			});
		},
		alone(){
			controles.chege(scroll.porScroll);
		}
	}
	function iniciar(){
		setInterval(function(){
			controles.alone();
		},25000);
		controles.ouvintes();
	}
iniciar();
}
function  scroll_section2(){
	var mobile=checkDevice();
	tamanho=window.innerWidth;
	var carrosel=document.getElementById('mini_carrosel2');
	var div=document.getElementById('novo_container_produto2');
	if(mobile==true){
		if(tamanho == 320 || tamanho>320 && tamanho<360){
			var por=200;
		}else if(tamanho == 360 || tamanho>360 && tamanho<411){
			var por=220;
		}else if(tamanho==411 || tamanho>411){
			var por=250;
		}
		num=div.offsetWidth*9;
	}else{
		var por=carrosel.offsetWidth;
		num=carrosel.offsetWidth;
	}
	const scroll={
		num,
		porScroll:por,
		scroll:0,
	};
	const controles={
		chege(l){
			scroll.scroll=scroll.scroll+l;
			if(scroll.scroll>scroll.num ){
				scroll.scroll=0;
			}
			carrosel.scrollTo(scroll.scroll,0);
		},
		prev(l){
			scroll.scroll=scroll.scroll-l;
			if(scroll.scroll < 0){
				scroll.scroll=0;
			}
			carrosel.scrollTo(scroll.scroll,0);
		},
		ouvintes(){
			document.getElementById('btn_next2').addEventListener('click',function(){
				controles.chege(scroll.porScroll);
			});
			document.getElementById('btn_prev2').addEventListener('click',function(){
				controles.prev(scroll.porScroll);
			});
		},
		alone(){
			controles.chege(scroll.porScroll);
		}
	}
	function iniciar(){
		setInterval(function(){
			controles.alone();
		},28000);
		controles.ouvintes();
	}
iniciar();
}
function  scroll_section3(){
	var mobile=checkDevice();
	tamanho=window.innerWidth;
	var carrosel=document.getElementById('mini_carrosel3');
	var div=document.getElementById('novo_container_produto3');
	if(mobile==true){
		if(tamanho == 320 || tamanho>320 && tamanho<360){
			var por=200;
		}else if(tamanho == 360 || tamanho>360 && tamanho<411){
			var por=220;
		}else if(tamanho==411 || tamanho>411){
			var por=250;
		}
		num=div.offsetWidth*9;
	}else{
		var por=carrosel.offsetWidth;
		num=carrosel.offsetWidth;
	}
	const scroll={
		num,
		porScroll:por,
		scroll:0,
	};
	const controles={
		chege(l){
			scroll.scroll=scroll.scroll+l;
			if(scroll.scroll>scroll.num ){
				scroll.scroll=0;
			}
			carrosel.scrollTo(scroll.scroll,0);
		},
		prev(l){
			scroll.scroll=scroll.scroll-l;
			if(scroll.scroll < 0){
				scroll.scroll=0;
			}
			carrosel.scrollTo(scroll.scroll,0);
		},
		ouvintes(){
			document.getElementById('btn_next3').addEventListener('click',function(){
				controles.chege(scroll.porScroll);
			});
			document.getElementById('btn_prev3').addEventListener('click',function(){
				controles.prev(scroll.porScroll);
			});
		},
		alone(){
			controles.chege(scroll.porScroll);
		}
	}
	function iniciar(){
		setInterval(function(){
			controles.alone();
		},20000);
		controles.ouvintes();
	}
iniciar();
}
/*Carrosel parte principal no top*/
function  carrosel_script(container,next,prev,content_max){
	var carrosel=document.getElementById(container),
	btn_next=document.getElementById(next),
	btn_prev=document.getElementById(prev),
	content=document.getElementById(content_max);
	const scroll={
		maxScroll:carrosel.offsetWidth*4,
		porScroll:carrosel.offsetWidth,
		scroll:0
	}
	const funcoes={
		chenge(porScroll,tipo){
			if(tipo=='next'){
				scroll.scroll=scroll.scroll+porScroll;
			}else{
				scroll.scroll=scroll.scroll-porScroll;
			}
			if(scroll.scroll==scroll.maxScroll){
				scroll.scroll=0;
			}
			carrosel.scrollTo(scroll.scroll,0);
		},
		show_buttons(){
			if(btn_next.style.opacity==0||btn_next.style.opacity==""&& btn_prev.style.opacity==0||btn_prev.style.opacity==""){
				btn_next.style.opacity=1;
				btn_next.style.pointerEvents="all";
				btn_prev.style.opacity=1;
				btn_prev.style.pointerEvents="all";
			}else{
				btn_next.style.opacity=0;
				btn_next.style.pointerEvents="none";
				btn_prev.style.opacity=0;
				btn_prev.style.pointerEvents="none";
			}
		},
		ouvintes(){
			content.addEventListener('mouseover',function(){
				funcoes.show_buttons();
			})
			content.addEventListener('mouseout',function(){
				funcoes.show_buttons();
			})
			btn_next.addEventListener('click',function(){
				funcoes.chenge(scroll.porScroll,'next');
			})
			btn_prev.addEventListener('click',function(){
				funcoes.chenge(scroll.porScroll,'prev');
			})
		},
	}
	function iniciar(){
		setInterval(function(){
			funcoes.chenge(scroll.porScroll,'next');
		},10000);
		funcoes.ouvintes();
	}
	iniciar();
}
/*Script tirar espaco*/
function script_tirar_espacos(id){
	var parametro=capturarParamentros();
	var stap=parametro.valorParametro;
	var texto=document.getElementById(id);
	if(stap=='step-four'){
		texto.value=texto.value.trim();
	}else if(stap===undefined){
		texto.value=texto.value.trim();
	}else if(stap=='empresa'){
		texto.value=texto.value.trim();
	}else if(stap=='faleConosco'){
		texto.value=texto.value.trim();
	}
}
/*Script para abrir a caixa de pesquisa no mobile*/
function caixa_de_pesquisa(){
	var mobile=checkDevice();
	if(mobile==true){
		const html={
			get(element){
				return document.getElementById(element);
			}
		}

		const controle={
			focus(caixa,btn,img,figure){
				btn.style.display='none';
				caixa.style.width="70%";
				img.style.display='block';
				figure.style.display="none";
			},	
			desfocus(caixa,btn,img){
				btn.style.display='block';
				img.style.display='none';
				caixa.style.width="50%";
				figure.style.display="block";
			}
		}
		var btn_menu=html.get('btn_menu_container');
		var caixa=html.get('content_pesquisa');
		var img=html.get('submit_pesquisa');
		var figure=html.get('logo_img');

		function inicar(){
			caixa.addEventListener('mouseover',function(){
				controle.focus(caixa,btn_menu,img,figure);
			}),
			caixa.addEventListener('mouseout',function(){
				controle.desfocus(caixa,btn_menu,img,figure);
			})
		}
		inicar();
	}
}
/*Trocar imagens */
function trocar_imagens(){
	num=1;
	const imagens={
		num,
		img(){
			if(imagens.num==1){
				var img="decisoes-de-compras.jpg";
			}else{
				var img="comparacao.jpg";
			}
			return img;
		}
	}
	const funcao={
		trocar(){
			var imagem=document.getElementById('img_principal');
			setInterval(function(){
				var img=imagens.img();

				funcao.trocarIMG(imagem);

				if(imagens.num>1){
					imagens.num=1
				}else{
					imagens.num=imagens.num+1;
				}
			},5000)
		},
		trocarIMG(imagem){
			var img=imagens.img();
			if(imagem.style.opacity == "" || imagem.style.opacity == "1"){
				imagem.style.opacity="0.9";
				funcao.trocarIMG(imagem);
			}else if(parseFloat(imagem.style.opacity) > 0){
				imagem.style.opacity = parseFloat(imagem.style.opacity)-0.2;
				setTimeout(function(){
					funcao.trocarIMG(imagem);
				},50);
			}else if(parseFloat(imagem.style.opacity) <= 0){
				imagem.src="img/"+img;
				imagem.style.opacity="1";
			}
		}
	}
	funcao.trocar();
}
/*Almentar barra*/
function almentar_barra(){
	var valor_paramentro=capturarParamentros();
	var step=valor_paramentro.valorParametro[0];
	var barra=document.getElementById('barra_preechimento');
	if(step=="step-two"){
		barra.style.width="20%";
	}else if(step=="step-tree"){
		barra.style.width="40%";
	}else if(step=="step-four"){
		barra.style.width="60%";
	}else if(step=='finish'){
		barra.style.width="100%";
	}
}
/*Mostrar selecionar nova categoria*/
function mostrar_select_categoria(click,div){
	const html={
		get(element){
			return document.getElementById(element);
		}
	}
	function inicar(){
		html.get(click).addEventListener('click',function(){
			var container=html.get(div);
			if(container.style.opacity==""||container.style.opacity==0){
				container.style.opacity=1;
				container.style.pointerEvents="all";
				window.scrollTo(0,500)
			}else{
				container.style.opacity=0;
				container.style.pointerEvents="none";
				window.scrollTo(0,0)
			}
		})
	}
	var valor_paramentro=capturarParamentros();
	var step=valor_paramentro.valorParametro[0];
	if(step=="step-tree"){
		inicar();
	}
}
function voltar(){
	window.history.back();
}
/*Fixed header*/
function header_fixed(){
	var valor_paramentro=capturarParamentros();
	var step=valor_paramentro.valorParametro;
		if(step===undefined||step=="empresa"){
			var header=document.getElementById('header');
			var menu=document.getElementById('container_abas');
			var pesquisa=document.getElementById('container_pesquisa');
			var img=document.getElementById('img_logotipo');
			window.addEventListener('scroll',function(){
				var scrollAtual = document.body.scrollTop;
				if(window.scrollY!=scrollAtual){
					img.src="img/Logo7.png";
					header.style.position="fixed";
					header.style.backgroundColor="white";
					header.style.color="black";
					pesquisa.style.border="1px solid black";
				}else{
					img.src="img/Logo6.png";
					header.style.position="relative";
					header.style.backgroundColor="black";
					header.style.color="white";
					pesquisa.style.border="0";
				}
			})
		}
  }
	function imagem_grande(){
		var valor_paramentro=capturarParamentros();
		var step=valor_paramentro.valorParametro;
		var img=document.getElementById('imagem_grande');
		if(step===undefined){
			img.style.display='flex';
		}else{
			img.style.display='none';
		}
	}